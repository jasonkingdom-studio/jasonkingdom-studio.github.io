# -*- coding: utf-8 -*-
"""
JK STUDIO 영상 스튜디오 v2 - 클라우드 영상 모델 클라이언트 (fal.ai 큐 API)
- Kling / Seedance / Hailuo 이미지→영상
- 모델 ID 는 설정에서 바꿀 수 있어 새 버전(예: Seedance 2.x)이 나와도 코드 수정 불필요
"""
import os
import time
import base64
import mimetypes
import requests

FAL_QUEUE = "https://queue.fal.run"

ENGINE_KEYS = {"kling": "fal_kling", "seedance": "fal_seedance", "hailuo": "fal_hailuo"}
ENGINE_NAMES = {"kling": "Kling", "seedance": "Seedance", "hailuo": "Hailuo"}


def _data_uri(path):
    """로컬 이미지를 data URI 로 (fal 은 image_url 에 data URI 허용)"""
    mime = mimetypes.guess_type(path)[0] or "image/png"
    with open(path, "rb") as f:
        return f"data:{mime};base64,{base64.b64encode(f.read()).decode()}"


def _duration(engine, sec):
    """모델별 허용 길이로 맞춤"""
    sec = int(sec or 5)
    if engine == "hailuo":
        return "6" if sec <= 6 else "10"
    return "5" if sec <= 7 else "10"


def image_to_video(engine, image_path, prompt, negative, settings, api_key, dest_dir, progress_cb=None):
    """fal 큐에 요청 → 완료까지 대기 → mp4 다운로드 후 로컬 경로 반환"""
    if engine not in ENGINE_KEYS:
        raise ValueError(f"알 수 없는 클라우드 엔진: {engine}")
    if not api_key:
        raise RuntimeError("fal.ai API 키가 없습니다. ⚙ 설정에 입력하거나 환경변수 FAL_KEY 를 설정하세요.")
    model = settings[ENGINE_KEYS[engine]]
    base = settings.get("_fal_base", FAL_QUEUE)  # 테스트용 주소 교체
    headers = {"Authorization": f"Key {api_key}", "Content-Type": "application/json"}
    payload = {"prompt": prompt, "image_url": _data_uri(image_path),
               "duration": _duration(engine, settings.get("cloud_duration", 5))}
    if negative and engine == "kling":
        payload["negative_prompt"] = negative

    r = requests.post(f"{base}/{model}", json=payload, headers=headers, timeout=120)
    if r.status_code >= 400:
        raise RuntimeError(f"{ENGINE_NAMES[engine]} 요청 실패: HTTP {r.status_code} {r.text[:300]}")
    info = r.json()
    status_url = info.get("status_url") or f"{base}/{model}/requests/{info['request_id']}/status"
    response_url = info.get("response_url") or f"{base}/{model}/requests/{info['request_id']}"

    start = time.time()
    timeout = int(settings.get("timeout", 1800))
    while True:
        st = requests.get(status_url, headers=headers, timeout=30).json()
        s = st.get("status")
        el = int(time.time() - start)
        if s == "COMPLETED":
            break
        if s in ("FAILED", "ERROR"):
            raise RuntimeError(f"{ENGINE_NAMES[engine]} 생성 실패: {st}")
        if el > timeout:
            raise TimeoutError(f"{ENGINE_NAMES[engine]} {timeout}초 초과")
        if progress_cb:
            pos = st.get("queue_position")
            progress_cb(f"{ENGINE_NAMES[engine]} {'대기열 ' + str(pos) + '번째' if pos else '생성 중'}… {el}초")
        time.sleep(4)

    res = requests.get(response_url, headers=headers, timeout=60).json()
    video = res.get("video") or (res.get("videos") or [None])[0]
    url = video.get("url") if isinstance(video, dict) else video
    if not url:
        raise RuntimeError(f"결과 영상 주소가 없습니다: {str(res)[:300]}")
    os.makedirs(dest_dir, exist_ok=True)
    local = os.path.join(dest_dir, f"{engine}_{int(time.time() * 1000)}.mp4")
    with requests.get(url, stream=True, timeout=300) as d:
        d.raise_for_status()
        with open(local, "wb") as f:
            for chunk in d.iter_content(1024 * 256):
                f.write(chunk)
    return local
