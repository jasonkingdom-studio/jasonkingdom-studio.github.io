# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════╗
║  JK STUDIO 영상 스튜디오 v2  ·  JASON KINGDOM STUDIO                 ║
║  무한 캔버스 · 3D 디렉터 스테이지 · 캐스팅 스튜디오 · 캐릭터 시트  ║
║  시네마틱 라이트 · 멀티뷰 · 프로 샷 재현 · 레이어 편집            ║
║  오토링크 롱비디오 · 구간 재작성 · 클라우드 모델 · MCP 에이전트    ║
╚══════════════════════════════════════════════════════════════╝
실행: python app.py  →  http://127.0.0.1:5077
"""
import os
import re
import json
import time
import uuid
import base64
import random
import threading
import traceback
import requests

from flask import Flask, request, jsonify, render_template, send_from_directory, abort

import config
import director_tools as dt
import cloud_client
from comfy_client import ComfyClient, load_workflow, IMAGE_EXT, VIDEO_EXT, AUDIO_EXT
from storyboard_ai import generate_storyboard, write_script, auto_board, detect_scenes

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024
app.json.ensure_ascii = False

IMG_DIR = os.path.join(config.OUTPUT_DIR, "images")
VID_DIR = os.path.join(config.OUTPUT_DIR, "videos")
FRAME_DIR = os.path.join(config.OUTPUT_DIR, "frames")
CUT_DIR = os.path.join(config.OUTPUT_DIR, "cutouts")

# ═══════════════ 작업(Job) 관리 ═══════════════
JOBS = {}
JOBS_LOCK = threading.Lock()
PROJECT_LOCK = threading.Lock()


def new_job(kind, scene_id=None, label="", char_id=None):
    jid = uuid.uuid4().hex[:10]
    with JOBS_LOCK:
        JOBS[jid] = {"id": jid, "kind": kind, "scene_id": scene_id, "char_id": char_id, "label": label,
                     "status": "queued", "progress": 0, "message": "대기 중",
                     "result": None, "error": None, "created": time.time()}
    return jid


def update_job(jid, **kw):
    with JOBS_LOCK:
        if jid in JOBS:
            JOBS[jid].update(kw)


def start_job(jid, fn, d):
    """스레드 실행 → 결과의 apply(수정 지시)를 persist 요청이면 프로젝트 파일에도 반영"""
    def runner():
        update_job(jid, status="running", message="시작")
        try:
            result = fn(jid, d)
            if d.get("persist") and d.get("project") and result and result.get("apply"):
                persist_apply(d["project"], result["apply"])
            update_job(jid, status="done", progress=100, message="완료", result=result)
        except Exception as e:
            traceback.print_exc()
            update_job(jid, status="error", message=str(e), error=str(e))
    threading.Thread(target=runner, daemon=True).start()
    return jid


# ═══════════════ 경로 / 공통 도우미 ═══════════════
MEDIA_ROOTS = {"outputs": config.OUTPUT_DIR, "uploads": config.UPLOAD_DIR}


def path_to_url(path):
    path = os.path.abspath(path)
    for key, root in MEDIA_ROOTS.items():
        root = os.path.abspath(root)
        if path.startswith(root):
            return f"/media/{key}/" + os.path.relpath(path, root).replace("\\", "/")
    raise ValueError("미디어 폴더 밖의 파일입니다")


def url_to_path(url):
    if not url:
        return None
    m = re.match(r"^/media/(outputs|uploads)/(.+)$", url.split("?")[0])
    if not m:
        return None
    root = os.path.abspath(MEDIA_ROOTS[m.group(1)])
    full = os.path.abspath(os.path.join(root, m.group(2)))
    return full if full.startswith(root) and os.path.exists(full) else None


def safe_name(name, default="project"):
    return re.sub(r"[^\w\-]", "_", (name or "").strip())[:60] or default


def join_prompt(*parts):
    return ", ".join(p.strip() for p in parts if p and str(p).strip())


def pick_seed(v):
    try:
        v = int(v)
    except (TypeError, ValueError):
        v = -1
    return v if v >= 0 else random.randint(0, 2**31 - 1)


def build_values(s):
    v = {k.upper(): val for k, val in s.items() if k not in config.SECRET_KEYS}
    v["VID_OUT_FPS"] = int(s.get("vid_fps", 16)) * max(1, int(s.get("interp_multiplier", 1)))  # 보간 후 최종 fps
    return v


# ── 프로젝트 파일 ──
def project_path(name):
    return os.path.join(config.PROJECT_DIR, safe_name(name) + ".json")


def load_project(name):
    with open(project_path(name), "r", encoding="utf-8") as f:
        return json.load(f)


def save_project_file(name, data):
    data["name"] = safe_name(name)
    data["saved_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    tmp = project_path(name) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, project_path(name))


def apply_patches(project, patches):
    """
    수정 지시 적용 (프론트엔드 app.js 의 applyPatches 와 같은 규칙)
    patch = {"target": "scene"|"character"|"project", "id": ..., "set": {필드: 값}, "push": {목록필드: [값...]}}
    """
    for p in patches:
        if p["target"] == "project":
            obj = project
        else:
            coll = project.get("scenes" if p["target"] == "scene" else "characters", [])
            obj = next((o for o in coll if o.get("id") == p["id"]), None)
        if not obj:
            continue
        for k, v in (p.get("set") or {}).items():
            obj[k] = v
        for k, vals in (p.get("push") or {}).items():
            lst = obj.setdefault(k, [])
            for v in vals:
                if v and v not in lst:
                    lst.append(v)
    return project


def persist_apply(name, patches):
    with PROJECT_LOCK:
        if os.path.exists(project_path(name)):
            save_project_file(name, apply_patches(load_project(name), patches))


def scene_characters(scene, characters):
    ids = set(scene.get("characters") or [])
    return [c for c in characters or [] if c.get("id") in ids]


def character_refs(chars, extra_urls=()):
    """캐릭터 대표 이미지 → 씬 참조 → 나머지 캐릭터 참조 순서로 경로 목록"""
    primary, rest = [], []
    for c in chars:
        imgs = [u for u in (c.get("refs") or [])] + ([c["sheet"]] if c.get("sheet") else [])
        if imgs:
            primary.append(imgs[0])
            rest.extend(imgs[1:])
    urls = primary + list(extra_urls) + rest
    seen, out = set(), []
    for u in urls:
        p = url_to_path(u)
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


# ═══════════════ 생성 엔진 ═══════════════
def comfy(s):
    c = ComfyClient(s["comfy_url"])
    if not c.is_alive():
        raise RuntimeError(f"ComfyUI에 연결할 수 없습니다 ({s['comfy_url']}). ComfyUI를 먼저 실행하세요.")
    return c


UPLOAD_KEYS = ("IMAGE1", "IMAGE2", "IMAGE3", "START_IMAGE", "DEPTH_IMAGE", "END_IMAGE")


def voicebox_stop(s):
    """GPU 보호: Voicebox·Ollama 가 VRAM 을 잡고 있으면 ComfyUI 생성이 크게 느려지거나 멈춤 → 생성 전에 비움"""
    import requests as _rq
    try:
        _rq.post(s.get("voicebox_url", "http://127.0.0.1:17493").rstrip("/") + "/shutdown", timeout=3)
        time.sleep(2)
    except Exception:
        pass
    try:  # Ollama 에 올라가 있는 모델을 메모리에서 내림 (다음 사용 때 자동으로 다시 올라감)
        base = s.get("ollama_url", "http://127.0.0.1:11434").rstrip("/")
        for mdl in _rq.get(base + "/api/ps", timeout=3).json().get("models", []):
            _rq.post(base + "/api/generate", json={"model": mdl["name"], "keep_alive": 0}, timeout=10)
    except Exception:
        pass


def comfy_run(jid, s, wf_name, values, exts, dest, prefix, label=""):
    voicebox_stop(s)
    client = comfy(s)
    for k in UPLOAD_KEYS:  # 로컬 이미지 경로는 ComfyUI 에 업로드한 뒤 파일 이름으로 교체
        v = values.get(k)
        if isinstance(v, str) and os.path.exists(v):
            values[k] = client.upload_image(v)
    wf = load_workflow(os.path.join(config.WORKFLOW_DIR, wf_name), values)
    pid = client.queue(wf)
    update_job(jid, message=f"{label} 대기열 등록 ({wf_name})", progress=10)
    inflight_add(jid, pid, exts, dest, prefix, label)
    try:
        hist = client.wait(pid, s["timeout"], lambda m: update_job(jid, message=f"{label} {m}", progress=50))
        files = client.collect_outputs(hist, exts)
        if not files:
            raise RuntimeError(f"결과 파일이 없습니다 ({wf_name} 의 저장 노드 확인)")
        return client.download(files[-1], dest, prefix)
    finally:
        inflight_remove(jid)


# ═══════════════ 재시작 복구: 앱이 꺼져도 ComfyUI 에서 돌던 작업 이어받기 ═══════════════
INFLIGHT_FILE = os.path.join(config.BASE_DIR, "logs", "inflight.json")
INFLIGHT_LOCK = threading.Lock()


def _inflight_rw(fn):
    with INFLIGHT_LOCK:
        try:
            with open(INFLIGHT_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
        out = fn(data)
        os.makedirs(os.path.dirname(INFLIGHT_FILE), exist_ok=True)
        with open(INFLIGHT_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        return out


def inflight_add(jid, pid, exts, dest, prefix, label):
    with JOBS_LOCK:
        j = dict(JOBS.get(jid) or {})
    rec = {"prompt_id": pid, "exts": list(exts), "dest": dest, "prefix": prefix, "label": label,
           "kind": j.get("kind"), "scene_id": j.get("scene_id"), "char_id": j.get("char_id"),
           "job_label": j.get("label"), "resume": j.get("_resume"), "created": j.get("created", time.time())}
    try:
        _inflight_rw(lambda d: d.__setitem__(jid, rec))
    except Exception as e:
        print(f"[복구] 기록 실패: {e}")


def inflight_remove(jid):
    try:
        _inflight_rw(lambda d: d.pop(jid, None))
    except Exception:
        pass


def _find_scene_project(scene_id=None, image_name=None):
    """씬 id 또는 시작 이미지 파일명으로 (프로젝트 이름, 씬) 찾기"""
    for fn in sorted(os.listdir(config.PROJECT_DIR), key=lambda f: -os.path.getmtime(os.path.join(config.PROJECT_DIR, f))):
        if not fn.endswith(".json"):
            continue
        try:
            p = load_project(fn[:-5])
        except Exception:
            continue
        for sc in p.get("scenes", []):
            if scene_id and sc.get("id") == scene_id:
                return fn[:-5], sc
            if image_name and os.path.basename(str(sc.get("image") or "")) == image_name:
                return fn[:-5], sc
    return None, None


def _resume_worker(jid, rec, write_file):
    """ComfyUI 작업이 끝나길 기다렸다가 결과를 받아 씬에 연결 (같은 작업 id → 열려 있는 화면이 그대로 반영)"""
    s = config.load_settings()
    client = comfy(s)
    label = rec.get("label") or "작업"
    try:
        hist = client.wait(rec["prompt_id"], s["timeout"],
                           lambda m: update_job(jid, message=f"♻ 재시작 복구 · {label} {m}", progress=50))
        files = client.collect_outputs(hist, tuple(rec["exts"]))
        if not files:
            raise RuntimeError("결과 파일이 없습니다")
        local = client.download(files[-1], rec["dest"], rec["prefix"])
        url = path_to_url(local)
        result = {"url": url, "apply": []}
        rs = rec.get("resume") or {}
        if rec.get("kind") == "video" and rec.get("scene_id"):
            engine = rs.get("engine") or ("comfy_fast" if rec["prefix"] == "vidf_" else "comfy")
            patch = {"target": "scene", "id": rec["scene_id"], "set": {"video": url, "videoEngine": engine},
                     "push": {"videoHistory": [url]}}
            if rs.get("linkedFrame"):
                patch["set"]["linkedFrame"] = rs["linkedFrame"]
            result.update({"engine": engine, "apply": [patch]})
        elif rec.get("kind") == "image" and rec.get("scene_id"):
            result["apply"] = [{"target": "scene", "id": rec["scene_id"], "set": {"image": url},
                                "push": {"variants": [url]}}]
        if write_file and result["apply"]:
            name, _ = _find_scene_project(scene_id=rec.get("scene_id"))
            if name:
                p = load_project(name)
                apply_patches(p, result["apply"])
                save_project_file(name, p)
        update_job(jid, status="done", progress=100, message="완료 (재시작 복구)", result=result)
        print(f"[복구] {label} → {url}")
    except Exception as e:
        update_job(jid, status="error", error=f"재시작 복구 실패: {e}", message="실패")
    finally:
        inflight_remove(jid)


def resume_inflight():
    """앱 시작 시: ① 기록된 진행 중 작업 이어받기 ② 기록 없는 JK 영상 작업(구버전/강제 종료) 입양"""
    time.sleep(2)
    try:
        recs = _inflight_rw(lambda d: dict(d))
    except Exception:
        recs = {}
    known = set()
    for jid, rec in recs.items():
        known.add(rec["prompt_id"])
        with JOBS_LOCK:
            JOBS[jid] = {"id": jid, "kind": rec.get("kind"), "scene_id": rec.get("scene_id"), "char_id": rec.get("char_id"),
                         "label": rec.get("job_label") or rec.get("label"), "status": "running", "progress": 40,
                         "message": "♻ 재시작 복구 중", "result": None, "error": None, "created": rec.get("created", time.time())}
        threading.Thread(target=_resume_worker, args=(jid, rec, True), daemon=True).start()
    # 기록 없는 JK 영상 작업 (대기열에 남아 있는 것)
    try:
        s = config.load_settings()
        q = requests.get(s["comfy_url"].rstrip("/") + "/queue", timeout=5).json()
    except Exception:
        return
    items = [(it[1], it[2], False) for it in (q.get("queue_running") or []) + (q.get("queue_pending") or [])
             if isinstance(it, list) and len(it) > 2]
    # 앱이 꺼져 있는 동안 이미 끝난 영상 (최근 20분, 씬에 영상이 아직 없을 때만)
    try:
        hist = requests.get(s["comfy_url"].rstrip("/") + "/history?max_items=40", timeout=10).json()
        for hpid, h in hist.items():
            done = [m[1].get("timestamp", 0) for m in h.get("status", {}).get("messages", []) if m[0] == "execution_success"]
            if done and time.time() - max(done) / 1000 < 20 * 60:
                items.append((hpid, (h.get("prompt") or [None, None, {}])[2], True))
    except Exception:
        pass
    for pid, wf, finished in items:
        if pid in known:
            continue
        saves = [n["inputs"].get("filename_prefix", "") for n in wf.values() if isinstance(n, dict) and "Save" in n.get("class_type", "")]
        if not any(str(x).startswith("JK_STUDIO/vid") for x in saves):
            continue
        img = next((n["inputs"].get("image") for n in wf.values() if isinstance(n, dict) and n.get("class_type") == "LoadImage"), None)
        name, sc = _find_scene_project(image_name=os.path.basename(str(img or "")))
        if not sc or (finished and sc.get("video")):
            continue
        fast = any("vidfast" in str(x) for x in saves)
        jid = uuid.uuid4().hex[:10]
        rec = {"prompt_id": pid, "exts": list(VIDEO_EXT), "dest": VID_DIR, "prefix": "vidf_" if fast else "vid_",
               "label": "⚡영상" if fast else "영상", "kind": "video", "scene_id": sc["id"],
               "job_label": f"♻ {sc.get('title', '')}", "resume": {"engine": "comfy_fast" if fast else "comfy"},
               "created": time.time()}
        with JOBS_LOCK:
            JOBS[jid] = {"id": jid, "kind": "video", "scene_id": sc["id"], "char_id": None, "label": rec["job_label"],
                         "status": "running", "progress": 40, "message": "♻ 재시작 복구 중", "result": None,
                         "error": None, "created": time.time()}
        _inflight_rw(lambda d: d.__setitem__(jid, rec))
        threading.Thread(target=_resume_worker, args=(jid, rec, True), daemon=True).start()
        print(f"[복구] 끊긴 영상 작업 이어받음: {name} / {sc.get('title')}")


# ═══════════════ 🎨 화풍 모드 (실사 / 애니메이션) ═══════════════
ANIME_TAGS = ("2D anime illustration style, cel shading, clean bold line art, vibrant colors, "
              "masterpiece, high score, great score, absurdres")
ANIME_NEG = ("photorealistic, photo, 3d render, realistic skin, lowres, bad anatomy, bad hands, extra digits, fewer digits, "
             "cropped, worst quality, low quality, low score, bad score, average score, signature, watermark, username, blurry, text")


def job_settings(d):
    """작업용 설정: 프로젝트 화풍이 애니메이션이면 이미지 모델·품질 태그·네거티브를 애니메이션용으로 교체"""
    s = config.load_settings()
    if (d.get("artStyle") or "real") == "anime":
        if s.get("anime_ckpt"):
            s["ckpt"] = s["anime_ckpt"]
        s["img_steps"] = int(s.get("anime_steps", 28))
        s["img_cfg"] = float(s.get("anime_cfg", 6.0))
        s["negative"] = ANIME_NEG
        s["vid_upscale"] = s.get("anime_upscale", s.get("vid_upscale"))
        if not d.get("_anime_applied"):
            d["globalStyle"] = join_prompt(ANIME_TAGS, d.get("globalStyle"))
            d["_anime_applied"] = True
    return s


def gen_t2i(jid, s, prompt, negative, seed, depth_path=None):
    v = build_values(s)
    v.update({"PROMPT": prompt, "NEGATIVE": join_prompt(negative, s["negative"]), "SEED": seed})
    wf = s["wf_t2i"]
    if depth_path:
        v["DEPTH_IMAGE"] = depth_path
        wf = s["wf_depth"]
    return comfy_run(jid, s, wf, v, IMAGE_EXT, IMG_DIR, "img_", "이미지")


def gen_edit(jid, s, prompt, image_paths, seed, width=None, height=None, label="편집", wf=None):
    """Qwen-Image-Edit: 최대 3장 참조 (넘치면 콜라주)"""
    imgs = dt.pack_references(image_paths, config.UPLOAD_DIR)
    if not imgs:
        raise RuntimeError("참조 이미지가 없습니다")
    v = build_values(s)
    v.update({"PROMPT": prompt, "NEGATIVE": s["negative"], "SEED": seed,
              "OUT_WIDTH": int(width or s["img_width"]) // 16 * 16,
              "OUT_HEIGHT": int(height or s["img_height"]) // 16 * 16,
              "IMAGE1": imgs[0],
              "IMAGE2": imgs[1] if len(imgs) > 1 else None,
              "IMAGE3": imgs[2] if len(imgs) > 2 else None})
    return comfy_run(jid, s, wf or s["wf_edit"], v, IMAGE_EXT, IMG_DIR, "edit_", label)


def gen_video(jid, s, engine, image_path, prompt, negative, seed):
    """engine: comfy | kling | seedance | hailuo"""
    if engine in cloud_client.ENGINE_KEYS:
        return cloud_client.image_to_video(engine, image_path, prompt, negative, s, config.get_fal_key(s), VID_DIR,
                                           lambda m: update_job(jid, message=m, progress=50))
    v = build_values(s)
    v.update({"PROMPT": prompt, "NEGATIVE": join_prompt(negative, s["negative"]), "SEED": seed,
              "START_IMAGE": image_path})
    if engine == "comfy_fast":
        # ⚡ 빠른 모드: GGUF Q4 + 480p + 4스텝 (초안·테스트용)
        v.update({"VID_WIDTH": s["fast_width"], "VID_HEIGHT": s["fast_height"],
                  "VID14_STEPS": s["fast_steps"], "VID14_SPLIT": s["fast_split"]})
        return comfy_run(jid, s, s["wf_i2v_fast"], v, VIDEO_EXT, VID_DIR, "vidf_", "⚡영상")
    local = comfy_run(jid, s, s["wf_i2v"], v, VIDEO_EXT, VID_DIR, "vid_", "영상")
    if s.get("vid_upscale") and s.get("wf_upscale"):
        try:
            local = upscale_video(jid, s, local)
        except Exception as e:
            update_job(jid, message=f"⚠ 업스케일 실패 → 720p 원본 사용 ({str(e)[:80]})")
    return local


def upscale_video(jid, s, local_path):
    """💎 영상 AI 업스케일 (RealESRGAN x4 → 1920x1080)
    메모리 초과를 막기 위해 32프레임씩 나눠 ComfyUI 에 차례로 맡기고, 조각을 ffmpeg 로 이어붙임"""
    import subprocess
    import imageio_ffmpeg
    src = os.path.abspath(local_path)
    ff = imageio_ffmpeg.get_ffmpeg_exe()
    n_frames, secs = imageio_ffmpeg.count_frames_and_secs(src)
    fps = round(n_frames / secs) if secs else int(s.get("vid_fps", 16)) * max(1, int(s.get("interp_multiplier", 1)))
    chunk = int(s.get("upscale_batch", 32))
    parts = []
    for i, skip in enumerate(range(0, n_frames, chunk)):
        v = build_values(s)
        v.update({"VIDEO_PATH": src, "UP_SKIP": skip, "UP_CAP": min(chunk, n_frames - skip), "UP_FPS": fps})
        update_job(jid, message=f"🔍 업스케일 {i + 1}/{-(-n_frames // chunk)}", progress=40 + int(skip / n_frames * 50))
        parts.append(comfy_run(jid, s, s["wf_upscale"], v, VIDEO_EXT, os.path.join(VID_DIR, "_up_parts"), "part_",
                               f"🔍업스케일 {i + 1}"))
    out = os.path.join(VID_DIR, f"vidup_{int(time.time() * 1000)}.mp4")
    lst = out + ".txt"
    with open(lst, "w", encoding="utf-8") as f:
        f.writelines(f"file '{p}'\n".replace("\\", "/") for p in parts)
    subprocess.run([ff, "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", out], check=True,
                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    for p in parts + [lst]:
        try:
            os.remove(p)
        except OSError:
            pass
    return out


# ═══════════════ 작업 본체 ═══════════════
def job_scene_image(jid, d):
    """
    씬 이미지 (자동 모드 선택)
    - 출연 캐릭터/참조 이미지 있음 → 캐스팅 모드 (편집 모델, 얼굴·의상 고정)
    - 3D 깊이맵 사용 → ControlNet Depth
    - 그 외 → 텍스트→이미지
    """
    s = job_settings(d)
    sc = d["scene"]
    chars = scene_characters(sc, d.get("characters"))
    mode = d.get("mode") or "auto"
    refs = character_refs(chars, sc.get("refs") or [])
    depth = url_to_path(sc.get("depth")) if sc.get("useDepth") else None
    if mode == "auto":
        mode = "character" if refs else ("depth" if depth else "t2i")
    seed = pick_seed(sc.get("seed"))
    base_prompt = join_prompt(sc.get("prompt"), d.get("globalStyle"))

    if mode == "character":
        if not refs:
            raise RuntimeError("캐스팅 모드: 출연 캐릭터의 참조 이미지가 없습니다 (🎭 캐스팅에서 이미지 추가)")
        if depth:  # 깊이맵도 있으면 구도 참고용으로 마지막에 추가
            refs = refs + [depth]
        prompt = dt.edit_prompt("character", base_prompt, chars,
                                custom="Use the grayscale depth map only as a composition guide." if depth else "")
        local = gen_edit(jid, s, prompt, refs, seed, label="캐스팅")
    else:
        char_desc = " ".join(c.get("description", "") for c in chars)
        local = gen_t2i(jid, s, join_prompt(base_prompt, char_desc), sc.get("negative"), seed,
                        depth if mode == "depth" else None)
    url = path_to_url(local)
    return {"url": url, "seed": seed, "mode": mode,
            "apply": [{"target": "scene", "id": sc["id"], "set": {"image": url, "lastSeed": seed},
                       "push": {"variants": [url]}}]}


def h3_length(sec):
    """초 → MiniMax H3 프레임 수 (24fps, 17k+5 격자로 올림)"""
    x = max(5, round(float(sec) * 24))
    return x + (5 - (x % 17)) % 17


def h3_prompt(sc, d):
    """MiniMax H3 용 한 덩어리 프롬프트: 화풍 · 장면 · 인물 · 대사(한국어, 입모양 동기화) · 오디오"""
    anime = (d.get("artStyle") or "real") == "anime"
    style = ("2D anime illustration style, cel shading, clean line art, consistent with the first frame, no photorealism"
             if anime else "Realistic live-action cinematic look, practical film photography, natural skin texture")
    chars = scene_characters(sc, d.get("characters"))
    who = "\n".join(f"- {c.get('name')}: {c.get('description', '')}" for c in chars if c.get("description"))
    dur = float(sc.get("duration") or 5)
    lines = []
    dia = (sc.get("dialogue") or "").strip()
    narr = (sc.get("narration") or "").strip()
    if dia:
        lines.append("Dialogue (spoken aloud in Korean by the on-screen characters, lips moving in perfect sync, "
                     "natural pauses between lines):")
        for ln in dia.splitlines():
            m = re.match(r"\s*([^:：]{1,20})\s*[:：]\s*(.+)", ln)
            if m:
                name, said = m.group(1).strip(), m.group(2).strip().strip('"“”')
                c = next((c for c in chars if c.get("name") == name), None)
                tag = f"{name} ({c.get('description', '')[:80]})" if c else name
                lines.append(f'{tag} says in Korean: "{said}"')
            elif ln.strip():
                lines.append(f'Someone says in Korean: "{ln.strip()}"')
    elif narr and d.get("h3_narration", True):
        lines.append(f'Off-screen narrator, deep calm elderly Korean male voice, says in Korean: "{narr}"')
    audio = ("Audio: clear Korean speech in the foreground, subtle natural ambience and foley matching the scene, "
             "no background music, no singing.")
    parts = [style, f"Scene ({dur:.0f} seconds): {sc.get('prompt', '')}", ]
    if sc.get("camera"):
        parts.append(f"Camera: {sc['camera']}, smooth and slow.")
    if who:
        parts.append("Characters (keep faces, hair and costumes identical to the first frame):\n" + who)
    if lines:
        parts.append("\n".join(lines))
    parts.append(audio)
    parts.append("Faces and hands stay sharp and undistorted, correct anatomy, no text, no watermark.")
    return "\n\n".join(parts)


def gen_video_h3(jid, s, sc, d, image_path, seed, fast=False):
    """🗣 대화 영상: MiniMax H3 로 영상 + 음성 동시 생성 (fast: 960x544, 약 2배 빠름)"""
    v = build_values(s)
    if fast:
        v.update({"H3_WIDTH": s.get("h3_fast_width", 960), "H3_HEIGHT": s.get("h3_fast_height", 544)})
    sec = min(float(s.get("h3_max_sec", 12)), max(3.0, float(sc.get("duration") or 5)))
    v.update({"PROMPT": h3_prompt(sc, d), "SEED": seed, "START_IMAGE": image_path,
              "H3_LENGTH": h3_length(sec)})
    return comfy_run(jid, s, s["wf_h3"], v, VIDEO_EXT, VID_DIR, "vidtalk_", "🗣대화영상")


def job_scene_video(jid, d):
    """씬 영상 — 오토링크면 이전 씬 영상의 마지막 프레임에서 시작"""
    s = job_settings(d)
    sc = d["scene"]
    start_url = None
    if d.get("autolink") and d.get("prev_video"):
        pv = url_to_path(d["prev_video"])
        if pv:
            update_job(jid, message="이전 씬 마지막 프레임 추출 (오토링크)", progress=5)
            start = dt.extract_frame(pv, FRAME_DIR, "last")
            start_url = path_to_url(start)
    if not start_url:
        start = url_to_path(sc.get("image"))
        if not start:
            raise RuntimeError("시작 이미지가 없습니다. 먼저 이미지를 생성하거나 업로드하세요.")
    engine = d.get("engine") or sc.get("engine") or "comfy_fast"
    prompt = join_prompt(sc.get("prompt"), sc.get("camera"), d.get("globalStyle"))
    seed = pick_seed(sc.get("seed"))
    update_job(jid, _resume={"engine": engine, "linkedFrame": start_url})   # 재시작 복구용
    if engine in ("h3", "h3_fast"):
        local = gen_video_h3(jid, s, sc, d, start, seed, fast=engine == "h3_fast")
    else:
        local = gen_video(jid, s, engine, start, prompt, sc.get("negative"), seed)
    url = path_to_url(local)
    patch = {"target": "scene", "id": sc["id"], "set": {"video": url, "videoEngine": engine,
                                                         "upscaled": "vidup_" in os.path.basename(local),
                                                         "videoHasAudio": engine in ("h3", "h3_fast")},
             "push": {"videoHistory": [url]}}
    if start_url:
        patch["set"]["linkedFrame"] = start_url
    return {"url": url, "engine": engine, "apply": [patch]}


def job_edit(jid, d):
    """디렉터 도구: sheet / portrait / light / multiview / recreate / harmonize / custom"""
    s = job_settings(d)
    mode = d["mode"]
    sc = d.get("scene") or {}
    chars_all = d.get("characters") or []
    seed = pick_seed(d.get("seed", sc.get("seed", -1)))
    custom = d.get("custom", "")

    # ── 캐릭터 관련 ──
    if mode in ("sheet", "portrait"):
        ch = next((c for c in chars_all if c.get("id") == d.get("char_id")), None)
        if not ch:
            raise RuntimeError("캐릭터를 찾을 수 없습니다")
        if mode == "portrait":  # 설명만으로 캐릭터 이미지 생성
            desc = ch.get('description', ch.get('name')) or ""
            if (d.get("artStyle") or "real") == "anime" and not re.search(r"\b1(boy|girl)\b", desc):
                # 애니메이션 모델은 여자 캐릭터로 쏠리는 경향 → 설명에서 성별을 읽어 태그 부여
                low = desc.lower()
                if re.search(r"\b(woman|girl|female|lady|queen|princess)\b", low):
                    desc = "1girl, solo, " + desc
                elif re.search(r"\b(man|boy|male|king|prince|god|lord|warrior|monk)\b", low):
                    desc = "1boy, male focus, solo, masculine face, " + desc
            prompt = join_prompt(f"character design portrait of {desc}",
                                 "full body, standing, neutral pose, plain light gray studio background, soft light, highly detailed",
                                 d.get("globalStyle"))
            v = build_values(s)
            v.update({"PROMPT": prompt, "NEGATIVE": s["negative"], "SEED": seed,
                      "IMG_WIDTH": 832, "IMG_HEIGHT": 1216})
            local = comfy_run(jid, s, s["wf_t2i"], v, IMAGE_EXT, IMG_DIR, "char_", "캐릭터")
            url = path_to_url(local)
            return {"url": url, "apply": [{"target": "character", "id": ch["id"], "push": {"refs": [url]}}]}
        refs = character_refs([ch])
        if not refs:
            raise RuntimeError("캐릭터 시트: 먼저 참조 이미지를 추가하거나 AI 생성하세요")
        local = gen_edit(jid, s, dt.edit_prompt("sheet", chars=[ch], custom=custom), refs[:3], seed, 1536, 864, "캐릭터시트")
        url = path_to_url(local)
        return {"url": url, "apply": [{"target": "character", "id": ch["id"], "set": {"sheet": url}}]}

    # ── 씬 이미지 기반 도구 ──
    chars = scene_characters(sc, chars_all)
    base = url_to_path(d.get("image") or sc.get("image"))
    scene_prompt = join_prompt(sc.get("prompt"), d.get("globalStyle"))
    urls = []

    if mode == "light":
        if not base:
            raise RuntimeError("씬 이미지가 필요합니다")
        local = gen_edit(jid, s, dt.edit_prompt("light", light=d.get("light"), custom=custom), [base], seed, label="라이트")
        urls.append(path_to_url(local))
    elif mode == "multiview":
        if not base:
            raise RuntimeError("씬 이미지가 필요합니다")
        angles = d.get("angles") or ["left45", "right45", "close"]
        for i, a in enumerate(angles):
            update_job(jid, message=f"멀티뷰 {i + 1}/{len(angles)}: {dt.MULTIVIEW_ANGLES.get(a, (a,))[0]}",
                       progress=int(i / len(angles) * 90))
            # 각도 LoRA 가 있으면 씬 이미지 1장만 넣고 전용 워크플로우 사용 (참조가 많으면 원래 구도로 끌려감)
            wf_ang = s.get("wf_edit_angles")
            use_ang = bool(wf_ang and s.get("qwen_angles_lora") and os.path.exists(os.path.join(config.WORKFLOW_DIR, wf_ang)))
            refs = [base] if use_ang else [base] + character_refs(chars)[:2]
            local = gen_edit(jid, s, dt.edit_prompt("multiview", angle=a, custom=custom), refs, seed + i,
                             label=f"멀티뷰 {i + 1}/{len(angles)}", wf=wf_ang if use_ang else None)
            urls.append(path_to_url(local))
    elif mode == "recreate":
        shot = url_to_path(d.get("refshot"))
        if not shot:
            raise RuntimeError("재현할 레퍼런스 샷 이미지를 올려주세요")
        refs = [shot] + character_refs(chars)
        local = gen_edit(jid, s, dt.edit_prompt("recreate", scene_prompt, chars, custom=custom), refs, seed, label="샷 재현")
        urls.append(path_to_url(local))
    elif mode == "harmonize":
        if not base:
            raise RuntimeError("합성할 이미지가 없습니다")
        local = gen_edit(jid, s, dt.edit_prompt("harmonize", custom=custom), [base], seed, label="레이어 합성")
        urls.append(path_to_url(local))
    elif mode == "custom":
        if not base:
            raise RuntimeError("씬 이미지가 필요합니다")
        refs = [base] + [p for p in (url_to_path(u) for u in d.get("extra_refs", [])) if p]
        local = gen_edit(jid, s, dt.edit_prompt("custom", custom=custom), refs, seed, label="자유 편집")
        urls.append(path_to_url(local))
    else:
        raise ValueError(f"알 수 없는 모드: {mode}")

    patch = {"target": "scene", "id": sc.get("id"), "push": {"variants": urls}}
    if mode in ("recreate", "harmonize", "light", "custom") and d.get("set_main", True):
        patch["set"] = {"image": urls[0]}
    return {"urls": urls, "url": urls[0], "apply": [patch]}


def job_rewrite(jid, d):
    """구간 재작성: [start,end] 를 새 프롬프트로 다시 생성해서 교체"""
    s = job_settings(d)
    sc = d["scene"]
    vpath = url_to_path(sc.get("video"))
    if not vpath:
        raise RuntimeError("재작성할 씬 영상이 없습니다")
    start, end = float(d.get("start", 0)), float(d.get("end", 0))
    update_job(jid, message=f"{start:.1f}초 프레임 추출", progress=5)
    frame = dt.extract_frame(vpath, FRAME_DIR, start)
    prompt = join_prompt(d.get("prompt") or sc.get("prompt"), d.get("camera") or sc.get("camera"), d.get("globalStyle"))
    clip = gen_video(jid, s, d.get("engine") or "comfy", frame, prompt, sc.get("negative"), pick_seed(-1))
    update_job(jid, message="구간 교체·인코딩", progress=90)
    out = dt.splice_segment(vpath, clip, start, end, VID_DIR)
    url = path_to_url(out)
    return {"url": url, "apply": [{"target": "scene", "id": sc["id"], "set": {"video": url},
                                    "push": {"videoHistory": [sc.get("video"), url]}}]}


def job_bgm(jid, d):
    """AI 배경음악 생성 (ACE-Step) → 프로젝트 BGM 으로 등록"""
    s = config.load_settings()
    style = (d.get("style") or "").strip() or s["bgm_default_style"]
    seconds = max(10.0, min(240.0, float(d.get("seconds") or 60)))
    v = build_values(s)
    v.update({"PROMPT": style, "LYRICS": d.get("lyrics") or ("[Instrumental]" if "15" in s["wf_bgm"] else "[inst]"), "SECONDS": round(seconds, 1),
              "SEED": pick_seed(d.get("seed", -1))})
    local = comfy_run(jid, s, s["wf_bgm"], v, AUDIO_EXT, os.path.join(config.OUTPUT_DIR, "bgm"), "bgm_", "BGM")
    url = path_to_url(local)
    name = f"AI BGM · {style[:40]}"
    return {"url": url, "name": name,
            "apply": [{"target": "project", "id": None, "set": {"bgm": url, "bgmName": name}, "push": {"bgmHistory": [url]}}]}


def job_cutout(jid, d):
    p = url_to_path(d.get("image"))
    if not p:
        raise RuntimeError("이미지가 없습니다")
    update_job(jid, message="배경 제거 중 (첫 실행은 모델 다운로드로 오래 걸림)", progress=30)
    return {"url": path_to_url(dt.remove_background(p, CUT_DIR))}


def job_render(jid, d):
    from video_editor import render_project
    s = config.load_settings()
    if s.get("tts_engine") == "voicebox" and d.get("opts", {}).get("narration", True):
        # 내 목소리(Voicebox)는 GPU 가 필요 → ComfyUI 가 잡고 있는 VRAM 을 먼저 비움
        try:
            import requests
            requests.post(s["comfy_url"].rstrip("/") + "/free", json={"unload_models": True, "free_memory": True}, timeout=10)
            update_job(jid, message="ComfyUI VRAM 비우는 중 (내레이션 준비)", progress=2)
            time.sleep(3)
        except Exception:
            pass
    scenes = {sc["id"]: sc for sc in d.get("scenes", [])}
    ordered = [scenes[i] for i in d.get("order", []) if i in scenes]
    out = os.path.join(config.OUTPUT_DIR, "renders",
                       f"{safe_name(d.get('name'), 'render')}_{time.strftime('%Y%m%d_%H%M%S')}.mp4")
    render_project(ordered, d.get("opts", {}), s, out, url_to_path,
                   lambda m, p=None: update_job(jid, message=m, **({"progress": int(p)} if p is not None else {})))
    return {"url": path_to_url(out), "apply": []}


# ═══════════════ 라우트 ═══════════════
@app.route("/")
def index():
    return render_template("index.html", app_name=config.APP_NAME, brand=config.BRAND, version=config.VERSION)


@app.route("/media/<kind>/<path:filename>")
def media(kind, filename):
    if kind not in MEDIA_ROOTS:
        abort(404)
    return send_from_directory(MEDIA_ROOTS[kind], filename)


@app.route("/api/status")
def api_status():
    s = config.load_settings()
    return jsonify({
        "comfy": ComfyClient(s["comfy_url"]).is_alive(), "comfy_url": s["comfy_url"],
        "claude": bool(config.get_api_key(s)), "gemini": bool(config.get_gemini_key(s)), "fal": bool(config.get_fal_key(s)),
        "workflows": sorted(f for f in os.listdir(config.WORKFLOW_DIR) if f.endswith(".json")),
        "version": config.VERSION,
    })


@app.route("/api/presets")
def api_presets():
    return jsonify({
        "lights": [{"key": k, "label": v[0]} for k, v in dt.LIGHT_PRESETS.items()],
        "angles": [{"key": k, "label": v[0]} for k, v in dt.MULTIVIEW_ANGLES.items()],
        "engines": [{"key": "comfy_fast", "label": "⚡ 빠른 모드 (480p · 2~4분)"},
                    {"key": "comfy", "label": "💎 고품질 (720p · 10~15분)"},
                    {"key": "h3_fast", "label": "🗣 대화 영상 · 빠름 (H3 960×544 · 약 8분)"},
                    {"key": "h3", "label": "🗣 대화 영상 · 고화질 (H3 1344×768 · 약 17분)"}] +
                   [{"key": k, "label": f"{n} (클라우드)"} for k, n in cloud_client.ENGINE_NAMES.items()],
    })


@app.route("/api/settings", methods=["GET", "POST"])
def api_settings():
    if request.method == "POST":
        config.save_settings(request.get_json(force=True) or {})
    return jsonify(config.public_settings())


@app.route("/api/projects")
def api_projects():
    items = []
    for f in os.listdir(config.PROJECT_DIR):
        if f.endswith(".json"):
            items.append({"name": f[:-5], "mtime": os.path.getmtime(os.path.join(config.PROJECT_DIR, f))})
    return jsonify(sorted(items, key=lambda x: -x["mtime"]))


@app.route("/api/projects/<name>", methods=["GET", "POST", "DELETE"])
def api_project(name):
    path = project_path(name)
    if request.method == "POST":
        with PROJECT_LOCK:
            save_project_file(name, request.get_json(force=True))
        return jsonify({"ok": True, "name": safe_name(name), "mtime": os.path.getmtime(path)})
    if request.method == "DELETE":
        if os.path.exists(path):
            os.remove(path)
        return jsonify({"ok": True})
    if not os.path.exists(path):
        abort(404)
    data = load_project(name)
    data["_mtime"] = os.path.getmtime(path)
    return jsonify(data)


@app.route("/api/projects/<name>/meta")
def api_project_meta(name):
    path = project_path(name)
    return jsonify({"exists": os.path.exists(path), "mtime": os.path.getmtime(path) if os.path.exists(path) else 0})


@app.route("/api/upload", methods=["POST"])
def api_upload():
    f = request.files.get("file")
    if not f:
        return jsonify({"error": "파일이 없습니다"}), 400
    base, ext = os.path.splitext(f.filename or "file")
    dest = os.path.join(config.UPLOAD_DIR, f"{safe_name(base, 'file')}_{uuid.uuid4().hex[:6]}{ext.lower()}")
    f.save(dest)
    return jsonify({"url": path_to_url(dest)})


@app.route("/api/upload_dataurl", methods=["POST"])
def api_upload_dataurl():
    data = request.get_json(force=True)
    m = re.match(r"^data:image/(png|jpeg);base64,(.+)$", data.get("data", ""))
    if not m:
        return jsonify({"error": "잘못된 이미지 데이터"}), 400
    ext = "jpg" if m.group(1) == "jpeg" else "png"
    dest = os.path.join(config.UPLOAD_DIR, f"{safe_name(data.get('prefix', 'img'))}_{uuid.uuid4().hex[:8]}.{ext}")
    with open(dest, "wb") as fp:
        fp.write(base64.b64decode(m.group(2)))
    return jsonify({"url": path_to_url(dest)})


@app.route("/api/storyboard", methods=["POST"])
def api_storyboard():
    d = request.get_json(force=True)
    script = (d.get("script") or "").strip()
    if not script:
        return jsonify({"error": "대본/아이디어를 입력해주세요"}), 400
    s = config.load_settings()
    return jsonify(generate_storyboard(script, d.get("n", 6), d.get("style", ""), s))


@app.route("/api/autoboard", methods=["POST"])
def api_autoboard():
    """⚡ 자동 씬 나누기: 스토리보드면 그대로 분할, 아이디어면 대본 → 분할 → 캐스팅 (한 번에)"""
    d = request.get_json(force=True)
    text = (d.get("text") or "").strip()
    if not text:
        return jsonify({"error": "스토리나 스토리보드 내용을 입력해주세요"}), 400
    try:
        return jsonify(auto_board(text, d.get("n", 0), d.get("style", ""), d.get("tone", ""), config.load_settings()))
    except Exception as e:
        return jsonify({"error": f"자동 씬 나누기 실패: {e}"}), 500


@app.route("/api/detect_scenes", methods=["POST"])
def api_detect_scenes():
    """입력 중 미리보기: 씬 표시가 몇 개 보이는지"""
    d = request.get_json(force=True)
    return jsonify({"count": len(detect_scenes(d.get("text") or ""))})


@app.route("/api/script", methods=["POST"])
def api_script():
    """스토리/아이디어 → 대본"""
    d = request.get_json(force=True)
    story = (d.get("story") or "").strip()
    if not story:
        return jsonify({"error": "스토리나 아이디어를 입력해주세요"}), 400
    try:
        return jsonify(write_script(story, d.get("n", 6), d.get("style", ""), d.get("tone", ""), config.load_settings()))
    except Exception as e:
        return jsonify({"error": f"대본 작성 실패: {e}"}), 500


@app.route("/api/lastframe", methods=["POST"])
def api_lastframe():
    d = request.get_json(force=True)
    p = url_to_path(d.get("video"))
    if not p:
        return jsonify({"error": "영상이 없습니다"}), 400
    return jsonify({"url": path_to_url(dt.extract_frame(p, FRAME_DIR, d.get("at", "last")))})


def _job_route(kind, fn, label_key="label"):
    d = request.get_json(force=True)
    sc = d.get("scene") or {}
    jid = new_job(kind, sc.get("id") or d.get("scene_id"), d.get(label_key, kind), d.get("char_id"))
    start_job(jid, fn, d)
    return jsonify({"job_id": jid})


@app.route("/api/generate/scene_image", methods=["POST"])
def api_scene_image():
    return _job_route("image", job_scene_image)


def job_upscale(jid, d):
    """🔍 씬 영상 AI 업스케일 (빠른 모드·기존 영상도 1080p 로)"""
    s = config.load_settings()
    sc = d["scene"]
    src = url_to_path(sc.get("video"))
    if not src:
        raise RuntimeError("업스케일할 영상이 없습니다")
    url = path_to_url(upscale_video(jid, s, src))
    return {"url": url, "apply": [{"target": "scene", "id": sc["id"], "set": {"video": url, "upscaled": True},
                                   "push": {"videoHistory": [url]}}]}


@app.route("/api/generate/upscale", methods=["POST"])
def api_upscale():
    return _job_route("video", job_upscale)


@app.route("/api/generate/scene_video", methods=["POST"])
def api_scene_video():
    return _job_route("video", job_scene_video)


@app.route("/api/generate/edit", methods=["POST"])
def api_edit():
    return _job_route("edit", job_edit)


@app.route("/api/generate/rewrite", methods=["POST"])
def api_rewrite():
    return _job_route("rewrite", job_rewrite)


@app.route("/api/generate/bgm", methods=["POST"])
def api_bgm():
    return _job_route("bgm", job_bgm)


@app.route("/api/cutout", methods=["POST"])
def api_cutout():
    return _job_route("cutout", job_cutout)


@app.route("/api/render", methods=["POST"])
def api_render():
    return _job_route("render", job_render)


@app.route("/api/jobs")
def api_jobs():
    with JOBS_LOCK:
        return jsonify(sorted(JOBS.values(), key=lambda j: -j["created"])[:50])


@app.route("/api/jobs/<jid>")
def api_job(jid):
    with JOBS_LOCK:
        j = JOBS.get(jid)
        return jsonify(j) if j else (jsonify({"error": "없는 작업"}), 404)


@app.route("/api/interrupt", methods=["POST"])
def api_interrupt():
    return jsonify({"ok": ComfyClient(config.load_settings()["comfy_url"]).interrupt()})


if __name__ == "__main__":
    print("=" * 64)
    print(f"  {config.APP_NAME} v{config.VERSION}  ·  {config.BRAND}")
    print(f"  브라우저에서 열기 → http://127.0.0.1:{config.PORT}")
    print("=" * 64)
    threading.Thread(target=resume_inflight, daemon=True).start()
    app.run(host="127.0.0.1", port=config.PORT, debug=False, threaded=True)
