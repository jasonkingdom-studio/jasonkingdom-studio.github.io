# 🎬 JK STUDIO 영상 스튜디오 v3.0 (무료판)
**JASON KINGDOM STUDIO** · https://jasonkingdom.com

내 PC 한 대에서 **스토리 → 대본 → 씬 → 캐스팅 → 이미지 → 영상 → 대사·내레이션·BGM·자막 → 완성 MP4** 까지 만드는 로컬 AI 영상 제작 앱입니다.
클라우드 구독 없이, 작품·목소리·캐릭터가 모두 내 PC 안에만 저장됩니다.

## ✨ 주요 기능
| 기능 | 설명 |
|---|---|
| 🧠 AI 작가 · 자동 씬 나누기 | 아이디어 몇 줄 → 대본·컷 분할·캐스팅 한 번에. 써 둔 스토리보드(씬1./S#1/1.)를 붙여넣으면 그대로 분할 |
| 🎥/🎨 화풍 모드 | 실사(RealVisXL) / 애니메이션(Animagine XL 4.0) 토글 하나로 전체 전환 |
| 🎭 캐스팅 · 캐릭터 일관성 | 캐릭터 사진 1장으로 모든 컷에서 같은 얼굴·의상 유지, 캐릭터 시트(정면·측면·후면·얼굴) |
| 💡 디렉터 도구 | 시네마틱 라이트 10종, 멀티뷰(카메라 각도), 프로 샷 재현, 레이어 합성, 자유 편집 |
| 🗺 무한 캔버스 | 노드로 컷을 연결하는 스토리보드, 3D 디렉터 스테이지(깊이맵) |
| 🎬 영상 생성 | ⚡빠른 모드(480p·2~4분) / 💎고품질(720p+프레임보간+AI 업스케일 1080p) / 오토링크 롱비디오 / 구간 재작성 |
| 🗣 대화 영상 | MiniMax H3 — 대사를 적으면 인물이 입을 맞춰 직접 말하는 영상 + 효과음 |
| 🎙 내레이션 | Voicebox(내 목소리 복제) 또는 edge-tts |
| 🎼 AI BGM | ACE-Step 1.5 — 장르·악기 지정 작곡, 무음 구간 자동 보정 |
| 🎞 최종 렌더 | 자막·페이드·BGM 믹스, 1080p MP4 |
| 🤖 AI 에이전트 | MCP 서버 내장 — Claude 등 AI 비서가 앱을 직접 조작 |

## 💻 필요 환경
- Windows 10/11, **NVIDIA 그래픽카드 VRAM 16GB 이상 권장** (RTX 5060 Ti 16GB 에서 개발·검증)
- Python 3.11 이상
- **ComfyUI** (Stability Matrix 로 설치 권장) — `127.0.0.1:8188` 에서 실행
- ComfyUI 커스텀 노드: `ComfyUI-GGUF`, `ComfyUI-Frame-Interpolation`, `ComfyUI-VideoHelperSuite`

## 📦 모델 (ComfyUI models 폴더에 직접 받아 넣기 — 앱에는 포함되어 있지 않습니다)
쓰는 기능의 모델만 받으면 됩니다. 파일 이름은 ⚙ 설정 창에서 바꿀 수 있습니다.

| 기능 | 폴더 | 파일 |
|---|---|---|
| 이미지(실사) | checkpoints | RealVisXL_V5.0_fp16.safetensors |
| 이미지(애니) | checkpoints | animagine-xl-4.0-opt.safetensors |
| 3D 스테이지 | controlnet | controlnet-depth-sdxl-1.0.safetensors |
| 캐스팅·편집 | unet / loras / text_encoders / vae | Qwen-Image-Edit-2509-Q4_K_M.gguf · Qwen-Image-Edit-2509-Lightning-4steps-V1.0-bf16 · qwen_2.5_vl_7b_fp8_scaled · qwen_image_vae |
| 멀티뷰 | loras | Qwen-Edit-2509 Multiple-angles LoRA (qwen_edit_2509_multiple_angles.safetensors) |
| 영상(빠른) | unet | Wan2.2-I2V-A14B-HighNoise/LowNoise-Q4_K_M.gguf |
| 영상(고품질) | diffusion_models | wan2.2_i2v_high/low_noise_14B_fp8_scaled |
| 영상 공통 | loras / text_encoders / vae | wan2.2_i2v_lightx2v_4steps_lora_v1 (high/low) · umt5_xxl_fp8_e4m3fn_scaled · wan_2.1_vae |
| 프레임 보간 | Frame-Interpolation ckpts | rife47.pth |
| 업스케일 | upscale_models | RealESRGAN_x2plus.pth |
| 대화 영상 | diffusion_models / text_encoders / vae / loras | minimax_h3_fl2va_pruned_w4a8_mixed · qwen3vl_32b_minimax_h3_nvfp4_awq · minimax_h3_video_vae_fp16 · minimax_h3_audio_vae_fp32 · minimax_h3_fl2v_turbo_8step |
| BGM | checkpoints | ace_step_1.5_turbo_aio.safetensors |

## 🚀 설치 · 실행
1. 이 폴더를 원하는 곳에 압축 해제 (예: `C:\JK_STUDIO_Video`)
2. `설치.bat` 실행 (처음 한 번)
3. ComfyUI 실행 후 `JK_STUDIO_실행.bat` → 브라우저에서 http://127.0.0.1:5077 자동으로 열림

## 🔑 선택 설정 (⚙ 설정 창 또는 Windows 환경변수)
- AI 작가: `ANTHROPIC_API_KEY`(Claude) 또는 `GEMINI_API_KEY` — 없으면 로컬 Ollama 사용
- 내 목소리: Voicebox 설치 후 설정 창에 프로필 이름 입력
- 클라우드 영상(Kling/Seedance/Hailuo): `FAL_KEY`

## ⏱ 참고 속도 (RTX 5060 Ti 16GB 실측)
- 빠른 영상 5초: 3~5분 · 고품질 720p 5초: 약 15분 · 업스케일 5초: 약 5분
- 대화 영상(빠름 960×544) 7초: 약 6분 · 캐릭터 캐스팅 이미지: 1~3분

## ⚠ 안내
- 무료 배포판이며 개인 창작용으로 자유롭게 사용하세요. 사용하는 각 AI 모델은 해당 모델의 라이선스를 따릅니다.
- 문의: JASON KINGDOM STUDIO · https://jasonkingdom.com/#contact
