# -*- coding: utf-8 -*-
"""
JK STUDIO 영상 스튜디오 - ComfyUI API 클라이언트
- 워크플로우(API 형식 JSON) 불러오기 + {{키}} 치환
- 대기열 등록(/prompt) → 완료 대기(/history) → 결과 다운로드(/view)
- 이미지 업로드(/upload/image)
"""
import os
import json
import time
import uuid
import copy
import re
import requests

IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp")
VIDEO_EXT = (".mp4", ".webm", ".mov", ".gif", ".webp")
AUDIO_EXT = (".mp3", ".flac", ".wav", ".opus", ".ogg")

_PH = re.compile(r"\{\{([A-Z0-9_]+)\}\}")


def fill_placeholders(obj, values):
    """JSON 안의 "{{KEY}}" 문자열을 값으로 치환 (통째로 일치하면 숫자형 유지)"""
    if isinstance(obj, dict):
        return {k: fill_placeholders(v, values) for k, v in obj.items()}
    if isinstance(obj, list):
        return [fill_placeholders(v, values) for v in obj]
    if isinstance(obj, str):
        m = _PH.fullmatch(obj.strip())
        if m and m.group(1) in values:
            return values[m.group(1)]           # 숫자는 숫자 그대로
        return _PH.sub(lambda mm: str(values.get(mm.group(1), mm.group(0))), obj)
    return obj


def prune_none(wf):
    """
    값이 None 으로 치환된 노드를 삭제하고, 그 노드에 연결된 (선택) 입력도 제거.
    예) 참조 이미지가 1장뿐이면 {{IMAGE2}}, {{IMAGE3}} = None → 해당 LoadImage 노드와 연결선 삭제
    """
    changed = True
    while changed:
        changed = False
        dead = [nid for nid, node in wf.items()
                if isinstance(node, dict) and any(v is None for v in node.get("inputs", {}).values())]
        for nid in dead:
            wf.pop(nid, None)
            changed = True
        for node in wf.values():
            ins = node.get("inputs", {})
            for k in [k for k, v in ins.items()
                      if isinstance(v, list) and len(v) == 2 and isinstance(v[0], str) and v[0] not in wf]:
                ins.pop(k)
                changed = True
    return wf


def load_workflow(path, values):
    """워크플로우 파일을 읽어 치환한 뒤 반환. UI 형식(nodes 배열)은 거부"""
    if not os.path.exists(path):
        raise FileNotFoundError(f"워크플로우 파일이 없습니다: {os.path.basename(path)}")
    with open(path, "r", encoding="utf-8") as f:
        wf = json.load(f)
    if "nodes" in wf and "links" in wf:
        raise ValueError("UI 형식 워크플로우입니다. ComfyUI에서 'Export (API)'로 저장한 파일을 넣어주세요.")
    wf.pop("_comment", None)
    wf = fill_placeholders(copy.deepcopy(wf), values)
    wf = prune_none(wf)
    left = sorted(set(_PH.findall(json.dumps(wf))))
    if left:
        raise ValueError(f"치환되지 않은 값이 있습니다: {', '.join(left)}")
    return wf


class ComfyClient:
    def __init__(self, base_url):
        self.base = base_url.rstrip("/")
        self.client_id = str(uuid.uuid4())

    # ── 상태 확인 ──
    def is_alive(self):
        try:
            return requests.get(f"{self.base}/system_stats", timeout=3).ok
        except requests.RequestException:
            return False

    # ── 이미지 업로드 (깊이맵, 시작 프레임 등) ──
    def upload_image(self, local_path):
        with open(local_path, "rb") as f:
            r = requests.post(f"{self.base}/upload/image",
                              files={"image": (os.path.basename(local_path), f, "image/png")},
                              data={"overwrite": "true", "type": "input"}, timeout=60)
        r.raise_for_status()
        info = r.json()
        name = info.get("name")
        if info.get("subfolder"):
            name = f"{info['subfolder']}/{name}"
        return name

    # ── 대기열 등록 ──
    def queue(self, workflow):
        r = requests.post(f"{self.base}/prompt",
                          json={"prompt": workflow, "client_id": self.client_id}, timeout=30)
        if r.status_code != 200:
            # ComfyUI 검증 오류 메시지를 사람이 읽기 좋게 정리
            try:
                err = r.json()
                detail = err.get("error", {}).get("message", "")
                nodes = err.get("node_errors", {})
                parts = []
                for nid, ne in nodes.items():
                    for e in ne.get("errors", []):
                        parts.append(f"[노드 {nid} {ne.get('class_type','')}] {e.get('message','')} {e.get('details','')}")
                raise RuntimeError(f"ComfyUI 거부: {detail} {' / '.join(parts)}".strip())
            except ValueError:
                raise RuntimeError(f"ComfyUI 거부: HTTP {r.status_code} {r.text[:300]}")
        return r.json()["prompt_id"]

    def queue_position(self, prompt_id):
        """대기열에서 몇 번째인지 (0=실행 중, None=모름)"""
        try:
            q = requests.get(f"{self.base}/queue", timeout=5).json()
            for item in q.get("queue_running", []):
                if len(item) > 1 and item[1] == prompt_id:
                    return 0
            pending = sorted(q.get("queue_pending", []), key=lambda x: x[0])
            for i, item in enumerate(pending):
                if len(item) > 1 and item[1] == prompt_id:
                    return i + 1
        except Exception:
            pass
        return None

    # ── 완료 대기 ──
    def wait(self, prompt_id, timeout=1800, progress_cb=None):
        start = time.time()
        while True:
            try:
                r = requests.get(f"{self.base}/history/{prompt_id}", timeout=10)
                if r.ok:
                    data = r.json()
                    if prompt_id in data:
                        h = data[prompt_id]
                        status = h.get("status", {})
                        if status.get("status_str") == "error":
                            msgs = [m[1].get("exception_message", "") for m in status.get("messages", [])
                                    if m and m[0] == "execution_error"]
                            raise RuntimeError("ComfyUI 실행 오류: " + (" ".join(msgs) or "알 수 없음"))
                        if h.get("outputs"):
                            return h
            except requests.RequestException:
                pass
            elapsed = int(time.time() - start)
            if elapsed > timeout:
                raise TimeoutError(f"{timeout}초 안에 생성이 끝나지 않았습니다")
            if progress_cb:
                pos = self.queue_position(prompt_id)
                if pos == 0:
                    progress_cb(f"생성 중… {elapsed}초")
                elif pos:
                    # 같은 ComfyUI 를 쓰는 다른 앱(jason-studio 음악 생성 등)의 작업이 끝날 때까지 순서대로 대기 → GPU 동시 사용 없음
                    progress_cb(f"⏸ 다른 작업 대기 중 (대기열 {pos}번째)… {elapsed}초")
                else:
                    progress_cb(f"처리 중… {elapsed}초")
            time.sleep(2)

    # ── 결과 파일 목록 ──
    @staticmethod
    def collect_outputs(history, exts):
        files = []
        for node_out in history.get("outputs", {}).values():
            for key, items in node_out.items():
                if not isinstance(items, list):
                    continue
                for it in items:
                    if isinstance(it, dict) and "filename" in it:
                        if it.get("type") == "temp":
                            continue  # 미리보기용 임시 파일 제외
                        if it["filename"].lower().endswith(exts):
                            files.append(it)
        return files

    # ── 다운로드 ──
    def download(self, file_info, dest_dir, prefix=""):
        os.makedirs(dest_dir, exist_ok=True)
        params = {"filename": file_info["filename"],
                  "subfolder": file_info.get("subfolder", ""),
                  "type": file_info.get("type", "output")}
        r = requests.get(f"{self.base}/view", params=params, timeout=300, stream=True)
        r.raise_for_status()
        ext = os.path.splitext(file_info["filename"])[1]
        local = os.path.join(dest_dir, f"{prefix}{int(time.time()*1000)}{ext}")
        with open(local, "wb") as f:
            for chunk in r.iter_content(1024 * 256):
                f.write(chunk)
        return local

    def interrupt(self):
        try:
            requests.post(f"{self.base}/interrupt", timeout=5)
            return True
        except requests.RequestException:
            return False
