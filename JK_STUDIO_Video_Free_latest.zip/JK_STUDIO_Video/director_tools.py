# -*- coding: utf-8 -*-
"""
JK STUDIO 영상 스튜디오 v2 - 디렉터 도구 모음
- 편집 모델(Qwen-Image-Edit) 모드별 프롬프트: 캐스팅 / 캐릭터 시트 / 시네마틱 라이트 / 멀티뷰 / 프로 샷 재현 / 레이어 합성
- 다중 레퍼런스 콜라주 (참조 이미지가 3장을 넘으면 한 장으로 묶어서 전달)
- 영상 프레임 추출 (오토링크용 마지막 프레임, 구간 재작성용 시작 프레임)
- 구간 재작성 영상 이어붙이기
- 배경 제거 (레이어 편집용, rembg)
"""
import os
import time
import math

from PIL import Image

# ── 시네마틱 라이트 프리셋 ──────────────────────────────────
LIGHT_PRESETS = {
    "golden_hour": ("골든아워", "warm golden hour sunset light coming from a low angle, long soft shadows, glowing rim light"),
    "blue_hour": ("블루아워", "cool blue hour twilight ambience, soft diffuse light, city lights starting to glow"),
    "neon": ("사이버펑크 네온", "cyberpunk neon lighting, magenta and cyan rim lights, wet reflective surfaces, volumetric haze"),
    "noir": ("필름 누아르", "high-contrast film noir lighting, hard key light through window blinds, deep black shadows, black and white"),
    "moonlight": ("달빛", "cold moonlight from above, desaturated blue tones, soft silver highlights, night atmosphere"),
    "candle": ("촛불", "warm flickering candlelight, very low key, orange glow on faces, dark surroundings"),
    "studio": ("스튜디오 3점 조명", "professional three-point studio lighting, soft key light, fill light, clean hair light"),
    "overcast": ("흐린 날", "soft overcast daylight, even diffuse lighting, muted natural colors"),
    "fire": ("불빛/폭발", "dramatic orange firelight from below, sparks, strong contrast, smoky atmosphere"),
    "shaman": ("무속 제의 조명", "ritual shamanic ceremony lighting, red and gold lantern glow, incense smoke, mystical rays"),
}

# ── 멀티뷰 각도 ────────────────────────────────────────────
MULTIVIEW_ANGLES = {
    "left45": ("왼쪽 45°", "Rotate the camera 45 degrees to the left around the subject"),
    "right45": ("오른쪽 45°", "Rotate the camera 45 degrees to the right around the subject"),
    "top": ("하이앵글", "Change to a high-angle shot looking down at the subject from above"),
    "low": ("로우앵글", "Change to a dramatic low-angle shot looking up at the subject"),
    "close": ("클로즈업", "Zoom in to a tight close-up shot of the main character's face"),
    "wide": ("와이드", "Zoom out to a wide establishing shot showing the whole environment"),
    "reverse": ("리버스샷", "Show the reverse angle from behind the main character, looking at what they see"),
    "ots": ("오버숄더", "Over-the-shoulder shot from behind the main character"),
}
# Multiple-angles LoRA(dx8152) 학습 명령어 — 중국어 카메라 지시가 가장 잘 먹힘
MULTIVIEW_CN = {
    "left45": "将镜头向左旋转45度",
    "right45": "将镜头向右旋转45度",
    "top": "将镜头转为俯视",
    "low": "将镜头向下移动，将镜头转为仰视",
    "close": "将镜头转为特写镜头",
    "wide": "将镜头转为广角镜头",
    "reverse": "将镜头向左旋转90度，将镜头向左旋转90度",
    "ots": "将镜头向右旋转45度，将镜头向前移动",
}


def _chars_text(chars):
    return " ".join(f"{c.get('name', '')}: {c.get('description', '')}." for c in chars if c.get("description"))


def edit_prompt(mode, scene_prompt="", chars=None, light=None, angle=None, custom=""):
    """모드별 편집 프롬프트 생성"""
    chars = chars or []
    ct = _chars_text(chars)
    sp = (scene_prompt or "").strip()
    if mode == "character":
        return (f"Create a new cinematic film still: {sp}. "
                f"The characters must look exactly like the people in the reference images — identical face, "
                f"hairstyle, body type and outfit. {ct} Photorealistic, high detail. {custom}").strip()
    if mode == "sheet":
        return ("Character reference sheet of the person in image 1: full-body turnaround showing front view, "
                "three-quarter view, side view and back view side by side, plus one close-up face portrait. "
                "Identical outfit, hairstyle and proportions in every view, neutral standing pose, "
                f"clean light gray studio background, soft even lighting. {ct} {custom}").strip()
    if mode == "light":
        desc = LIGHT_PRESETS.get(light, (None, light))[1] if light else custom
        return (f"Relight this image with {desc}. Keep exactly the same composition, camera angle, characters, "
                f"faces, poses, clothing and objects. Only change the lighting, shadows, color temperature and atmosphere. {custom if light else ''}").strip()
    if mode == "multiview":
        desc = MULTIVIEW_ANGLES.get(angle, (None, angle))[1]
        cn = MULTIVIEW_CN.get(angle, "")
        return (f"{cn} {desc}. Keep the same person, face, outfit, lighting and location. {custom}").strip()
    if mode == "recreate":
        if chars:
            return (f"Recreate image 1 exactly: same camera angle, lens, shot size, composition, pose and lighting. "
                    f"But the person must be the character from the other reference image(s) — identical face, hair and outfit. "
                    f"{ct} {sp} {custom}").strip()
        return (f"Recreate image 1 exactly: same camera angle, lens, shot size, composition, pose and lighting, "
                f"but restyle the content as: {sp}. {custom}").strip()
    if mode == "harmonize":
        return ("Blend every element of this collage into one seamless photorealistic cinematic image. "
                "Unify the lighting direction, shadows, perspective, color grading and film grain. "
                f"Keep each element's position, size and identity unchanged. {custom}").strip()
    if mode == "custom":
        return custom or sp
    raise ValueError(f"알 수 없는 편집 모드: {mode}")


# ── 다중 레퍼런스 ──────────────────────────────────────────
def make_collage(paths, dest_dir, cell=512):
    """여러 참조 이미지를 격자 한 장으로 합치기 (50장 레퍼런스 기능)"""
    paths = [p for p in paths if p and os.path.exists(p)]
    if not paths:
        return None
    n = len(paths)
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)
    sheet = Image.new("RGB", (cols * cell, rows * cell), (235, 235, 235))
    for i, p in enumerate(paths):
        im = Image.open(p).convert("RGB")
        im.thumbnail((cell, cell))
        x = (i % cols) * cell + (cell - im.width) // 2
        y = (i // cols) * cell + (cell - im.height) // 2
        sheet.paste(im, (x, y))
    out = os.path.join(dest_dir, f"refs_{int(time.time() * 1000)}.png")
    sheet.save(out)
    return out


def pack_references(paths, dest_dir, slots=3):
    """참조 이미지를 편집 모델의 3칸에 배치. 넘치면 마지막 칸을 콜라주로"""
    paths = [p for p in paths if p and os.path.exists(p)]
    if len(paths) <= slots:
        return paths
    return paths[:slots - 1] + [make_collage(paths[slots - 1:], dest_dir)]


# ── 영상 프레임 ────────────────────────────────────────────
def extract_frame(video_path, dest_dir, at="last"):
    """영상에서 프레임 한 장 추출 (at: 'last' 또는 초 단위 숫자)"""
    from moviepy import VideoFileClip
    v = VideoFileClip(video_path)
    try:
        fps = v.fps or 24
        t = max(0, v.duration - 1.5 / fps) if at == "last" else max(0, min(float(at), v.duration - 1.0 / fps))
        frame = v.get_frame(t)
    finally:
        v.close()
    out = os.path.join(dest_dir, f"frame_{int(time.time() * 1000)}.png")
    Image.fromarray(frame).save(out)
    return out


def splice_segment(orig_path, new_clip_path, start, end, dest_dir):
    """원본 영상의 [start, end] 구간을 새 클립으로 교체 (새 클립 속도를 구간 길이에 맞춤)"""
    from moviepy import VideoFileClip, concatenate_videoclips, vfx
    v = VideoFileClip(orig_path).without_audio()
    n = VideoFileClip(new_clip_path).without_audio()
    start = max(0.0, float(start))
    end = min(v.duration, float(end))
    if end - start < 0.3:
        raise ValueError("재작성 구간이 너무 짧습니다 (0.3초 이상)")
    seg = n.resized(v.size).with_effects([vfx.MultiplySpeed(final_duration=end - start)])
    parts = []
    if start > 0.05:
        parts.append(v.subclipped(0, start))
    parts.append(seg)
    if end < v.duration - 0.05:
        parts.append(v.subclipped(end, v.duration))
    out = os.path.join(dest_dir, f"rewrite_{int(time.time() * 1000)}.mp4")
    final = concatenate_videoclips(parts, method="compose")
    final.write_videofile(out, fps=v.fps or 24, codec="libx264", audio=False, logger=None)
    for c in (final, v, n):
        try:
            c.close()
        except Exception:
            pass
    return out


# ── 배경 제거 ──────────────────────────────────────────────
_rembg_session = None


def remove_background(image_path, dest_dir):
    """rembg 로 배경 제거 → 투명 PNG (첫 실행 때 모델 자동 다운로드)"""
    global _rembg_session
    try:
        from rembg import remove, new_session
    except ImportError:
        raise RuntimeError("배경 제거 모듈이 없습니다: pip install rembg onnxruntime")
    if _rembg_session is None:
        _rembg_session = new_session("isnet-general-use")
    im = Image.open(image_path).convert("RGBA")
    out_im = remove(im, session=_rembg_session)
    out = os.path.join(dest_dir, f"cutout_{int(time.time() * 1000)}.png")
    out_im.save(out)
    return out
