# -*- coding: utf-8 -*-
"""
JK STUDIO 영상 스튜디오 v2 - 설정 모듈
JASON KINGDOM STUDIO
- 기본 설정값 정의
- settings.json 에 사용자 설정 저장/불러오기 (화면의 ⚙ 설정 창에서 수정)
"""
import os
import json

# ── 폴더 경로 ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.join(BASE_DIR, "projects")     # 프로젝트(.json)
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")       # 생성 결과물
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")       # 업로드, 깊이맵, 레이어 합성본
WORKFLOW_DIR = os.path.join(BASE_DIR, "workflows")   # ComfyUI API 워크플로우
SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")

for _d in (PROJECT_DIR, OUTPUT_DIR, UPLOAD_DIR, WORKFLOW_DIR,
           *[os.path.join(OUTPUT_DIR, x) for x in ("images", "videos", "renders", "tts", "frames", "cutouts", "bgm")]):
    os.makedirs(_d, exist_ok=True)

APP_NAME = "JK STUDIO 영상 스튜디오"
BRAND = "JASON KINGDOM STUDIO"
VERSION = "3.0"
PORT = 5077

# ── 기본 설정값 ───────────────────────────────────────────
# 워크플로우 JSON 안의 {{대문자키}} 는 아래 설정값으로 자동 치환됩니다.
DEFAULT_SETTINGS = {
    # 연결
    "comfy_url": "http://127.0.0.1:8188",
    "anthropic_api_key": "",
    "claude_model": "claude-sonnet-5",
    "gemini_api_key": "",                     # 비우면 환경변수 GEMINI_API_KEY / GOOGLE_API_KEY
    "gemini_model": "gemini-2.5-flash",
    "ollama_url": "http://127.0.0.1:11434",
    "ollama_model": "gemma4:31b",
    "llm_order": "claude,gemini,ollama",      # 대본·스토리보드 AI 시도 순서
    "fal_api_key": "",                        # 클라우드 영상(Kling/Seedance/Hailuo)용 fal.ai 키
    "timeout": 1800,

    # 워크플로우 파일
    "wf_t2i": "t2i_sdxl.json",
    "wf_depth": "depth_t2i_sdxl.json",
    "wf_i2v": "i2v_wan22_14b_rife.json",  # 고품질(14B). 가벼운 버전: i2v_wan22_5b.json
    "wf_edit": "qwen_edit_gguf_lightning.json",         # 캐스팅/라이트/멀티뷰/샷재현/합성 공용 편집 모델
    "wf_bgm": "bgm_ace15.json",                # AI 배경음악 (ACE-Step 1.5, 구버전: bgm_ace_step.json)

    # 이미지 생성 (SDXL)
    "ckpt": "RealVisXL_V5.0_fp16.safetensors",
    "anime_ckpt": "animagine-xl-4.0-opt.safetensors",   # 🎨 애니메이션 모드 이미지 모델
    "anime_steps": 28,
    "anime_cfg": 6.0,
    "controlnet_depth": "controlnet-depth-sdxl-1.0.safetensors",
    "cn_strength": 0.75,
    "img_width": 1344,
    "img_height": 768,
    "img_steps": 30,
    "img_cfg": 5.0,
    "negative": "blurry, low quality, deformed, bad anatomy, watermark, text, logo",

    # 편집 모델 (Qwen-Image-Edit 2509)
    "qwen_unet": "qwen_image_edit_2509_fp8_e4m3fn.safetensors",
    "qwen_clip": "qwen_2.5_vl_7b_fp8_scaled.safetensors",
    "qwen_vae": "qwen_image_vae.safetensors",
    "qwen_gguf": "Qwen-Image-Edit-2509-Q4_K_M.gguf",
    "qwen_lightning": "Qwen-Image-Edit-2509-Lightning-4steps-V1.0-bf16.safetensors",
    "wf_edit_angles": "qwen_edit_gguf_angles.json",   # 멀티뷰 전용 (Multiple-angles LoRA)
    "qwen_angles_lora": "qwen_edit_2509_multiple_angles.safetensors",
    "angles_lora_strength": 1.0,
    "edit_steps": 4,                          # Lightning LoRA: 4스텝, CFG 1
    "edit_cfg": 1.0,

    # 영상 생성 (Wan 2.2 TI2V 5B, 프레임 수는 4n+1)
    "wan_unet": "wan2.2_ti2v_5B_fp16.safetensors",
    "wan_clip": "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
    "wan_vae": "wan2.2_vae.safetensors",
    # Wan 2.2 14B I2V (고품질) + Lightx2v 4스텝 LoRA
    "wan14_high": "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
    "wan14_low": "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
    "wan14_lora_high": "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
    "wan14_lora_low": "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
    "wan21_vae": "wan_2.1_vae.safetensors",
    "vid14_steps": 6,                          # 4 → 6: 빠른 동작 잔상 감소
    "vid14_split": 3,
    # 🗣 대화 영상 (MiniMax H3: 영상 + 음성/대사 동시 생성)
    "wf_h3": "i2va_minimax_h3.json",
    "h3_unet": "minimax_h3_fl2va_pruned_w4a8_mixed.safetensors",
    "h3_clip": "qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
    "h3_vae": "minimax_h3_video_vae_fp16.safetensors",
    "h3_audio_vae": "minimax_h3_audio_vae_fp32.safetensors",
    "h3_lora": "minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors",
    "h3_steps": 8,
    "h3_width": 1344,
    "h3_height": 768,
    "h3_max_sec": 12,
    "h3_fast_width": 960,                     # 🗣 빠른 대화 영상 (약 2배 빠름, 나중에 업스케일 가능)
    "h3_fast_height": 544,
    # ⚡ 빠른 모드 (Wan 2.2 14B GGUF Q4, 480p, 4스텝)
    "wf_i2v_fast": "i2v_wan22_14b_gguf_fast.json",
    "wan14_high_gguf": "Wan2.2-I2V-A14B-HighNoise-Q4_K_M.gguf",
    "wan14_low_gguf": "Wan2.2-I2V-A14B-LowNoise-Q4_K_M.gguf",
    "fast_width": 832,
    "fast_height": 480,
    "fast_steps": 4,
    "fast_split": 2,
    "vid_width": 1280,
    "vid_height": 720,
    "vid_frames": 81,
    "vid_fps": 16,
    "interp_multiplier": 2,                   # RIFE 프레임 보간 배수 (16fps × 2 = 32fps)
    "rife_model": "rife47.pth",
    # 💎 고품질 영상 후처리: AI 업스케일 (720p → 1080p)
    "vid_upscale": True,
    "wf_upscale": "upscale_video_esrgan.json",
    "upscale_model": "RealESRGAN_x2plus.pth",   # 2배 모델: x4 대비 약 4배 빠름 (720p→1440p→1080p)
    "upscale_batch": 32,
    "up_width": 1920,
    "up_height": 1080,
    "vid_steps": 20,
    "vid_cfg": 5.0,

    # 클라우드 영상 모델 (fal.ai 모델 ID — 새 버전이 나오면 여기만 바꾸면 됨)
    "fal_kling": "fal-ai/kling-video/v2.1/standard/image-to-video",
    "fal_seedance": "fal-ai/bytedance/seedance/v1/pro/image-to-video",
    "fal_hailuo": "fal-ai/minimax/hailuo-02/standard/image-to-video",
    "cloud_duration": 5,

    # AI 배경음악 (ACE-Step 3.5B)
    "ace_ckpt": "ace_step_v1_3.5b.safetensors",
    "ace15_ckpt": "ace_step_1.5_turbo_aio.safetensors",
    "bgm_steps": 8,                           # ACE-Step 1.5 turbo: 8스텝, CFG 1
    "bgm_cfg": 1.0,
    "bgm_bpm": 90,
    "bgm_key": "D minor",
    "bgm_timesig": "4",
    "bgm_default_style": "cinematic, ambient, epic orchestral, emotional, instrumental, no vocals",

    # 내레이션 / 자막
    "tts_engine": "voicebox",                 # voicebox(내 목소리) | edge
    "voicebox_url": "http://127.0.0.1:17493",
    "voicebox_exe": "C:/Program Files/Voicebox/voicebox.exe",   # 내레이션 때만 자동 실행, 생성 전 자동 종료
    "voicebox_profile": "",                  # Voicebox 에 등록한 내 목소리 프로필 이름 (비우면 edge-tts)
    "voicebox_instruct": "",
    "tts_voice": "ko-KR-InJoonNeural",
    "tts_rate": "+0%",
    "font_path": "C:/Windows/Fonts/malgunbd.ttf",
}

SECRET_KEYS = {"anthropic_api_key", "fal_api_key", "gemini_api_key"}


def load_settings():
    """기본값 + settings.json 을 합쳐서 반환"""
    data = dict(DEFAULT_SETTINGS)
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                data.update(json.load(f))
        except Exception as e:
            print(f"[설정] settings.json 읽기 실패: {e}")
    return data


def save_settings(new_values):
    """화면에서 받은 설정을 형 변환 후 저장 (비밀키 칸이 비어 있으면 기존 값 유지)"""
    cur = load_settings()
    for key, val in new_values.items():
        if key in SECRET_KEYS and (val is None or val == "" or str(val).startswith("●")):
            continue
        default = DEFAULT_SETTINGS.get(key)
        try:
            if isinstance(default, bool):
                val = bool(val)
            elif isinstance(default, int):
                val = int(float(val))
            elif isinstance(default, float):
                val = float(val)
        except (TypeError, ValueError):
            val = default
        cur[key] = val
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(cur, f, ensure_ascii=False, indent=2)
    return cur


def public_settings():
    """비밀키를 가린 설정 (화면 표시용)"""
    s = load_settings()
    for k in SECRET_KEYS:
        s[k] = "●●●●●●●● (저장됨)" if s.get(k) else ""
    return s


def _env(name):
    """환경변수 읽기: 현재 프로세스 → Windows 사용자/시스템 환경변수(레지스트리)
    (원격·예약 실행 창에는 사용자 환경변수가 전달되지 않는 경우가 있어 레지스트리까지 확인)"""
    v = os.environ.get(name, "")
    if v:
        return v
    try:
        import winreg
        for root, path in ((winreg.HKEY_CURRENT_USER, r"Environment"),
                           (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")):
            try:
                with winreg.OpenKey(root, path) as k:
                    v = winreg.QueryValueEx(k, name)[0]
                    if v:
                        return v
            except OSError:
                pass
    except ImportError:
        pass
    return ""


def get_api_key(settings=None):
    settings = settings or load_settings()
    return settings.get("anthropic_api_key") or _env("ANTHROPIC_API_KEY")


def get_gemini_key(settings=None):
    settings = settings or load_settings()
    return settings.get("gemini_api_key") or _env("GEMINI_API_KEY") or _env("GOOGLE_API_KEY")


def get_fal_key(settings=None):
    settings = settings or load_settings()
    return settings.get("fal_api_key") or _env("FAL_KEY")
