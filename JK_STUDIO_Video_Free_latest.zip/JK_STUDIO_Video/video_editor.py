# -*- coding: utf-8 -*-
"""
JK STUDIO 영상 스튜디오 - 최종 영상 편집 (MoviePy 2.x)
- 씬 순서대로 영상/이미지 클립 배치 (이미지는 켄번스 줌·팬 모션)
- edge_tts 한국어 내레이션 자동 생성 → 씬 길이 자동 맞춤
- 자막, 페이드 전환, 배경음악(BGM) 루프·볼륨·페이드아웃
"""
import os
import re
import asyncio
import hashlib

import proglog
from moviepy import (VideoFileClip, ImageClip, AudioFileClip, TextClip, ColorClip,
                     CompositeVideoClip, CompositeAudioClip, concatenate_videoclips, vfx, afx)

import config

FADE = 0.35  # 씬 사이 페이드(초)


class _ProgressLogger(proglog.ProgressBarLogger):
    """MoviePy 인코딩 진행률을 콜백으로 전달"""
    def __init__(self, cb):
        super().__init__()
        self.cb = cb
        self._last = -1

    def bars_callback(self, bar, attr, value, old_value=None):
        if attr != "index" or bar not in ("frame_index", "t"):
            return
        total = self.bars[bar].get("total") or 1
        pct = int(value / total * 100)
        if pct != self._last and pct % 2 == 0:
            self._last = pct
            self.cb(f"인코딩 {pct}%", 60 + pct * 0.4)


# ── 내레이션 ──────────────────────────────────────────────
def _voicebox_launch(settings):
    """Voicebox GPU(CUDA) 서버를 직접 창 없이 실행 (없으면 앱 실행 파일)"""
    import subprocess
    data = os.path.join(os.environ.get("APPDATA", ""), "sh.voicebox.app")
    cuda = os.path.join(data, "backends", "cuda", "voicebox-server-cuda.exe")
    port = settings.get("voicebox_url", "http://127.0.0.1:17493").rstrip("/").rsplit(":", 1)[-1]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
    log = open(os.path.join(config.BASE_DIR, "logs", "voicebox_cuda.log"), "ab")
    if os.path.exists(cuda):
        subprocess.Popen([cuda, "--data-dir", data, "--port", port], stdout=log, stderr=log, creationflags=flags)
    else:
        subprocess.Popen([settings.get("voicebox_exe", r"C:\Program Files\Voicebox\voicebox.exe")], creationflags=flags)


def _voicebox_ensure(base, settings, profile):
    """Voicebox 가 GPU 모드 + 프로필 있는 상태인지 확인, 아니면 끄고 GPU 서버로 다시 실행"""
    import time
    import requests

    def ok():
        try:
            h = requests.get(f"{base}/health", timeout=3).json()
            names = [p.get("name") for p in requests.get(f"{base}/profiles", timeout=5).json()]
            return h.get("gpu_available") and profile in names
        except Exception:
            return None   # 꺼져 있음

    state = ok()
    if state:
        return
    if state is not None:   # 켜져 있지만 CPU 모드이거나 프로필이 안 보임 → 종료 후 재실행
        try:
            requests.post(f"{base}/shutdown", timeout=5)
        except Exception:
            pass
        time.sleep(3)
    _voicebox_launch(settings)
    for _ in range(40):
        time.sleep(3)
        if ok():
            return
    raise RuntimeError("Voicebox GPU 서버가 준비되지 않았습니다 (프로필 확인 필요)")


def _voicebox_tts(text, settings):
    """Voicebox 로컬 서버(내 목소리 클론, Qwen3-TTS)로 wav 생성 (같은 문장·설정은 캐시 재사용)"""
    import time
    import requests
    base = settings.get("voicebox_url", "http://127.0.0.1:17493").rstrip("/")
    profile = settings.get("voicebox_profile", "내 목소리")
    instruct = settings.get("voicebox_instruct", "")
    key = hashlib.md5(f"vb2|{profile}|{instruct}|{text}".encode("utf-8")).hexdigest()[:16]   # vb2: 말끝 잘림 보정판
    path = os.path.join(config.OUTPUT_DIR, "tts", f"{key}.wav")
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return path
    _voicebox_ensure(base, settings, profile)
    # 프로필 이름 → id
    pid = profile
    profiles = requests.get(f"{base}/profiles", timeout=10).json()
    for p in profiles:
        if p.get("name") == profile or p.get("id") == profile:
            pid = p["id"]
            break
    else:
        raise RuntimeError(f"Voicebox 프로필 '{profile}' 없음")
    # Qwen3-TTS 는 문장 끝을 다 말하기 전에 멈추는 경우가 있어 끝에 쉼 부호를 덧붙임 (실측: 여백 0.08초 → 0.48초)
    body = {"profile_id": pid, "text": text.rstrip() + " . . .", "language": "ko"}
    if instruct:
        body["instruct"] = instruct
    g = requests.post(f"{base}/generate", json=body, timeout=120).json()
    gid = g["id"]
    t0 = time.time()
    while g.get("status") not in ("completed", "failed", "error"):
        if time.time() - t0 > 300:
            raise TimeoutError("Voicebox 생성 시간 초과")
        time.sleep(2)
        g = requests.get(f"{base}/history/{gid}", timeout=10).json()
    if g.get("status") != "completed":
        raise RuntimeError(f"Voicebox 실패: {g.get('error')}")
    r = requests.get(f"{base}/audio/{gid}", timeout=60)
    r.raise_for_status()
    with open(path, "wb") as f:
        f.write(r.content)
    _trim_tail(path, keep=0.35)
    return path


def _trim_tail(path, keep=0.35):
    """wav 끝의 긴 무음을 keep 초만 남기고 잘라냄 (말끝은 보존)"""
    try:
        import wave
        import numpy as np
        with wave.open(path, "rb") as w:
            params = w.getparams()
            raw = w.readframes(w.getnframes())
        if params.sampwidth != 2:
            return
        a = np.frombuffer(raw, dtype=np.int16).reshape(-1, params.nchannels)
        mono = np.abs(a.astype(np.float32)).mean(axis=1)
        sr, win = params.framerate, max(1, int(params.framerate * 0.02))
        rms = np.array([np.sqrt((mono[i:i + win] ** 2).mean()) for i in range(0, len(mono) - win, win)])
        if not len(rms):
            return
        voiced = np.where(rms > rms.max() * 0.04)[0]
        end = min(len(a), (int(voiced[-1]) + 1) * win + int(sr * keep))
        if end < len(a) - int(sr * 0.05):
            with wave.open(path, "wb") as w:
                w.setparams(params)
                w.writeframes(a[:end].tobytes())
    except Exception:
        pass


def _prep_bgm(path):
    """BGM 다듬기 (캐시): 끝의 무음 제거 + 조용한 구간 음량 보정 → 루프해도 빈 곳이 없게"""
    try:
        import subprocess
        import imageio_ffmpeg
        out = os.path.splitext(path)[0] + "_prep.mp3"
        if os.path.exists(out) and os.path.getmtime(out) >= os.path.getmtime(path):
            return out
        ff = imageio_ffmpeg.get_ffmpeg_exe()
        af = ("areverse,silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.3,areverse,"
              "dynaudnorm=f=250:g=15:m=6,afade=t=in:d=0.3")
        subprocess.run([ff, "-y", "-v", "error", "-i", path, "-af", af, "-b:a", "192k", out],
                       check=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return out if os.path.getsize(out) > 1000 else path
    except Exception:
        return path


def make_tts(text, voice, rate, settings=None, cb=None):
    """내레이션 생성: tts_engine 이 voicebox 면 내 목소리, 실패하거나 edge 면 edge-tts"""
    settings = settings or {}
    if settings.get("tts_engine", "voicebox") == "voicebox":
        try:
            return _voicebox_tts(text, settings)
        except Exception as e:
            if cb:
                cb(f"⚠ Voicebox 실패 → edge-tts 로 대체 ({e})", None)
    import edge_tts
    key = hashlib.md5(f"{voice}|{rate}|{text}".encode("utf-8")).hexdigest()[:16]
    path = os.path.join(config.OUTPUT_DIR, "tts", f"{key}.mp3")
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        async def _run():
            await edge_tts.Communicate(text, voice, rate=rate).save(path)
        asyncio.run(_run())
    return path


# ── 화면 맞춤 ─────────────────────────────────────────────
def _cover(clip, W, H):
    """화면을 꽉 채우도록 확대 후 가운데 자르기"""
    s = max(W / clip.w, H / clip.h)
    c = clip.resized(s)
    return c.cropped(x_center=c.w / 2, y_center=c.h / 2, width=W, height=H)


def _image_clip(path, W, H, dur, motion):
    """이미지 → 켄번스 모션 클립"""
    img = ImageClip(path)
    s0 = max(W / img.w, H / img.h)
    if motion == "static":
        return _cover(img, W, H).with_duration(dur)
    if motion in ("zoom_in", "zoom_out"):
        z = 0.12
        if motion == "zoom_in":
            f = lambda t: s0 * (1 + z * t / dur)
        else:
            f = lambda t: s0 * (1 + z * (1 - t / dur))
        moving = img.resized(f).with_duration(dur).with_position("center")
        return CompositeVideoClip([moving], size=(W, H)).with_duration(dur)
    # 좌우 팬: 18% 확대 후 가로 이동
    s = s0 * 1.18
    big = img.resized(s)
    over = max(0, big.w - W)
    y = -(big.h - H) / 2
    if motion == "pan_left":
        pos = lambda t: (-over * (t / dur), y)
    else:
        pos = lambda t: (-over * (1 - t / dur), y)
    return CompositeVideoClip([big.with_duration(dur).with_position(pos)], size=(W, H)).with_duration(dur)


def _video_clip(path, W, H, dur, keep_audio=False):
    """영상 클립 → 길이 맞춤 (짧으면 반복, 길면 자르기)"""
    v = VideoFileClip(path)
    if not keep_audio:
        v = v.without_audio()
    if v.duration < dur - 0.05:
        v = v.with_effects([vfx.Loop(duration=dur)])
    else:
        v = v.subclipped(0, dur)
    return _cover(v, W, H).with_duration(dur)


def _subtitle(text, W, H, dur, font):
    """하단 자막 클립"""
    txt = TextClip(font=font, text=text, font_size=max(28, int(H * 0.042)), color="white",
                   stroke_color="black", stroke_width=3, method="caption",
                   size=(int(W * 0.84), None), text_align="center",
                   margin=(10, 20))  # 여백을 줘서 받침/테두리 잘림 방지
    y = max(0, int(H * 0.93) - txt.h)  # 자막 아래 끝을 화면 93% 지점에 맞춤
    return txt.with_duration(dur).with_position(("center", y))


# ── 렌더 본체 ─────────────────────────────────────────────
def render_project(scenes, opts, settings, out_path, url_to_path, cb=lambda m, p=None: None):
    """
    scenes : 순서대로 정렬된 씬 리스트
    opts   : {width, height, fps, narration, subtitles, bgm, bgm_volume}
    """
    W, H = int(opts.get("width", 1920)), int(opts.get("height", 1080))
    fps = int(opts.get("fps", 24))
    use_tts = bool(opts.get("narration", True))
    use_sub = bool(opts.get("subtitles", True))
    font = settings.get("font_path", "")
    if use_sub and not (font and os.path.exists(font)):
        cb(f"⚠ 자막 폰트 없음({font}) → 자막 생략", 2)
        use_sub = False

    clips, audio_tracks, opened = [], [], []
    t_cursor = 0.0
    n = len(scenes)
    if n == 0:
        raise ValueError("렌더할 씬이 없습니다")

    for i, sc in enumerate(scenes):
        cb(f"씬 {i + 1}/{n} 준비: {sc.get('title', '')}", 5 + i / n * 50)
        dur = float(sc.get("duration") or 5)

        # 1) 내레이션
        narr = None
        text = (sc.get("narration") or "").strip()
        vpath0 = url_to_path(sc.get("video")) if sc.get("video") else None
        talk = bool(sc.get("videoHasAudio") and vpath0 and os.path.exists(vpath0))
        if talk:
            # 🗣 대화 영상: 영상 자체에 대사·효과음이 있음 → TTS 생략, 영상 길이만큼 사용
            try:
                probe = VideoFileClip(vpath0); dur = max(1.0, probe.duration); probe.close()
            except Exception:
                pass
            if sc.get("dialogue"):
                # 자막: 대사 전체를 "이름: 대사" 줄 그대로 (여러 줄)
                text = "\n".join(l.strip() for l in sc["dialogue"].strip().splitlines() if l.strip())
        if use_tts and text and not talk:
            try:
                mp3 = make_tts(text, settings.get("tts_voice"), settings.get("tts_rate", "+0%"), settings, cb)
                narr = AudioFileClip(mp3)
                opened.append(narr)
                dur = max(dur, narr.duration + 0.6)  # 내레이션보다 짧지 않게
            except Exception as e:
                cb(f"⚠ 씬 {i + 1} 내레이션 실패: {e}", None)

        # 2) 영상 > 이미지 > 빈 화면 순서로 소스 선택
        vpath = url_to_path(sc.get("video")) if sc.get("video") else None
        ipath = url_to_path(sc.get("image")) if sc.get("image") else None
        if vpath and os.path.exists(vpath):
            clip = _video_clip(vpath, W, H, dur, keep_audio=talk)
            if talk and clip.audio is not None:
                audio_tracks.append(clip.audio.with_start(t_cursor))
                clip = clip.without_audio()
        elif ipath and os.path.exists(ipath):
            clip = _image_clip(ipath, W, H, dur, sc.get("motion", "zoom_in"))
        else:
            clip = ColorClip((W, H), color=(8, 8, 14)).with_duration(dur)

        # 3) 자막
        if use_sub and text:
            try:
                clip = CompositeVideoClip([clip, _subtitle(text, W, H, dur, font)], size=(W, H)).with_duration(dur)
            except Exception as e:
                cb(f"⚠ 자막 실패: {e}", None)

        # 4) 페이드 전환
        clip = clip.with_effects([vfx.FadeIn(FADE), vfx.FadeOut(FADE)])
        clips.append(clip)
        if narr is not None:
            audio_tracks.append(narr.with_start(t_cursor + 0.3))
        t_cursor += dur

    cb("클립 이어붙이는 중…", 57)
    final = concatenate_videoclips(clips, method="chain")
    total = final.duration

    # 5) 배경음악
    bgm_url = opts.get("bgm")
    if bgm_url:
        bpath = url_to_path(bgm_url)
        if bpath and os.path.exists(bpath):
            vol = float(opts.get("bgm_volume", 0.25))
            bgm = AudioFileClip(_prep_bgm(bpath))
            opened.append(bgm)
            bgm = bgm.with_effects([afx.AudioLoop(duration=total), afx.MultiplyVolume(vol),
                                    afx.AudioFadeOut(min(2.5, total / 3))])
            audio_tracks.insert(0, bgm)

    if audio_tracks:
        final = final.with_audio(CompositeAudioClip(audio_tracks).with_duration(total))

    cb("MP4 인코딩 시작…", 60)
    final.write_videofile(out_path, fps=fps, codec="libx264", audio_codec="aac",
                          preset="medium", threads=4, ffmpeg_params=["-crf", "18", "-pix_fmt", "yuv420p"],
                          logger=_ProgressLogger(cb))

    # 정리
    for c in clips + opened:
        try:
            c.close()
        except Exception:
            pass
    final.close()
    cb("렌더 완료", 100)
    return out_path
