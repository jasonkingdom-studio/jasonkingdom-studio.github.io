@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist venv\Scripts\python.exe call "설치.bat"
set PYTHONIOENCODING=utf-8
echo JK STUDIO 영상 스튜디오 시작 중... (ComfyUI 가 127.0.0.1:8188 에서 켜져 있어야 합니다)
start "" http://127.0.0.1:5077
venv\Scripts\python.exe app.py
pause
