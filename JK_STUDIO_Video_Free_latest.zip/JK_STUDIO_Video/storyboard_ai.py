# -*- coding: utf-8 -*-
"""
JK STUDIO 영상 스튜디오 v2.1 - AI 작가 · 스토리보드 감독
  1) 스토리/아이디어 → 대본(장면별 화면 묘사 + 내레이션/대사) 작성
  2) 대본 → 씬(컷) 분할 + 등장인물 캐스팅 + 영어 이미지 프롬프트 + 카메라 연출
LLM 순서: Claude API → Gemini API → 로컬 Ollama(gemma4 등) → (모두 실패 시) 문장 기본 분할
"""
import json
import re
import requests

import config

# ════════════════ LLM 공통 호출 ════════════════
def _claude(system, user, settings, max_tokens):
    import anthropic
    key = config.get_api_key(settings)
    if not key:
        raise RuntimeError("Claude API 키 없음")
    client = anthropic.Anthropic(api_key=key)
    resp = client.messages.create(model=settings.get("claude_model", "claude-sonnet-5"), max_tokens=max_tokens,
                                  system=system, messages=[{"role": "user", "content": user}])
    return "".join(getattr(b, "text", "") for b in resp.content)


def _gemini(system, user, settings, max_tokens):
    key = config.get_gemini_key(settings)
    if not key:
        raise RuntimeError("Gemini API 키 없음")
    model = settings.get("gemini_model", "gemini-2.5-flash")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    body = {"systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {"maxOutputTokens": max_tokens, "temperature": 0.8}}
    r = requests.post(url, json=body, timeout=180)
    r.raise_for_status()
    parts = r.json()["candidates"][0]["content"]["parts"]
    return "".join(p.get("text", "") for p in parts)


def _ollama(system, user, settings, max_tokens):
    base = settings.get("ollama_url", "http://127.0.0.1:11434").rstrip("/")
    model = settings.get("ollama_model", "gemma4:31b")
    r = requests.post(f"{base}/api/chat", timeout=600, json={
        "model": model, "stream": False,
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        "keep_alive": 0,   # 끝나면 바로 VRAM 반환 (영상 생성과 충돌 방지)
        "options": {"num_ctx": 16384, "num_predict": max_tokens, "temperature": 0.8}})
    r.raise_for_status()
    return r.json()["message"]["content"]


PROVIDERS = [("claude", "Claude", _claude), ("gemini", "Gemini", _gemini), ("ollama", "로컬 Ollama", _ollama)]


def llm(system, user, settings, max_tokens=8000):
    """설정된 순서대로 시도 → (텍스트, 사용한 엔진 이름, 실패 기록)"""
    order = [p.strip() for p in settings.get("llm_order", "claude,gemini,ollama").split(",") if p.strip()]
    errors = []
    for key, name, fn in PROVIDERS:
        if key not in order:
            continue
        try:
            text = fn(system, user, settings, max_tokens)
            if text and text.strip():
                return text, name, errors
            errors.append(f"{name}: 빈 응답")
        except Exception as e:
            errors.append(f"{name}: {str(e)[:120]}")
    raise RuntimeError(" / ".join(errors) or "사용 가능한 AI 엔진 없음")


# ════════════════ 1) 대본 작성 ════════════════
SCRIPT_SYSTEM = """당신은 한국의 영상 대본 작가이자 시네마틱 AI 영상 연출가입니다.
사용자가 준 스토리/아이디어를 촬영 가능한 영상 대본으로 완성하세요.

형식(반드시 지키기):
#제목: (영상 제목)
#등장인물: 이름 - 외모·나이·의상 한 줄 묘사 (주요 인물만, 최대 4명)

[S#1] 장소 / 시간 / 분위기
화면: 무엇이 보이는지 구체적으로 (인물 동작, 배경, 조명, 카메라 구도·움직임)
내레이션: 한국어 내레이션 1~2문장 (없으면 생략)
대사: 인물이름: "대사" (없으면 생략)

[S#2] ...

규칙:
- 요청한 컷 수에 맞춰 [S#] 개수를 정확히 맞추기
- 각 컷은 4~8초 분량, 한 컷에 한 가지 핵심 동작
- 기승전결이 있게, 첫 컷은 강한 훅, 마지막 컷은 여운
- 빠른 회전·격렬한 동작보다 느리고 우아한 움직임 위주 (AI 영상 품질을 위해)
- 대본 외의 설명·인사말 금지"""


def _parse_n(n_scenes):
    """컷 수: 숫자면 1~40, '자동'/0/빈값이면 None(내용에 맞게)"""
    try:
        n = int(float(n_scenes))
    except (TypeError, ValueError):
        return None
    return max(1, min(n, 40)) if n > 0 else None


def write_script(story, n_scenes, style, tone, settings):
    """스토리 → 대본 텍스트"""
    n = _parse_n(n_scenes)
    n_txt = n if n else "자동 (내용에 맞게 3~12컷 사이에서 결정)"
    user = (f"컷 수: {n_txt}\n영상 스타일: {style or '(자유)'}\n톤/분위기: {tone or '(자유)'}\n\n"
            f"스토리/아이디어:\n{story}")
    text, provider, errors = llm(SCRIPT_SYSTEM, user, settings, 6000)
    text = re.sub(r"^```\w*\s*|\s*```$", "", text.strip())
    n_cuts = len(re.findall(r"\[S#", text))
    note = f"{provider}가 대본 작성 완료 ({n_cuts}컷)"
    if errors:
        note += f" · 대체 사용 ({'; '.join(errors)})"
    return {"script": text, "provider": provider, "note": note}


# ════════════════ 2) 씬 분할 + 캐스팅 ════════════════
BOARD_SYSTEM = """당신은 시네마틱 AI 영상 스토리보드 감독이자 캐스팅 디렉터입니다.
주어진 대본(또는 아이디어)을 분석해 반드시 아래 JSON 객체 하나만 출력하세요. 설명 문장·코드블록 금지.
{
  "title": "영상 제목",
  "characters": [
    {"name": "한국어 이름", "description": "English visual description for image models: age, gender, ethnicity, face, hairstyle, outfit, props (30~50 words)"}
  ],
  "scenes": [
    {
      "title": "짧은 한국어 컷 제목",
      "prompt": "English image prompt: subject & action, environment, lighting, lens, composition, mood (40~70 words). Mention characters by name only, not their appearance",
      "negative": "",
      "narration": "이 컷의 한국어 내레이션 (화면 밖 해설, 대본 그대로, 없으면 빈 문자열)",
      "dialogue": "화면 속 인물의 대사. 한 줄에 한 명씩 '이름: 대사' 형식 (대본 그대로, 없으면 빈 문자열)",
      "camera": "English camera movement for the video model (e.g. slow dolly in, gentle orbit left)",
      "motion": "zoom_in | zoom_out | pan_left | pan_right | static",
      "duration": 4~8 사이 숫자 (내레이션 길이를 고려),
      "characters": ["이 컷에 나오는 캐릭터 이름"]
    }
  ]
}
규칙: 대본에 [S#]가 있으면 그 개수·순서 그대로 씬을 만들고, 없으면 요청한 컷 수로 나누세요.
스타일 지정이 있으면 모든 prompt 끝에 반영하세요. 움직임은 느리고 우아하게 묘사하세요."""

MOTIONS = {"zoom_in", "zoom_out", "pan_left", "pan_right", "static"}


def _extract_json(text):
    text = re.sub(r"```(?:json)?", "", text)
    s, e = text.find("{"), text.rfind("}")
    if s >= 0 and e > s:
        try:
            return json.loads(text[s:e + 1])
        except json.JSONDecodeError:
            # 흔한 오류(끝의 쉼표) 보정 후 재시도
            return json.loads(re.sub(r",\s*([}\]])", r"\1", text[s:e + 1]))
    s, e = text.find("["), text.rfind("]")
    if s >= 0 and e > s:
        return {"characters": [], "scenes": json.loads(text[s:e + 1])}
    raise ValueError("응답에서 JSON 을 찾지 못했습니다")


def _clean_narration(text):
    """내레이션/대사 정리: '소녀: "대사"' → '대사' (TTS가 화자 이름·따옴표를 읽지 않도록)"""
    text = str(text or "").strip()
    m = re.match(r'^\s*(?:대사\s*[:：]\s*)?([^\s:："“]{1,12})\s*[:：]\s*(.+)$', text, re.S)
    if m and m.group(1) not in ("내레이션", "나레이션", "NA"):
        text = m.group(2)
    text = re.sub(r'^\s*(?:내레이션|나레이션|NA)\s*[:：]\s*', "", text)
    return text.strip().strip('"“”\'').strip()


def _normalize(scene):
    try:
        dur = float(scene.get("duration", 5))
    except (TypeError, ValueError):
        dur = 5.0
    motion = str(scene.get("motion", "zoom_in")).strip()
    return {
        "title": str(scene.get("title", "새 컷"))[:40],
        "prompt": str(scene.get("prompt", "")).strip(),
        "negative": str(scene.get("negative", "")).strip(),
        "narration": _clean_narration(scene.get("narration", "")),
        "dialogue": "\n".join(l.strip() for l in str(scene.get("dialogue", "") or "").splitlines() if l.strip()),
        "camera": str(scene.get("camera", "")).strip(),
        "motion": motion if motion in MOTIONS else "zoom_in",
        "duration": max(2.0, min(15.0, dur)),
        "characterNames": [str(n) for n in scene.get("characters", []) if n],
    }


# 사용자가 직접 쓴 스토리보드의 씬 구분 표시 (줄 맨 앞)
#   [S#1]  S#1  S1.  씬1  신 2  장면 3  컷4  #5  Scene 6  Cut 7  1.  2)  ①  [1]
_SCENE_MARK = re.compile(
    r"^[ \t]*(?:"
    r"\[?\s*(?:S\s*#?|씬|신|장면|컷|scene|cut|shot|샷|#)\s*\d{1,2}\s*\]?(?:\s*[.):\-–—]|\s|$)"
    r"|\[\s*\d{1,2}\s*\]"
    r"|\d{1,2}\s*(?:[.)]|컷|번)(?=\s)"
    r"|[①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳]"
    r")", re.IGNORECASE | re.MULTILINE)


def detect_scenes(text):
    """이미 씬이 나뉜 스토리보드면 씬별 텍스트 목록, 아니면 []"""
    text = (text or "").replace("\r\n", "\n")
    marks = [m.start() for m in _SCENE_MARK.finditer(text)]
    if len(marks) < 2:
        # 빈 줄로 나뉜 문단이 3개 이상이고 충분히 길면 문단 = 씬
        paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
        if len(paras) >= 3 and len(text) >= 200 and not paras[0].startswith("#"):
            return paras[:40]
        return []
    blocks = []
    for i, s in enumerate(marks):
        e = marks[i + 1] if i + 1 < len(marks) else len(text)
        b = text[s:e].strip()
        if b:
            blocks.append(b)
    return blocks[:40]


def auto_board(text, n_scenes, style, tone, settings):
    """⚡ 자동: 스토리보드(씬 표시 있음)·긴 글이면 바로 씬 분할, 짧은 아이디어면 대본 먼저 쓰고 분할"""
    blocks = detect_scenes(text)
    script, script_note = None, ""
    if len(blocks) >= 2:
        mode = f"스토리보드 인식: {len(blocks)}컷 그대로 분할"
    elif len(text) >= 600:
        mode = "긴 글 → AI가 흐름대로 분할"
    else:
        r = write_script(text, n_scenes, style, tone, settings)
        script, script_note = r["script"], r["note"]
        text = script
        mode = "아이디어 → 대본 작성 후 분할"
    board = generate_storyboard(text, n_scenes, style, settings)
    board["script"] = script
    board["route"] = mode
    board["note"] = f"{mode} · {board['note']}" + (f" · {script_note}" if script_note else "")
    return board


def _basic_storyboard(script, n_scenes, style):
    """AI 엔진이 모두 실패했을 때: 사용자 씬 표시 → [S#] → 문장 단위로 분할"""
    blocks = detect_scenes(script)
    if len(blocks) < 2:
        parts = re.split(r"\[S#\d+\]", script)
        blocks = [b.strip() for b in parts[1:] if b.strip()]   # 첫 조각(제목·등장인물 머리말)은 제외
    if len(blocks) < 2:
        n_scenes = n_scenes or 6
        blocks = [s.strip() for s in re.split(r"(?<=[.!?。…])\s+|\n+", script) if s.strip()] or ["새 장면"]
        n = max(1, min(n_scenes, len(blocks)))
        size = len(blocks) / n
        blocks = [" ".join(blocks[int(i * size):int((i + 1) * size)]) for i in range(n)]
    motions = ["zoom_in", "pan_right", "zoom_out", "pan_left"]
    scenes = []
    for i, b in enumerate(blocks):
        b = _SCENE_MARK.sub("", b, count=1).strip(" .:)-\n")
        narr = re.search(r"내레이션\s*:\s*(.+)", b)
        scenes.append({"title": f"컷 {i + 1}", "prompt": f"cinematic film still, {b[:200]}" + (f", {style}" if style else ""),
                       "negative": "", "narration": narr.group(1).strip() if narr else b[:80],
                       "camera": "slow dolly in", "motion": motions[i % 4], "duration": 5.0, "characterNames": []})
    return scenes


def generate_storyboard(script, n_scenes, style, settings, api_key=None):
    """대본/아이디어 → {"title","characters","scenes","mode","note"}"""
    blocks = detect_scenes(script)
    n = len(blocks) if len(blocks) >= 2 else (_parse_n(n_scenes) or 0)
    if len(blocks) >= 2:
        # 사용자가 이미 씬을 나눠 둔 경우: 그 개수·순서·내레이션을 그대로 보존
        numbered = "\n\n".join(f"[S#{i + 1}]\n{b}" for i, b in enumerate(blocks))
        user = (f"컷 수: 정확히 {n} (사용자가 나눈 씬 그대로, 합치거나 쪼개지 말 것)\n"
                f"스타일: {style or '(자유)'}\n"
                "내레이션/대사는 사용자 원문을 그대로 쓰고 새로 지어내지 마세요.\n\n"
                f"사용자 스토리보드:\n{numbered}")
        head = script[:script.find(blocks[0][:20])] if blocks[0][:20] in script else ""
        if head.strip():
            user += f"\n\n(머리말/등장인물 참고)\n{head.strip()[:1500]}"
    else:
        n_txt = n if n else "자동 (내용 흐름에 맞게 3~12컷)"
        user = f"컷 수: {n_txt}\n스타일: {style or '(자유)'}\n\n대본/아이디어:\n{script}"
    n_scenes = n or 6
    try:
        text, provider, errors = llm(BOARD_SYSTEM, user, settings, 12000)
        data = _extract_json(text)
        chars = [{"name": str(c.get("name", "")).strip(), "description": str(c.get("description", "")).strip()}
                 for c in data.get("characters", []) if c.get("name")]
        scenes = [_normalize(s) for s in data.get("scenes", [])]
        if not scenes:
            raise ValueError("씬이 비어 있음")
        warn = ""
        if len(blocks) >= 2:
            # 원문 내레이션 보존: AI가 비워 둔 곳은 원문의 '내레이션:/대사:' 줄로 채움
            for sc, b in zip(scenes, blocks):
                if not sc["narration"]:
                    m = re.search(r"(?:내레이션|나레이션|NA|N\.A|대사)\s*[:：]\s*(.+)", b)
                    if m:
                        sc["narration"] = _clean_narration(m.group(1))
            if len(scenes) != len(blocks):
                warn = f" · ⚠ 원본 {len(blocks)}컷과 개수 다름"
        note = f"{provider} 스토리보드 완료 · {len(scenes)}컷 · 캐릭터 {len(chars)}명 캐스팅{warn}"
        if errors:
            note += f" (대체 사용: {'; '.join(errors)})"
        return {"title": data.get("title", ""), "characters": chars, "scenes": scenes, "mode": provider, "note": note}
    except Exception as e:
        return {"title": "", "characters": [], "scenes": _basic_storyboard(script, n_scenes, style), "mode": "basic",
                "note": f"⚠ AI 엔진 사용 불가 → 기본 분할 ({str(e)[:200]})"}
