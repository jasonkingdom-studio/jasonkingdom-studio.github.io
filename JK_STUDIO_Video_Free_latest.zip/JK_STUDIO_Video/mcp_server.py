# -*- coding: utf-8 -*-
"""
JK STUDIO 영상 스튜디오 v2 - MCP 서버 (AI 에이전트용)
Claude Desktop / Claude Code 가 스튜디오를 직접 조작:
  대본 → 프로젝트 생성(캐스팅 포함) → 캐릭터 이미지/시트 → 씬 이미지 → 라이트/멀티뷰 → 영상(오토링크) → 렌더

사용 전 app.py 가 실행 중이어야 합니다 (http://127.0.0.1:5077).
등록 예)
  Claude Code : claude mcp add jk-studio -- python C:\\JK_STUDIO_Video\\mcp_server.py
  Claude Desktop (claude_desktop_config.json):
    "jk-studio": {"command": "python", "args": ["C:\\\\JK_STUDIO_Video\\\\mcp_server.py"]}
"""
import os
import time
import uuid
import requests
from mcp.server.fastmcp import FastMCP

BASE = os.environ.get("JK_STUDIO_URL", "http://127.0.0.1:5077")
mcp = FastMCP("jk-studio-video")


# ── 내부 도우미 ──────────────────────────────────────────
def _get(path):
    r = requests.get(BASE + path, timeout=60)
    r.raise_for_status()
    return r.json()


def _post(path, body):
    r = requests.post(BASE + path, json=body, timeout=300)
    if r.status_code >= 400:
        raise RuntimeError(r.json().get("error", r.text[:300]) if r.headers.get("content-type", "").startswith("application/json") else r.text[:300])
    return r.json()


def _order(p):
    """씬 연결(edges) 순서 — 프론트엔드 computeOrder 와 같은 규칙"""
    scenes = p.get("scenes", [])
    ids = {s["id"] for s in scenes}
    nxt, has_in = {}, set()
    for e in p.get("edges", []):
        if e["from"] in ids and e["to"] in ids:
            nxt[e["from"]] = e["to"]
            has_in.add(e["to"])
    heads = sorted([s for s in scenes if s["id"] not in has_in], key=lambda s: (s.get("x", 0), s.get("y", 0)))
    order, seen = [], set()
    for h in heads:
        cur = h["id"]
        while cur and cur not in seen:
            seen.add(cur)
            order.append(cur)
            cur = nxt.get(cur)
    order += [s["id"] for s in sorted(scenes, key=lambda s: s.get("x", 0)) if s["id"] not in seen]
    return order


def _load(name):
    p = _get(f"/api/projects/{name}")
    p.pop("_mtime", None)
    return p


def _save(name, p):
    return _post(f"/api/projects/{name}", p)


def _scene_at(p, index):
    order = _order(p)
    if not 1 <= index <= len(order):
        raise ValueError(f"씬 번호는 1~{len(order)} 사이여야 합니다")
    sid = order[index - 1]
    return next(s for s in p["scenes"] if s["id"] == sid)


def _char_by_name(p, name):
    for c in p.get("characters", []):
        if c["name"] == name:
            return c
    raise ValueError(f"캐릭터 '{name}' 없음. 목록: {[c['name'] for c in p.get('characters', [])]}")


def _new_scene(**kw):
    s = {"id": "s" + uuid.uuid4().hex[:7], "title": "새 컷", "prompt": "", "negative": "", "narration": "",
         "camera": "", "duration": 5, "seed": -1, "motion": "zoom_in", "x": 0, "y": 0, "image": None,
         "video": None, "depth": None, "useDepth": False, "stage": None, "characters": [], "refs": [],
         "variants": [], "videoHistory": [], "engine": "comfy", "layers": None}
    s.update(kw)
    return s


def _wait(job_id, timeout=1800):
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = _get(f"/api/jobs/{job_id}")
        if j["status"] in ("done", "error"):
            return j
        time.sleep(3)
    return {"status": "timeout", "id": job_id}


def _summary(p):
    order = _order(p)
    by = {s["id"]: s for s in p.get("scenes", [])}
    cmap = {c["id"]: c["name"] for c in p.get("characters", [])}
    return {
        "name": p.get("name"), "globalStyle": p.get("globalStyle", ""),
        "characters": [{"name": c["name"], "description": c.get("description", ""),
                        "refs": len(c.get("refs", [])), "sheet": bool(c.get("sheet"))} for c in p.get("characters", [])],
        "scenes": [{"index": i + 1, "title": by[sid]["title"], "prompt": by[sid]["prompt"][:160],
                    "narration": by[sid].get("narration", ""), "duration": by[sid].get("duration"),
                    "characters": [cmap.get(c, "?") for c in by[sid].get("characters", [])],
                    "image": by[sid].get("image"), "video": by[sid].get("video")} for i, sid in enumerate(order)],
        "lastRender": p.get("lastRender"),
    }


def _job_body(p, sc, **extra):
    return {"project": p["name"], "persist": True, "scene": sc, "characters": p.get("characters", []),
            "globalStyle": p.get("globalStyle", ""), "artStyle": p.get("artStyle", "real"),
            "label": extra.pop("label", sc.get("title", "")), **extra}


# ── MCP 도구 ─────────────────────────────────────────────
@mcp.tool()
def studio_status() -> dict:
    """스튜디오/ComfyUI/Claude/fal 연결 상태 확인"""
    return _get("/api/status")


@mcp.tool()
def list_projects() -> list:
    """저장된 프로젝트 목록"""
    return _get("/api/projects")


@mcp.tool()
def get_project(name: str) -> dict:
    """프로젝트 요약 (캐릭터, 순서대로 정렬된 씬, 이미지/영상 유무)"""
    return _summary(_load(name))


@mcp.tool()
def create_project(name: str, script: str, n_scenes: int = 0, style: str = "", global_style: str = "",
                   tone: str = "", art_style: str = "real") -> dict:
    """아이디어·스토리보드·대본으로 새 프로젝트 생성 (자동 씬 나누기 + 캐스팅 + 씬 연결).
    script 에 씬 표시(S#1, 씬1, 1. 등)가 있으면 그대로 나누고, 짧은 아이디어면 대본부터 씀. n_scenes 0 = 자동"""
    if art_style == "anime":
        style = "2D anime illustration, cel shading. " + (style or "")
    sb = _post("/api/autoboard", {"text": script, "n": n_scenes, "style": style, "tone": tone})
    chars = [{"id": "c" + uuid.uuid4().hex[:7], "name": c["name"], "description": c["description"],
              "refs": [], "sheet": None} for c in sb.get("characters", [])]
    name_to_id = {c["name"]: c["id"] for c in chars}
    scenes, edges = [], []
    for i, sc in enumerate(sb["scenes"]):
        names = sc.pop("characterNames", [])
        s = _new_scene(**sc, x=(i % 5) * 310, y=(i // 5) * 360,
                       characters=[name_to_id[n] for n in names if n in name_to_id])
        if scenes:
            edges.append({"from": scenes[-1]["id"], "to": s["id"]})
        scenes.append(s)
    p = {"name": name, "globalStyle": global_style, "characters": chars, "scenes": scenes, "edges": edges,
         "bgm": None, "bgmName": "", "lastRender": None, "story": script, "script": sb.get("script") or "",
         "artStyle": art_style}
    saved = _save(name, p)
    p["name"] = saved["name"]
    return {"note": sb.get("note"), **_summary(p)}


@mcp.tool()
def update_scene(project: str, index: int, title: str = None, prompt: str = None, narration: str = None,
                 camera: str = None, duration: float = None, engine: str = None, motion: str = None) -> dict:
    """씬 수정 (index 는 1부터). engine: comfy|kling|seedance|hailuo, motion: zoom_in|zoom_out|pan_left|pan_right|static"""
    p = _load(project)
    sc = _scene_at(p, index)
    for k, v in dict(title=title, prompt=prompt, narration=narration, camera=camera,
                     duration=duration, engine=engine, motion=motion).items():
        if v is not None:
            sc[k] = v
    _save(project, p)
    return _summary(p)["scenes"][index - 1]


@mcp.tool()
def add_scene(project: str, prompt: str, title: str = "새 컷", narration: str = "", after_index: int = 0) -> dict:
    """씬 추가 (after_index=0 이면 맨 끝)"""
    p = _load(project)
    order = _order(p)
    after = order[after_index - 1] if after_index else (order[-1] if order else None)
    ref = next((s for s in p["scenes"] if s["id"] == after), None)
    s = _new_scene(title=title, prompt=prompt, narration=narration,
                   x=(ref["x"] + 310) if ref else 0, y=ref["y"] if ref else 0)
    p["scenes"].append(s)
    if after:
        nxt = next((e for e in p["edges"] if e["from"] == after), None)
        p["edges"] = [e for e in p["edges"] if e["from"] != after]
        p["edges"].append({"from": after, "to": s["id"]})
        if nxt:
            p["edges"].append({"from": s["id"], "to": nxt["to"]})
    _save(project, p)
    return _summary(p)


@mcp.tool()
def set_global_style(project: str, style: str) -> str:
    """모든 컷 프롬프트 뒤에 붙는 전역 스타일"""
    p = _load(project)
    p["globalStyle"] = style
    _save(project, p)
    return "OK"


@mcp.tool()
def add_character(project: str, name: str, description: str) -> dict:
    """캐스팅에 캐릭터 추가 (description 은 영어 외형 묘사)"""
    p = _load(project)
    c = {"id": "c" + uuid.uuid4().hex[:7], "name": name, "description": description, "refs": [], "sheet": None}
    p.setdefault("characters", []).append(c)
    _save(project, p)
    return c


@mcp.tool()
def set_scene_characters(project: str, index: int, character_names: list[str]) -> dict:
    """씬 출연 캐릭터 지정 → 이미지 생성 시 캐스팅 모드로 얼굴·의상 고정"""
    p = _load(project)
    sc = _scene_at(p, index)
    sc["characters"] = [_char_by_name(p, n)["id"] for n in character_names]
    _save(project, p)
    return _summary(p)["scenes"][index - 1]


@mcp.tool()
def generate_character_image(project: str, character_name: str, wait: bool = True) -> dict:
    """캐릭터 설명으로 캐릭터 이미지 생성 (참조 이미지로 등록)"""
    p = _load(project)
    c = _char_by_name(p, character_name)
    jid = _post("/api/generate/edit", {"project": p["name"], "persist": True, "mode": "portrait", "char_id": c["id"],
                                       "characters": p["characters"], "globalStyle": p.get("globalStyle", ""),
                                       "artStyle": p.get("artStyle", "real"), "label": f"🎭 {c['name']}"})["job_id"]
    return _wait(jid) if wait else {"job_id": jid}


@mcp.tool()
def generate_character_sheet(project: str, character_name: str, wait: bool = True) -> dict:
    """캐릭터 턴어라운드 시트 생성 (정면/측면/후면/얼굴)"""
    p = _load(project)
    c = _char_by_name(p, character_name)
    jid = _post("/api/generate/edit", {"project": p["name"], "persist": True, "mode": "sheet", "char_id": c["id"],
                                       "characters": p["characters"], "globalStyle": p.get("globalStyle", ""),
                                       "artStyle": p.get("artStyle", "real"), "label": f"📋 {c['name']} 시트"})["job_id"]
    return _wait(jid) if wait else {"job_id": jid}


@mcp.tool()
def generate_image(project: str, index: int, mode: str = "auto", wait: bool = True) -> dict:
    """씬 이미지 생성. mode: auto(캐릭터→캐스팅, 깊이맵→ControlNet, 그 외 텍스트) | t2i | depth | character"""
    p = _load(project)
    sc = _scene_at(p, index)
    jid = _post("/api/generate/scene_image", _job_body(p, sc, mode=mode))["job_id"]
    return _wait(jid) if wait else {"job_id": jid}


@mcp.tool()
def apply_cinematic_light(project: str, index: int, light: str = "golden_hour", wait: bool = True) -> dict:
    """씬 이미지 조명 재연출. light: golden_hour|blue_hour|neon|noir|moonlight|candle|studio|overcast|fire|shaman"""
    p = _load(project)
    sc = _scene_at(p, index)
    jid = _post("/api/generate/edit", _job_body(p, sc, mode="light", light=light))["job_id"]
    return _wait(jid) if wait else {"job_id": jid}


@mcp.tool()
def generate_multiview(project: str, index: int, angles: list[str] = None, wait: bool = True) -> dict:
    """같은 장면을 다른 각도로. angles: left45|right45|top|low|close|wide|reverse|ots"""
    p = _load(project)
    sc = _scene_at(p, index)
    jid = _post("/api/generate/edit", _job_body(p, sc, mode="multiview",
                                                angles=angles or ["left45", "right45", "close"]))["job_id"]
    return _wait(jid) if wait else {"job_id": jid}


@mcp.tool()
def generate_video(project: str, index: int, engine: str = "comfy_fast", autolink: bool = False, wait: bool = True) -> dict:
    """씬 영상 생성. engine: comfy|kling|seedance|hailuo. autolink=True 면 이전 씬 영상 끝 프레임에서 이어서 시작"""
    p = _load(project)
    sc = _scene_at(p, index)
    prev = _scene_at(p, index - 1).get("video") if autolink and index > 1 else None
    jid = _post("/api/generate/scene_video", _job_body(p, sc, engine=engine, autolink=bool(prev),
                                                       prev_video=prev))["job_id"]
    return _wait(jid) if wait else {"job_id": jid}


@mcp.tool()
def generate_all(project: str, what: str = "image", engine: str = "comfy", autolink: bool = True,
                 only_missing: bool = True) -> list:
    """전체 씬 순서대로 생성. what: image|video. 영상은 autolink 로 컷끼리 자연스럽게 연결"""
    results = []
    n = len(_order(_load(project)))
    for i in range(1, n + 1):
        sc = _scene_at(_load(project), i)
        if only_missing and sc.get("video" if what == "video" else "image"):
            continue
        r = generate_video(project, i, engine, autolink) if what == "video" else generate_image(project, i)
        results.append({"index": i, "status": r.get("status"), "error": r.get("error"),
                        "url": (r.get("result") or {}).get("url")})
    return results


@mcp.tool()
def upscale_video(project: str, index: int, wait: bool = True) -> dict:
    """씬 영상 AI 업스케일 (RealESRGAN → 1920x1080). 빠른 모드 영상도 선명하게"""
    p = _load(project)
    sc = _scene_at(p, index)
    jid = _post("/api/generate/upscale", _job_body(p, sc, label=f"🔍 {sc.get('title', '')}"))["job_id"]
    return _wait(jid, 3600) if wait else {"job_id": jid}


@mcp.tool()
def generate_bgm(project: str, style: str = "", seconds: float = 0, wait: bool = True) -> dict:
    """AI 배경음악 생성(ACE-Step) → 프로젝트 BGM 으로 자동 등록. seconds=0 이면 타임라인 길이+3초"""
    p = _load(project)
    if not seconds:
        seconds = sum(float(s.get("duration") or 5) for s in p.get("scenes", [])) + 3
    jid = _post("/api/generate/bgm", {"project": p["name"], "persist": True, "style": style,
                                      "seconds": seconds, "label": "🎼 AI BGM"})["job_id"]
    return _wait(jid) if wait else {"job_id": jid}


@mcp.tool()
def render(project: str, size: str = "1920x1080", fps: int = 24, narration: bool = True,
           subtitles: bool = True, wait: bool = True) -> dict:
    """최종 MP4 렌더. size: 1920x1080 | 1080x1920 | 1280x720 | 1080x1080"""
    p = _load(project)
    w, h = [int(x) for x in size.lower().split("x")]
    body = {"name": p["name"], "scenes": p["scenes"], "order": _order(p),
            "opts": {"width": w, "height": h, "fps": fps, "narration": narration, "subtitles": subtitles,
                     "bgm": p.get("bgm"), "bgm_volume": 0.25}}
    jid = _post("/api/render", body)["job_id"]
    if not wait:
        return {"job_id": jid}
    j = _wait(jid, 3600)
    if j.get("status") == "done":
        p = _load(project)
        p["lastRender"] = j["result"]["url"]
        _save(project, p)
    return j


@mcp.tool()
def job_status(job_id: str) -> dict:
    """작업 상태 조회"""
    return _get(f"/api/jobs/{job_id}")


if __name__ == "__main__":
    mcp.run()
