// ═══════════════════════════════════════════════
// JK STUDIO 영상 스튜디오 v2 - 레이어 편집기 (Layered Editing)
// 배경/인물/소품/텍스트 레이어 → 이동·크기·회전·투명도·반전·순서 → 배경 제거
// → 합치기(씬 이미지) 또는 AI 자연 합성(조명·그림자·색감 통일)
// ═══════════════════════════════════════════════

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const lid = () => 'L' + Math.random().toString(36).slice(2, 8);

export class LayerEditor {
  /**
   * @param {object} ctx { state, api, uploadFile, startJob, toast, onChange, getScene }
   */
  constructor(ctx) {
    this.ctx = ctx;
    this.modal = document.getElementById('layer-modal');
    this.cv = document.getElementById('ly-canvas');
    this.g = this.cv.getContext('2d');
    this.imgs = {};      // src → HTMLImageElement 캐시
    this.layers = [];    // 0 = 맨 뒤
    this.sel = null;
    this.sceneId = null;
    this._bind();
    new ResizeObserver(() => this._fit()).observe(this.cv.parentElement);
  }

  // ── 열기/닫기 ──
  open(sceneId) {
    const s = this.ctx.getScene(sceneId);
    if (!s) return;
    this.sceneId = sceneId;
    const st = this.ctx.state.settings;
    this.cv.width = st.img_width || 1344;
    this.cv.height = st.img_height || 768;
    this.layers = s.layers ? JSON.parse(JSON.stringify(s.layers)) : [];
    if (!this.layers.length && s.image) this.addImage(s.image, true);
    this.sel = this.layers.length ? this.layers[this.layers.length - 1].id : null;
    document.getElementById('layer-scene-name').textContent = `씬: ${s.title}`;
    this.modal.hidden = false;
    this._fit();
    this.refresh();
  }
  close() {
    const s = this.ctx.getScene(this.sceneId);
    if (s) { s.layers = this.layers; this.ctx.onChange(); }
    this.modal.hidden = true;
  }

  _fit() {
    const wrap = this.cv.parentElement;
    const W = wrap.clientWidth - 10, H = wrap.clientHeight - 10;
    if (W <= 0 || H <= 0) return;
    const a = this.cv.width / this.cv.height;
    let w = W, h = W / a;
    if (h > H) { h = H; w = H * a; }
    this.cv.style.width = w + 'px';
    this.cv.style.height = h + 'px';
  }

  // ── 레이어 추가 ──
  _load(src) {
    if (this.imgs[src]) return this.imgs[src];
    const im = new Image();
    im.onload = () => {
      // 크기가 정해지지 않은 레이어는 로드 후 맞춤
      this.layers.filter(l => l.src === src && l._fit).forEach(l => this._autoFit(l, im));
      this.refresh();
    };
    im.src = src;
    this.imgs[src] = im;
    return im;
  }
  _autoFit(l, im) {
    const W = this.cv.width, H = this.cv.height;
    l.scale = l._fit === 'cover' ? Math.max(W / im.width, H / im.height) : Math.min(W / im.width, H / im.height) * 0.6;
    delete l._fit;
  }
  addImage(src, background = false) {
    const l = { id: lid(), type: 'image', src, x: this.cv.width / 2, y: this.cv.height / 2, scale: 1, rot: 0,
                opacity: 1, flip: false, visible: true, name: background ? '배경' : '레이어',
                _fit: background ? 'cover' : 'contain' };
    const im = this._load(src);
    if (im.complete && im.naturalWidth) this._autoFit(l, im);
    if (background) this.layers.unshift(l); else this.layers.push(l);
    this.sel = l.id;
    this.refresh();
    return l;
  }
  addText() {
    const text = prompt('텍스트 입력', '제목');
    if (!text) return;
    const l = { id: lid(), type: 'text', text, x: this.cv.width / 2, y: this.cv.height * 0.15, scale: 1, rot: 0,
                opacity: 1, flip: false, visible: true, name: '텍스트', size: Math.round(this.cv.height * 0.08), color: '#ffffff' };
    this.layers.push(l);
    this.sel = l.id;
    this.refresh();
  }

  get cur() { return this.layers.find(l => l.id === this.sel) || null; }

  // ── 그리기 ──
  _size(l) {
    if (l.type === 'text') {
      this.g.font = `900 ${l.size * l.scale}px "Noto Sans KR", sans-serif`;
      const w = this.g.measureText(l.text).width;
      return [w, l.size * l.scale * 1.2];
    }
    const im = this.imgs[l.src];
    if (!im || !im.naturalWidth) return [0, 0];
    return [im.naturalWidth * l.scale, im.naturalHeight * l.scale];
  }

  draw(g = this.g, withUI = true) {
    const W = this.cv.width, H = this.cv.height;
    g.save();
    g.fillStyle = '#000';
    g.fillRect(0, 0, W, H);
    for (const l of this.layers) {
      if (!l.visible) continue;
      g.save();
      g.globalAlpha = l.opacity;
      g.translate(l.x, l.y);
      g.rotate(l.rot * Math.PI / 180);
      if (l.flip) g.scale(-1, 1);
      if (l.type === 'text') {
        g.font = `900 ${l.size * l.scale}px "Noto Sans KR", sans-serif`;
        g.textAlign = 'center'; g.textBaseline = 'middle';
        g.lineWidth = Math.max(2, l.size * l.scale * 0.08); g.strokeStyle = '#000';
        g.strokeText(l.text, 0, 0);
        g.fillStyle = l.color; g.fillText(l.text, 0, 0);
      } else {
        const im = this.imgs[l.src] || this._load(l.src);
        if (im.complete && im.naturalWidth) {
          const [w, h] = this._size(l);
          g.drawImage(im, -w / 2, -h / 2, w, h);
        }
      }
      g.restore();
    }
    if (withUI && this.cur) {
      const l = this.cur, [w, h] = this._size(l);
      g.save();
      g.translate(l.x, l.y); g.rotate(l.rot * Math.PI / 180);
      g.strokeStyle = '#3de0ff'; g.lineWidth = Math.max(2, W / 500); g.setLineDash([12, 8]);
      g.strokeRect(-w / 2, -h / 2, w, h);
      g.restore();
    }
    g.restore();
  }

  refresh() {
    this.draw();
    // 레이어 목록 (위가 앞)
    const list = document.getElementById('ly-list');
    list.innerHTML = [...this.layers].reverse().map(l => `
      <div class="ly-row ${l.id === this.sel ? 'sel' : ''}" data-id="${l.id}">
        <span class="av" style="${l.type === 'image' ? `background-image:url('${l.src}')` : ''}">${l.type === 'text' ? '🔤' : ''}</span>
        <span>${esc(l.type === 'text' ? l.text : l.name)}</span>
        <span class="eye" data-eye="${l.id}">${l.visible ? '👁' : '🚫'}</span></div>`).join('') || '<div class="muted small">레이어 없음</div>';
    list.querySelectorAll('.ly-row').forEach(el => el.addEventListener('click', e => {
      const eye = e.target.dataset.eye;
      if (eye) { const l = this.layers.find(x => x.id === eye); l.visible = !l.visible; }
      else this.sel = el.dataset.id;
      this.refresh();
    }));
    const c = this.cur;
    document.getElementById('ly-props').style.opacity = c ? 1 : 0.4;
    if (c) {
      document.getElementById('ly-scale').value = c.scale;
      document.getElementById('ly-rot').value = c.rot;
      document.getElementById('ly-opacity').value = c.opacity;
    }
  }

  // ── 마우스 ──
  _toCanvas(e) {
    const r = this.cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) * this.cv.width / r.width, y: (e.clientY - r.top) * this.cv.height / r.height };
  }
  _hit(p) {
    for (let i = this.layers.length - 1; i >= 0; i--) {
      const l = this.layers[i];
      if (!l.visible) continue;
      const [w, h] = this._size(l);
      const a = -l.rot * Math.PI / 180, dx = p.x - l.x, dy = p.y - l.y;
      const lx = dx * Math.cos(a) - dy * Math.sin(a), ly = dx * Math.sin(a) + dy * Math.cos(a);
      if (Math.abs(lx) <= w / 2 && Math.abs(ly) <= h / 2) return l;
    }
    return null;
  }

  _bind() {
    const $ = id => document.getElementById(id);
    this.cv.addEventListener('pointerdown', e => {
      const p = this._toCanvas(e);
      const l = this._hit(p);
      this.sel = l ? l.id : null;
      this.refresh();
      if (!l) return;
      const ox = l.x, oy = l.y;
      const mv = ev => { const q = this._toCanvas(ev); l.x = ox + q.x - p.x; l.y = oy + q.y - p.y; this.draw(); };
      const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    });
    this.cv.addEventListener('wheel', e => {
      e.preventDefault();
      const l = this.cur; if (!l) return;
      l.scale = Math.max(0.02, l.scale * Math.exp(-e.deltaY * 0.001));
      this.refresh();
    }, { passive: false });
    this.cv.addEventListener('dblclick', e => {
      const l = this._hit(this._toCanvas(e));
      if (l && l.type === 'text') {
        const t = prompt('텍스트 수정', l.text); if (t !== null) l.text = t;
        const col = prompt('색상 (예: #f2c14e)', l.color); if (col) l.color = col;
        this.refresh();
      }
    });
    $('ly-scale').addEventListener('input', e => { if (this.cur) { this.cur.scale = +e.target.value; this.draw(); } });
    $('ly-rot').addEventListener('input', e => { if (this.cur) { this.cur.rot = +e.target.value; this.draw(); } });
    $('ly-opacity').addEventListener('input', e => { if (this.cur) { this.cur.opacity = +e.target.value; this.draw(); } });
    $('ly-flip').addEventListener('click', () => { if (this.cur) { this.cur.flip = !this.cur.flip; this.refresh(); } });
    $('ly-up').addEventListener('click', () => this._move(1));
    $('ly-down').addEventListener('click', () => this._move(-1));
    $('ly-del').addEventListener('click', () => { this.layers = this.layers.filter(l => l.id !== this.sel); this.sel = null; this.refresh(); });
    $('ly-close').addEventListener('click', () => this.close());

    // 추가
    $('ly-add-file').addEventListener('click', () => $('ly-file').click());
    $('ly-file').addEventListener('change', async e => {
      for (const f of [...e.target.files]) {
        try { this.addImage(await this.ctx.uploadFile(f)); } catch (err) { this.ctx.toast('업로드 실패: ' + err.message); }
      }
      e.target.value = '';
    });
    $('ly-add-scene').addEventListener('click', () => {
      const s = this.ctx.getScene(this.sceneId);
      if (s && s.image) this.addImage(s.image, !this.layers.length); else this.ctx.toast('씬 이미지가 없습니다');
    });
    $('ly-add-char').addEventListener('click', () => {
      const s = this.ctx.getScene(this.sceneId);
      const chars = this.ctx.state.project.characters.filter(c => (s.characters || []).includes(c.id) && c.refs.length);
      const pool = chars.length ? chars : this.ctx.state.project.characters.filter(c => c.refs.length);
      if (!pool.length) return this.ctx.toast('참조 이미지가 있는 캐릭터가 없습니다');
      pool.forEach(c => { const l = this.addImage(c.refs[0]); l.name = c.name; });
      this.ctx.toast('캐릭터 레이어 추가 — "✂ 배경 제거"로 인물만 남기세요');
    });
    $('ly-add-variant').addEventListener('click', () => {
      const s = this.ctx.getScene(this.sceneId);
      const v = (s.variants || []).filter(u => u !== s.image);
      if (!v.length) return this.ctx.toast('변형 이미지가 없습니다');
      this.addImage(v[v.length - 1]);
    });
    $('ly-add-text').addEventListener('click', () => this.addText());

    // 배경 제거
    $('ly-cutout').addEventListener('click', async () => {
      const l = this.cur;
      if (!l || l.type !== 'image') return this.ctx.toast('이미지 레이어를 선택하세요');
      this.ctx.toast('✂ 배경 제거 중… (첫 실행은 모델 다운로드로 1~2분)', 5000);
      const job = await this.ctx.startJob('/api/cutout', { image: l.src, label: '✂ 배경 제거' }, {});
      if (job && job.status === 'done') {
        l.src = job.result.url; this._load(l.src); l.name = (l.name || '레이어') + ' (누끼)';
        this.refresh();
      }
    });

    // 완성
    $('ly-flatten').addEventListener('click', () => this.flatten(false));
    $('ly-harmonize').addEventListener('click', () => this.flatten(true));
  }

  _move(dir) {
    const i = this.layers.findIndex(l => l.id === this.sel);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= this.layers.length) return;
    [this.layers[i], this.layers[j]] = [this.layers[j], this.layers[i]];
    this.refresh();
  }

  async flatten(harmonize) {
    const s = this.ctx.getScene(this.sceneId);
    if (!s || !this.layers.length) return;
    const off = document.createElement('canvas');
    off.width = this.cv.width; off.height = this.cv.height;
    this.draw(off.getContext('2d'), false);
    try {
      const { url } = await this.ctx.api('/api/upload_dataurl', { body: { data: off.toDataURL('image/png'), prefix: 'layers' } });
      s.layers = this.layers;
      s.image = url;
      s.variants = [...(s.variants || []), url];
      this.ctx.onChange();
      if (harmonize) {
        this.ctx.startJob('/api/generate/edit', { mode: 'harmonize', scene: s, image: url, label: `✨ ${s.title} 합성` },
                          { sceneId: s.id, busy: 'AI 합성' });
        this.ctx.toast('✨ AI 합성 요청 — 완료되면 대표 이미지로 교체됩니다');
      } else this.ctx.toast('📌 합친 이미지를 씬 대표 이미지로 설정');
      this.modal.hidden = true;
    } catch (e) { this.ctx.toast('합치기 실패: ' + e.message); }
  }
}
