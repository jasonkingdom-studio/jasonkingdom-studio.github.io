// ═══════════════════════════════════════════════
// JK STUDIO 영상 스튜디오 v2 - 캐스팅 스튜디오
// 캐릭터 등록 · 참조 이미지(무제한) · AI 캐릭터 이미지 · 캐릭터 턴어라운드 시트
// ═══════════════════════════════════════════════

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export class CastingStudio {
  /**
   * @param {object} ctx { state, uploadFile, startJob, toast, onChange }
   */
  constructor(ctx) {
    this.ctx = ctx;
    this.sel = null;
    this.modal = document.getElementById('cast-modal');
    document.getElementById('cast-close').addEventListener('click', () => this.close());
    document.getElementById('cast-add').addEventListener('click', () => this.add());
  }

  get chars() { return this.ctx.state.project.characters; }

  open(charId = null) {
    this.modal.hidden = false;
    this.sel = charId || this.sel || (this.chars[0] && this.chars[0].id);
    this.render();
  }
  close() { this.modal.hidden = true; this.ctx.onChange(); }
  isOpen() { return !this.modal.hidden; }

  add(name = '', description = '') {
    const c = { id: 'c' + Math.random().toString(36).slice(2, 9), name: name || `캐릭터 ${this.chars.length + 1}`,
                description, refs: [], sheet: null };
    this.chars.push(c);
    this.sel = c.id;
    this.ctx.onChange();
    this.render();
    return c;
  }

  remove(id) {
    const c = this.chars.find(x => x.id === id);
    if (!c || !confirm(`"${c.name}" 캐릭터를 삭제할까요? (씬 출연 정보도 지워집니다)`)) return;
    this.ctx.state.project.characters = this.chars.filter(x => x.id !== id);
    this.ctx.state.project.scenes.forEach(s => { s.characters = (s.characters || []).filter(x => x !== id); });
    this.sel = this.chars[0] ? this.chars[0].id : null;
    this.ctx.onChange();
    this.render();
  }

  render() {
    if (!this.isOpen()) return;
    this.renderList();
    this.renderDetail();
  }

  // 왼쪽 캐릭터 목록만 갱신 (입력 중 포커스 유지)
  renderList() {
    const list = document.getElementById('cast-items');
    list.innerHTML = this.chars.map(c => {
      const img = (c.refs && c.refs[0]) || c.sheet || '';
      const n = this.ctx.state.project.scenes.filter(s => (s.characters || []).includes(c.id)).length;
      return `<div class="cast-item ${c.id === this.sel ? 'sel' : ''}" data-id="${c.id}">
        <span class="av" style="background-image:url('${img}')"></span>
        <div><b>${esc(c.name)}</b><span class="muted small">참조 ${c.refs.length}장 · 출연 ${n}컷${c.sheet ? ' · 시트✓' : ''}</span></div></div>`;
    }).join('') || '<div class="muted small">아직 캐릭터가 없습니다</div>';
    list.querySelectorAll('.cast-item').forEach(el => el.addEventListener('click', () => { this.sel = el.dataset.id; this.render(); }));
  }

  renderDetail() {
    const c = this.chars.find(x => x.id === this.sel);
    const det = document.getElementById('cast-detail');
    if (!c) { det.innerHTML = '<div class="muted center-msg">캐릭터를 선택하거나 추가하세요</div>'; return; }
    const busy = this.ctx.state.busyChar[c.id];
    det.innerHTML = `
      <div class="row"><label style="flex:1">이름<input id="cd-name" value="${esc(c.name)}"></label>
        <button id="cd-del" class="btn danger">🗑 삭제</button></div>
      <label>외형 묘사 (영어 권장 — 모든 컷 프롬프트에 자동 반영)
        <textarea id="cd-desc" rows="3" placeholder="e.g. 20-year-old Korean woman, long black hair with red ribbons, white hanbok with neon trims">${esc(c.description)}</textarea></label>
      <div class="media-head">📎 참조 이미지 <span class="muted small">첫 번째(금색 테두리)가 대표 · 클릭: 대표로 지정 · 많을수록 일관성↑</span></div>
      <div class="ref-grid">${c.refs.map((u, i) => `<div class="ref-item ${i === 0 ? 'main' : ''}" data-i="${i}">
          <img src="${u}"><button class="x" data-x="${i}">✕</button></div>`).join('')}</div>
      <div class="row">
        <button id="cd-upload" class="btn wide">📁 참조 이미지 추가</button>
        <button id="cd-portrait" class="btn gold wide" ${busy ? 'disabled' : ''}>🎨 설명으로 AI 캐릭터 생성</button>
      </div>
      <input id="cd-file" type="file" accept="image/*" multiple hidden>
      <div class="media-head" style="margin-top:12px">📋 캐릭터 턴어라운드 시트 (정면·측면·후면·얼굴)</div>
      ${c.sheet ? `<img class="cast-sheet" src="${c.sheet}">` : '<div class="muted small">시트가 없습니다 — 참조 이미지로 자동 생성합니다</div>'}
      <div class="row">
        <button id="cd-sheet" class="btn gold wide" ${busy ? 'disabled' : ''}>📋 캐릭터 시트 생성</button>
        ${c.sheet ? '<button id="cd-sheet-del" class="btn ghost">✕ 시트 삭제</button>' : ''}
      </div>
      ${busy ? `<div class="muted">⏳ ${esc(busy)} 생성 중…</div>` : ''}`;

    det.querySelector('#cd-name').addEventListener('input', e => { c.name = e.target.value; this.ctx.onChange(true); this.renderList(); });
    det.querySelector('#cd-desc').addEventListener('input', e => { c.description = e.target.value; this.ctx.onChange(true); });
    det.querySelector('#cd-del').addEventListener('click', () => this.remove(c.id));
    det.querySelectorAll('.ref-item').forEach(el => el.addEventListener('click', e => {
      if (e.target.dataset.x !== undefined) {
        c.refs.splice(Number(e.target.dataset.x), 1);
      } else {
        const i = Number(el.dataset.i);
        c.refs.unshift(...c.refs.splice(i, 1));
      }
      this.ctx.onChange(); this.render();
    }));
    const file = det.querySelector('#cd-file');
    det.querySelector('#cd-upload').addEventListener('click', () => file.click());
    file.addEventListener('change', async e => {
      const files = [...e.target.files];
      for (const f of files) {
        try { c.refs.push(await this.ctx.uploadFile(f)); } catch (err) { this.ctx.toast('업로드 실패: ' + err.message); }
      }
      this.ctx.onChange(); this.render();
    });
    det.querySelector('#cd-portrait').addEventListener('click', () => {
      if (!c.description.trim()) return this.ctx.toast('외형 묘사를 먼저 입력하세요');
      this.ctx.startJob('/api/generate/edit', { mode: 'portrait', char_id: c.id, label: `🎭 ${c.name} 이미지` }, { charId: c.id, busy: '캐릭터 이미지' });
      this.render();
    });
    det.querySelector('#cd-sheet').addEventListener('click', () => {
      if (!c.refs.length) return this.ctx.toast('참조 이미지를 먼저 추가하거나 AI로 생성하세요');
      this.ctx.startJob('/api/generate/edit', { mode: 'sheet', char_id: c.id, label: `📋 ${c.name} 시트` }, { charId: c.id, busy: '캐릭터 시트' });
      this.render();
    });
    const sd = det.querySelector('#cd-sheet-del');
    if (sd) sd.addEventListener('click', () => { c.sheet = null; this.ctx.onChange(); this.render(); });
  }
}
