// ═══════════════════════════════════════════════
// JK STUDIO 영상 스튜디오 - 3D 디렉터 스테이지 (Three.js)
// 인물 마네킹/소품 배치 → 카메라 샷 구성 → 깊이맵/레이아웃 캡처
// 캡처한 깊이맵은 ComfyUI ControlNet Depth 로 들어가 구도를 고정
// ═══════════════════════════════════════════════
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';

const COLORS = [0xf2c14e, 0x3de0ff, 0xff5470, 0x9d7bff, 0x3dffa2, 0xff9a3d];
const POSES = ['stand', 'walk', 'arms_up', 'point', 'sit'];

// 깊이 셰이더: 카메라 거리 기준 선형 깊이 (가까울수록 흰색)
const depthMaterial = new THREE.ShaderMaterial({
  uniforms: { uNear: { value: 1 }, uFar: { value: 10 } },
  vertexShader: `varying float vD;
    void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0); vD = -mv.z; gl_Position = projectionMatrix * mv; }`,
  fragmentShader: `uniform float uNear; uniform float uFar; varying float vD;
    void main(){ float d = clamp((vD-uNear)/(uFar-uNear),0.0,1.0); gl_FragColor = vec4(vec3(1.0-d),1.0); }`,
});

export class Stage3D {
  constructor(container) {
    this.container = container;
    this.objects = [];
    this.aspect = 16 / 9;
    this.colorIdx = 0;

    // 렌더러 (캡처를 위해 preserveDrawingBuffer)
    this.renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio));
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x15151f);
    this.camera = new THREE.PerspectiveCamera(40, this.aspect, 0.05, 200);
    this.camera.position.set(0, 1.6, 6);

    // 조명
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x222233, 1.2));
    const sun = new THREE.DirectionalLight(0xffffff, 1.6);
    sun.position.set(4, 8, 5);
    this.scene.add(sun);

    // 바닥 + 그리드
    this.floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 60),
      new THREE.MeshStandardMaterial({ color: 0x2a2a38, roughness: 1 }));
    this.floor.rotation.x = -Math.PI / 2;
    this.scene.add(this.floor);
    this.grid = new THREE.GridHelper(60, 60, 0x555577, 0x33334a);
    this.grid.position.y = 0.002;
    this.scene.add(this.grid);

    // 컨트롤
    this.orbit = new OrbitControls(this.camera, this.renderer.domElement);
    this.orbit.target.set(0, 1, 0);
    this.orbit.enableDamping = true;
    this.orbit.update();

    this.tc = new TransformControls(this.camera, this.renderer.domElement);
    this.tcHelper = this.tc.getHelper ? this.tc.getHelper() : this.tc; // r169+ 대응
    this.scene.add(this.tcHelper);
    this._justDragged = false;
    this.tc.addEventListener('dragging-changed', e => {
      this.orbit.enabled = !e.value;
      if (e.value) this._justDragged = true;
    });

    this._bindPicking();
    this._bindKeys();
    this._ro = new ResizeObserver(() => this.resize());
    this._ro.observe(container.parentElement);
    this._loop();
  }

  // ── 화면 크기: 출력 비율 그대로 (보이는 화면 = 샷) ──
  setAspect(aspect) { this.aspect = aspect; this.resize(); }
  resize() {
    const wrap = this.container.parentElement;
    const W = wrap.clientWidth - 8, H = wrap.clientHeight - 8;
    if (W <= 0 || H <= 0) return;
    let w = W, h = W / this.aspect;
    if (h > H) { h = H; w = H * this.aspect; }
    this.container.style.width = w + 'px';
    this.container.style.height = h + 'px';
    this.renderer.setSize(w, h, false);
    this.camera.aspect = this.aspect;
    this.camera.updateProjectionMatrix();
  }

  _loop() {
    requestAnimationFrame(() => this._loop());
    if (!this.container.offsetParent) return; // 모달 닫혀 있으면 쉼
    this.orbit.update();
    this.renderer.render(this.scene, this.camera);
  }

  // ── 오브젝트 생성 ──
  _mat(color) { return new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.1 }); }

  _limb(parent, radius, length, color, x, y, name) {
    // 관절(pivot) 기준으로 회전하도록 그룹 안에 아래로 매달기
    const pivot = new THREE.Group();
    pivot.position.set(x, y, 0);
    pivot.name = name;
    const m = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 6, 12), this._mat(color));
    m.position.y = -length / 2 - radius;
    pivot.add(m);
    parent.add(pivot);
    return pivot;
  }

  _makePerson(color) {
    const g = new THREE.Group();
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.17, 0.42, 6, 14), this._mat(color));
    torso.position.y = 1.2;
    g.add(torso);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.12, 20, 16), this._mat(color));
    head.position.y = 1.64;
    g.add(head);
    // 얼굴 방향 표시 (코)
    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.07, 8), this._mat(0xffffff));
    nose.rotation.x = Math.PI / 2; nose.position.set(0, 1.64, 0.13);
    g.add(nose);
    this._limb(g, 0.065, 0.66, color, -0.1, 0.9, 'legL');
    this._limb(g, 0.065, 0.66, color, 0.1, 0.9, 'legR');
    this._limb(g, 0.05, 0.5, color, -0.25, 1.45, 'armL');
    this._limb(g, 0.05, 0.5, color, 0.25, 1.45, 'armR');
    return g;
  }

  applyPose(g, pose) {
    const p = n => g.getObjectByName(n);
    const [lL, lR, aL, aR] = ['legL', 'legR', 'armL', 'armR'].map(p);
    if (!lL) return;
    [lL, lR, aL, aR].forEach(o => o.rotation.set(0, 0, 0));
    g.children.forEach(c => { if (c.isMesh) c.position.y = c.userData.baseY ?? (c.userData.baseY = c.position.y); });
    lL.position.y = lR.position.y = 0.9;
    aL.rotation.z = -0.12; aR.rotation.z = 0.12;
    if (pose === 'walk') { lL.rotation.x = 0.45; lR.rotation.x = -0.45; aL.rotation.x = -0.45; aR.rotation.x = 0.45; }
    if (pose === 'arms_up') { aL.rotation.z = -2.8; aR.rotation.z = 2.8; }
    if (pose === 'point') { aR.rotation.x = -1.5; }
    if (pose === 'sit') {
      lL.rotation.x = -1.45; lR.rotation.x = -1.45;
      g.children.forEach(c => { if (c.isMesh) c.position.y = c.userData.baseY - 0.42; });
      lL.position.y = lR.position.y = 0.48;
      aL.rotation.x = -0.6; aR.rotation.x = -0.6;
    }
    g.userData.pose = pose;
  }

  add(type, data = null) {
    const color = data?.color ?? COLORS[this.colorIdx++ % COLORS.length];
    let obj;
    if (type === 'person') { obj = this._makePerson(color); }
    else if (type === 'box') { obj = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), this._mat(color)); obj.position.y = 0.5; }
    else if (type === 'sphere') { obj = new THREE.Mesh(new THREE.SphereGeometry(0.5, 32, 20), this._mat(color)); obj.position.y = 0.5; }
    else if (type === 'wall') { obj = new THREE.Mesh(new THREE.BoxGeometry(6, 3, 0.2), this._mat(color)); obj.position.set(0, 1.5, -2.5); }
    else if (type === 'pillar') { obj = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 3.5, 24), this._mat(color)); obj.position.y = 1.75; }
    else return null;
    obj.userData = { ...obj.userData, root: true, type, color };
    if (data) {
      obj.position.fromArray(data.pos);
      obj.rotation.set(...data.rot);
      obj.scale.fromArray(data.scl);
    } else if (type !== 'wall') {
      // 새 오브젝트는 조금씩 옆에
      obj.position.x = (this.objects.length % 5 - 2) * 0.9;
    }
    if (type === 'person') this.applyPose(obj, data?.pose || 'stand');
    this.scene.add(obj);
    this.objects.push(obj);
    if (!data) this.tc.attach(obj);
    return obj;
  }

  remove(obj) {
    if (!obj) return;
    this.tc.detach();
    this.scene.remove(obj);
    this.objects = this.objects.filter(o => o !== obj);
  }

  clear() { [...this.objects].forEach(o => this.remove(o)); this.colorIdx = 0; }

  get selected() { return this.tc.object || null; }

  cyclePose() {
    const o = this.selected;
    if (!o || o.userData.type !== 'person') return false;
    const i = POSES.indexOf(o.userData.pose || 'stand');
    this.applyPose(o, POSES[(i + 1) % POSES.length]);
    return POSES[(i + 1) % POSES.length];
  }

  // ── 선택 (클릭) ──
  _bindPicking() {
    const el = this.renderer.domElement;
    let down = null;
    el.addEventListener('pointerdown', e => { down = { x: e.clientX, y: e.clientY }; });
    el.addEventListener('pointerup', e => {
      if (this._justDragged) { this._justDragged = false; return; }
      if (!down || Math.hypot(e.clientX - down.x, e.clientY - down.y) > 4) return;
      const r = el.getBoundingClientRect();
      const ndc = new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
      const ray = new THREE.Raycaster();
      ray.setFromCamera(ndc, this.camera);
      const hit = ray.intersectObjects(this.objects, true)[0];
      if (hit) {
        let o = hit.object;
        while (o && !o.userData.root) o = o.parent;
        this.tc.attach(o);
      } else this.tc.detach();
    });
  }

  _bindKeys() {
    window.addEventListener('keydown', e => {
      if (!this.container.offsetParent) return;
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) return;
      const k = e.key.toLowerCase();
      if (k === 'w') this.tc.setMode('translate');
      if (k === 'e') this.tc.setMode('rotate');
      if (k === 'r') this.tc.setMode('scale');
      if (k === 'delete' || k === 'backspace') this.remove(this.selected);
    });
  }

  // ── 카메라 샷 프리셋 (선택 오브젝트 기준) ──
  shot(name) {
    const base = this.selected ? this.selected.position.clone() : new THREE.Vector3(0, 0, 0);
    const S = {
      wide:   [[0, 1.6, 7],  [0, 1.0, 0]],
      medium: [[0, 1.5, 3.2], [0, 1.25, 0]],
      close:  [[0, 1.62, 1.3], [0, 1.58, 0]],
      low:    [[0, 0.35, 3.2], [0, 1.4, 0]],
      high:   [[0, 6.5, 4],  [0, 0.4, 0]],
      side:   [[4.5, 1.5, 0], [0, 1.1, 0]],
    }[name];
    if (!S) return;
    this.camera.position.copy(base).add(new THREE.Vector3(...S[0]));
    this.orbit.target.copy(base).add(new THREE.Vector3(...S[1]));
    this.orbit.update();
  }

  setFov(v) { this.camera.fov = v; this.camera.updateProjectionMatrix(); }

  // ── 저장/불러오기 ──
  serialize() {
    return {
      camera: { pos: this.camera.position.toArray(), target: this.orbit.target.toArray(), fov: this.camera.fov },
      objects: this.objects.map(o => ({
        type: o.userData.type, color: o.userData.color, pose: o.userData.pose,
        pos: o.position.toArray(), rot: [o.rotation.x, o.rotation.y, o.rotation.z], scl: o.scale.toArray(),
      })),
    };
  }

  load(data) {
    this.clear();
    if (!data || !data.objects) {
      // 기본 무대: 인물 1명
      this.add('person');
      this.tc.detach();
      this.camera.position.set(0, 1.6, 6); this.orbit.target.set(0, 1, 0); this.setFov(40);
    } else {
      data.objects.forEach(o => this.add(o.type, o));
      this.camera.position.fromArray(data.camera.pos);
      this.orbit.target.fromArray(data.camera.target);
      this.setFov(data.camera.fov || 40);
    }
    this.orbit.update();
  }

  // ── 캡처 ──
  _withCapture(w, h, fn) {
    const prevAspect = this.camera.aspect;
    this.tcHelper.visible = false;
    this.grid.visible = false;
    this.renderer.setPixelRatio(1);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    fn();
    this.renderer.render(this.scene, this.camera);
    const url = this.renderer.domElement.toDataURL('image/png');
    // 원상복구
    this.scene.overrideMaterial = null;
    this.scene.background = new THREE.Color(0x15151f);
    this.tcHelper.visible = true;
    this.grid.visible = true;
    this.camera.aspect = prevAspect;
    this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio));
    this.resize();
    return url;
  }

  captureDepth(w, h) {
    // 오브젝트까지 거리 범위로 깊이 대비를 최대화
    this.camera.updateMatrixWorld();
    let minD = Infinity, maxD = 0;
    const box = new THREE.Box3(), v = new THREE.Vector3();
    this.objects.forEach(o => {
      box.setFromObject(o);
      for (let i = 0; i < 8; i++) {
        v.set(i & 1 ? box.max.x : box.min.x, i & 2 ? box.max.y : box.min.y, i & 4 ? box.max.z : box.min.z);
        const d = v.applyMatrix4(this.camera.matrixWorldInverse).z * -1;
        if (d > 0) { minD = Math.min(minD, d); maxD = Math.max(maxD, d); }
      }
    });
    if (!isFinite(minD)) { minD = 0.5; maxD = 10; }
    depthMaterial.uniforms.uNear.value = Math.max(0.05, minD * 0.85);
    depthMaterial.uniforms.uFar.value = maxD * 1.6 + 2;
    return this._withCapture(w, h, () => {
      this.scene.overrideMaterial = depthMaterial;
      this.scene.background = new THREE.Color(0x000000);
    });
  }

  captureRGB(w, h) { return this._withCapture(w, h, () => {}); }
}
