// ═══════════════════════════════════════════════
// JK STUDIO 영상 스튜디오 v2 - 메인 앱 로직
// 상태 · 캔버스 · 인스펙터 · 캐스팅 · 디렉터 도구 · 레이어 · 영상(오토링크/구간 재작성)
// 작업 추적 · 타임라인 · 렌더 · 프로젝트 저장(외부 변경 감지) · 설정 · 3D 스테이지
// ═══════════════════════════════════════════════
import { NodeCanvas, computeOrder } from './canvas.js';
import { CastingStudio } from './casting.js';
import { LayerEditor } from './layers.js';

const $ = sel => document.querySelector(sel);
const $$ = sel => [...document.querySelectorAll(sel)];
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ═══════════ 상태 ═══════════
const state = {
  project: emptyProject('새_프로젝트'),
  selected: null,
  dirty: false,
  mtime: 0,          // 서버 파일 수정 시각 (외부 변경 감지용)
  settings: {},
  presets: { lights: [], angles: [], engines: [] },
  jobs: {},
  busy: {},          // scene_id → 라벨
  busyChar: {},      // char_id → 라벨
  angles: new Set(['left45', 'right45', 'close']),
};

function emptyProject(name) {
  return { name, globalStyle: '', artStyle: 'real', story: '', script: '', characters: [], scenes: [], edges: [], bgm: null, bgmName: '', lastRender: null };
}
const uid = p => p + Math.random().toString(36).slice(2, 9);

function newScene(p = {}) {
  return Object.assign({
    id: uid('s'), title: '새 컷', prompt: '', negative: '', narration: '', camera: '',
    duration: 5, seed: -1, motion: 'zoom_in', x: 0, y: 0,
    image: null, video: null, depth: null, useDepth: false, stage: null,
    characters: [], refs: [], variants: [], videoHistory: [], engine: 'comfy_fast', layers: null, refshot: null,
  }, p);
}
function normChar(c) { return Object.assign({ id: uid('c'), name: '캐릭터', description: '', refs: [], sheet: null }, c); }

const scene = id => state.project.scenes.find(s => s.id === id);
const order = () => computeOrder(state.project.scenes, state.project.edges);

// ═══════════ 유틸 ═══════════
async function api(path, opts = {}) {
  const init = { method: opts.method || (opts.body ? 'POST' : 'GET'), headers: {} };
  if (opts.body instanceof FormData) init.body = opts.body;
  else if (opts.body) { init.body = JSON.stringify(opts.body); init.headers['Content-Type'] = 'application/json'; }
  const r = await fetch(path, init);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
}
let toastTimer;
function toast(msg, ms = 2800) {
  const t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), ms);
}
async function uploadFile(file) {
  const fd = new FormData(); fd.append('file', file);
  return (await api('/api/upload', { body: fd })).url;
}
function markDirty() { state.dirty = true; }
function lsGet(k) { try { return localStorage.getItem(k); } catch { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch { /* 저장소 차단 시 무시 */ } }

// 서버 app.py 의 apply_patches 와 같은 규칙
function applyPatches(project, patches) {
  for (const p of patches || []) {
    const obj = p.target === 'project' ? project
      : (p.target === 'scene' ? project.scenes : project.characters).find(o => o.id === p.id);
    if (!obj) continue;
    Object.assign(obj, p.set || {});
    for (const [k, vals] of Object.entries(p.push || {})) {
      obj[k] = obj[k] || [];
      vals.forEach(v => { if (v && !obj[k].includes(v)) obj[k].push(v); });
    }
  }
}

// ═══════════ 캔버스 ═══════════
const canvas = new NodeCanvas($('#viewport'), {
  getScenes: () => state.project.scenes,
  getEdges: () => state.project.edges,
  getCharacters: () => state.project.characters,
  setEdges: e => { state.project.edges = e; },
  getBusy: id => state.busy[id],
  onSelect: id => { state.selected = id; fillInspector(); renderTimeline(); },
  onChange: () => { markDirty(); renderTimeline(); },
  onAction: (act, id, extra) => handleAction(act, id, extra),
});

function refreshAll() {
  canvas.render();
  renderTimeline();
  fillInspector();
  renderCastChips();
  casting.render();
}

function handleAction(act, id, extra) {
  if (act === 'img') return genImage(id);
  if (act === 'vid') return genVideo(id);
  if (act === 'stage') return openStage(id);
  if (act === 'dup') return duplicateScene(id);
  if (act === 'del') return deleteScene(id);
  if (act === 'add-at') return addScene(extra);
}

// ═══════════ 작업 (Job) ═══════════
// 모든 생성 요청의 공통 진입점: 프로젝트 문맥(캐릭터, 전역 스타일)을 붙여서 보냄 → 완료 시 Promise 로 job 반환
function startJob(endpoint, body, opts = {}) {
  const payload = { project: state.project.name, persist: false, characters: state.project.characters,
                    globalStyle: state.project.globalStyle, artStyle: state.project.artStyle || 'real', ...body };
  return api(endpoint, { body: payload })
    .then(({ job_id }) => trackJob(job_id, { label: body.label, ...opts }))
    .catch(e => { toast('요청 실패: ' + e.message, 5000); return null; });
}

function trackJob(jid, { sceneId, charId, busy, label } = {}) {
  state.jobs[jid] = { id: jid, status: 'queued', progress: 0, message: '대기 중', label, created: Date.now() / 1000 };
  if (sceneId) { state.busy[sceneId] = busy || '작업'; canvas.updateNode(sceneId); }
  if (charId) state.busyChar[charId] = busy || '작업';
  renderJobs(); fillInspector(); casting.render();
  return new Promise(resolve => {
    const poll = async () => {
      let j;
      try { j = await api('/api/jobs/' + jid); } catch { setTimeout(poll, 3000); return; }
      state.jobs[jid] = j;
      renderJobs();
      if (j.status !== 'done' && j.status !== 'error') { setTimeout(poll, 1500); return; }
      if (sceneId) delete state.busy[sceneId];
      if (charId) delete state.busyChar[charId];
      if (j.status === 'done') onJobDone(j);
      else toast('❌ ' + (j.label || '') + ' 실패: ' + j.error, 7000);
      refreshAll();
      resolve(j);
    };
    setTimeout(poll, 800);
  });
}

function onJobDone(j) {
  if (j.kind === 'bgm') {
    applyPatches(state.project, j.result.apply);
    $('#bgm-name').textContent = '🎵 ' + j.result.name;
    $('#bgm-preview').src = j.result.url; $('#bgm-preview').hidden = false;
    toast('🎼 AI BGM 완료 — 렌더에 자동 사용됩니다');
  } else if (j.kind === 'render') {
    state.project.lastRender = j.result.url;
    showFinal(j.result.url);
    toast('🎉 렌더 완료!');
  } else if (j.kind !== 'cutout') {
    applyPatches(state.project, j.result.apply);
    toast(`✅ ${j.label || '작업'} 완료`);
  }
  markDirty();
  saveProject(true);
}

function renderJobs() {
  const list = Object.values(state.jobs).sort((a, b) => (b.created || 0) - (a.created || 0)).slice(0, 30);
  $('#jobs').innerHTML = list.map(j => `
    <div class="job ${j.status}">
      <div class="jt"><span>${esc(j.label || j.kind)}</span><span>${{ queued: '대기', running: '진행', done: '완료', error: '오류' }[j.status] || ''}</span></div>
      <div class="jm">${esc(j.message || '')}</div>
      <div class="bar"><i style="width:${j.status === 'done' ? 100 : (j.progress || 3)}%"></i></div>
    </div>`).join('') || '<div class="muted small">작업 없음</div>';
}

// ═══════════ 씬 추가/복제/삭제 ═══════════
function addScene(pos) {
  const scenes = state.project.scenes;
  const last = scenes.length ? scene(order().at(-1)) : null;
  const s = newScene({ title: `컷 ${scenes.length + 1}`,
    x: pos ? pos.x : (last ? last.x + 310 : 0), y: pos ? pos.y : (last ? last.y : 0) });
  scenes.push(s);
  if (last && !pos) state.project.edges.push({ from: last.id, to: s.id });
  markDirty(); canvas.render(); canvas.select(s.id);
}
function duplicateScene(id) {
  const src = scene(id);
  if (!src) return;
  const s = newScene({ ...JSON.parse(JSON.stringify(src)), id: uid('s'), title: src.title + ' 복제', x: src.x + 40, y: src.y + 320 });
  state.project.scenes.push(s);
  markDirty(); canvas.render(); canvas.select(s.id);
}
function deleteScene(id) {
  const s = scene(id);
  if (!s || !confirm(`"${s.title}" 씬을 삭제할까요?`)) return;
  const inE = state.project.edges.find(e => e.to === id), outE = state.project.edges.find(e => e.from === id);
  state.project.edges = state.project.edges.filter(e => e.from !== id && e.to !== id);
  if (inE && outE) state.project.edges.push({ from: inE.from, to: outE.to });
  state.project.scenes = state.project.scenes.filter(x => x.id !== id);
  state.selected = null;
  markDirty(); canvas.select(null); refreshAll();
}

// ═══════════ 인스펙터 ═══════════
function setMedia(sel, url) {
  const el = $(sel);
  if (url) { if (el.getAttribute('src') !== url) el.src = url; el.hidden = false; }
  else { el.removeAttribute('src'); el.hidden = true; }
}

function fillInspector() {
  const s = scene(state.selected);
  $('#insp-empty').hidden = !!s;
  $('#insp-body').hidden = !s;
  if (!s) return;
  $('#insp-title').textContent = `#${order().indexOf(s.id) + 1}  ${s.title}`;
  $$('#insp-body [data-field]').forEach(el => {
    const v = s[el.dataset.field];
    if (el.type === 'checkbox') el.checked = !!v;
    else if (document.activeElement !== el) el.value = v ?? '';
  });
  setMedia('#insp-image', s.image);
  setMedia('#insp-video', s.video);
  setMedia('#insp-depth', s.depth);
  setMedia('#insp-refshot', s.refshot);

  // 출연 캐릭터
  $('#insp-chars').innerHTML = state.project.characters.map(c => {
    const on = (s.characters || []).includes(c.id);
    const img = (c.refs && c.refs[0]) || c.sheet || '';
    return `<span class="chip ${on ? 'on' : ''}" data-cid="${c.id}"><span class="av" style="background-image:url('${img}')"></span>${esc(c.name)}</span>`;
  }).join('') || '<span class="muted small">캐릭터 없음 — 🎭 캐스팅에서 추가</span>';

  // 참조 / 변형 / 영상 히스토리
  $('#insp-refs').innerHTML = (s.refs || []).map((u, i) => `<div class="ref-item" data-i="${i}"><img src="${u}"><button class="x" data-x="${i}">✕</button></div>`).join('');
  $('#insp-variants').innerHTML = (s.variants || []).map((u, i) =>
    `<div class="ref-item ${u === s.image ? 'main' : ''}" data-i="${i}"><img src="${u}"><button class="x" data-x="${i}">✕</button></div>`).join('')
    || '<span class="muted small">생성·편집 결과가 여기에 쌓입니다</span>';
  $('#insp-vhist').innerHTML = (s.videoHistory || []).map((u, i) =>
    `<a data-u="${u}" class="${u === s.video ? 'cur' : ''}">🎬 버전 ${i + 1}${u === s.video ? ' (사용 중)' : ''}</a>`).join('')
    || '<span class="muted small">없음</span>';

  const busy = state.busy[s.id];
  ['#btn-gen-img', '#btn-gen-vid', '#btn-light', '#btn-multiview', '#btn-recreate', '#btn-rewrite', '#btn-custom-edit']
    .forEach(b => { $(b).disabled = !!busy; });
  const prev = order()[order().indexOf(s.id) - 1];
  $('#vid-autolink').disabled = !(prev && scene(prev).video);
}

// 필드 바인딩
$$('#insp-body [data-field]').forEach(el => {
  el.addEventListener(el.type === 'checkbox' || el.tagName === 'SELECT' ? 'change' : 'input', () => {
    const s = scene(state.selected);
    if (!s) return;
    const f = el.dataset.field;
    if (el.type === 'checkbox') s[f] = el.checked;
    else if (el.type === 'number') s[f] = el.value === '' ? (f === 'seed' ? -1 : 5) : parseFloat(el.value);
    else s[f] = el.value;
    markDirty();
    canvas.updateNode(s.id);
    if (f === 'title' || f === 'duration') { renderTimeline(); $('#insp-title').textContent = `#${order().indexOf(s.id) + 1}  ${s.title}`; }
  });
});

// 캐릭터 칩 토글
$('#insp-chars').addEventListener('click', e => {
  const chip = e.target.closest('.chip'); const s = scene(state.selected);
  if (!chip || !s) return;
  const cid = chip.dataset.cid;
  s.characters = (s.characters || []).includes(cid) ? s.characters.filter(x => x !== cid) : [...(s.characters || []), cid];
  markDirty(); fillInspector(); canvas.updateNode(s.id);
});

// 참조 이미지
$('#btn-add-ref').addEventListener('click', () => $('#ref-file').click());
$('#ref-file').addEventListener('change', async e => {
  const s = scene(state.selected);
  for (const f of [...e.target.files]) {
    try { s.refs.push(await uploadFile(f)); } catch (err) { toast('업로드 실패: ' + err.message); }
  }
  e.target.value = ''; markDirty(); fillInspector();
});
$('#insp-refs').addEventListener('click', e => {
  const s = scene(state.selected);
  if (e.target.dataset.x !== undefined) { s.refs.splice(+e.target.dataset.x, 1); markDirty(); fillInspector(); }
});
// 변형: 클릭 = 대표 이미지
$('#insp-variants').addEventListener('click', e => {
  const s = scene(state.selected);
  const item = e.target.closest('.ref-item'); if (!item) return;
  if (e.target.dataset.x !== undefined) {
    const u = s.variants.splice(+e.target.dataset.x, 1)[0];
    if (s.image === u) s.image = s.variants.at(-1) || null;
  } else s.image = s.variants[+item.dataset.i];
  markDirty(); refreshAll();
});
$('#insp-vhist').addEventListener('click', e => {
  const s = scene(state.selected); const u = e.target.dataset.u;
  if (u) { s.video = u; markDirty(); refreshAll(); }
});

// 업로드 버튼
function bindUpload(btnSel, inputSel, field, alsoVariant) {
  $(btnSel).addEventListener('click', () => $(inputSel).click());
  $(inputSel).addEventListener('change', async e => {
    const f = e.target.files[0]; e.target.value = '';
    const s = scene(state.selected);
    if (!f || !s) return;
    try {
      const url = await uploadFile(f);
      s[field] = url;
      if (alsoVariant === 'variants') s.variants.push(url);
      if (alsoVariant === 'videoHistory') s.videoHistory.push(url);
      markDirty(); refreshAll(); toast('업로드 완료');
    } catch (err) { toast('업로드 실패: ' + err.message); }
  });
}
bindUpload('#btn-up-img', '#img-file', 'image', 'variants');
bindUpload('#btn-up-vid', '#vid-file', 'video', 'videoHistory');
bindUpload('#btn-up-refshot', '#refshot-file', 'refshot');
$('#btn-del-img').addEventListener('click', () => { const s = scene(state.selected); if (s) { s.image = null; markDirty(); refreshAll(); } });
$('#btn-del-vid').addEventListener('click', () => { const s = scene(state.selected); if (s) { s.video = null; markDirty(); refreshAll(); } });
$('#btn-gen-img').addEventListener('click', () => genImage(state.selected, $('#img-mode').value));
$('#btn-gen-vid').addEventListener('click', () => genVideo(state.selected, { autolink: $('#vid-autolink').checked }));
$('#btn-upscale-vid').addEventListener('click', () => {
  const s = scene(state.selected);
  if (!s || !s.video) return toast('업스케일할 영상이 없습니다');
  if (state.busy[s.id]) return toast('이미 작업 중입니다');
  if (s.upscaled) return toast('이미 업스케일된 영상입니다');
  startJob('/api/generate/upscale', { scene: s, label: `🔍 ${s.title} 업스케일` }, { sceneId: s.id, busy: '업스케일' });
});
$('#btn-stage').addEventListener('click', () => openStage(state.selected));
$('#btn-layers').addEventListener('click', () => layers.open(state.selected));
$('#btn-dup').addEventListener('click', () => duplicateScene(state.selected));
$('#btn-del-scene').addEventListener('click', () => deleteScene(state.selected));

// ═══════════ 생성 ═══════════
function genImage(id, mode = 'auto') {
  const s = scene(id);
  if (!s) return Promise.resolve(null);
  if (!s.prompt.trim()) { toast('프롬프트를 먼저 입력하세요'); return Promise.resolve(null); }
  if (state.busy[id]) { toast('이미 작업 중입니다'); return Promise.resolve(null); }
  return startJob('/api/generate/scene_image', { scene: s, mode, label: `🎨 ${s.title}` }, { sceneId: id, busy: '이미지' });
}

function genVideo(id, { autolink = false, engine = null } = {}) {
  const s = scene(id);
  if (!s) return Promise.resolve(null);
  const ids = order(); const prev = scene(ids[ids.indexOf(id) - 1]);
  const link = autolink && prev && prev.video;
  if (!link && !s.image) { toast(`"${s.title}": 이미지가 없습니다`); return Promise.resolve(null); }
  if (state.busy[id]) { toast('이미 작업 중입니다'); return Promise.resolve(null); }
  const eng = engine || s.engine || 'comfy';
  return startJob('/api/generate/scene_video', {
    scene: s, engine: eng, autolink: !!link, prev_video: link ? prev.video : null,
    label: `🎬 ${s.title}${link ? ' 🔗' : ''} · ${eng}`,
  }, { sceneId: id, busy: '영상' });
}

// 디렉터 도구
function needImage() {
  const s = scene(state.selected);
  if (!s) return null;
  if (!s.image) { toast('씬 이미지가 먼저 필요합니다'); return null; }
  return s;
}
$('#btn-light').addEventListener('click', () => {
  const s = needImage(); if (!s) return;
  const custom = $('#light-custom').value.trim();
  const light = custom ? null : $('#light-preset').value;
  const label = custom || state.presets.lights.find(l => l.key === light)?.label;
  startJob('/api/generate/edit', { mode: 'light', scene: s, light, custom, label: `💡 ${s.title} · ${label}` }, { sceneId: s.id, busy: '라이트' });
});
$('#btn-multiview').addEventListener('click', () => {
  const s = needImage(); if (!s) return;
  if (!state.angles.size) return toast('각도를 하나 이상 선택하세요');
  startJob('/api/generate/edit', { mode: 'multiview', scene: s, angles: [...state.angles], label: `🔄 ${s.title} 멀티뷰 ×${state.angles.size}` },
           { sceneId: s.id, busy: '멀티뷰' });
});
$('#btn-recreate').addEventListener('click', () => {
  const s = scene(state.selected); if (!s) return;
  if (!s.refshot) return toast('📁 레퍼런스 샷을 먼저 올리세요');
  startJob('/api/generate/edit', { mode: 'recreate', scene: s, refshot: s.refshot, label: `🎯 ${s.title} 샷 재현` }, { sceneId: s.id, busy: '샷 재현' });
});
$('#btn-custom-edit').addEventListener('click', () => {
  const s = needImage(); if (!s) return;
  const custom = $('#custom-edit').value.trim();
  if (!custom) return toast('편집 지시문을 입력하세요');
  startJob('/api/generate/edit', { mode: 'custom', scene: s, custom, extra_refs: s.refs, label: `✏ ${s.title} 편집` }, { sceneId: s.id, busy: '편집' });
});

// 끝 프레임 → 다음 컷 이미지
$('#btn-next-frame').addEventListener('click', async () => {
  const s = scene(state.selected);
  if (!s || !s.video) return toast('이 씬에 영상이 없습니다');
  const ids = order(); const nxt = scene(ids[ids.indexOf(s.id) + 1]);
  if (!nxt) return toast('다음 씬이 없습니다');
  try {
    const { url } = await api('/api/lastframe', { body: { video: s.video } });
    nxt.image = url; nxt.variants.push(url);
    markDirty(); refreshAll(); toast(`⏭ "${nxt.title}" 시작 이미지로 설정`);
  } catch (e) { toast('프레임 추출 실패: ' + e.message); }
});

// 구간 재작성
$('#rw-from-player').addEventListener('click', () => {
  const v = $('#insp-video');
  $('#rw-start').value = v.currentTime.toFixed(1);
  $('#rw-end').value = Math.min(v.duration || 99, v.currentTime + 2).toFixed(1);
});
$('#btn-rewrite').addEventListener('click', () => {
  const s = scene(state.selected);
  if (!s || !s.video) return toast('재작성할 영상이 없습니다');
  const start = +$('#rw-start').value, end = +$('#rw-end').value;
  if (!(end > start)) return toast('끝 시간이 시작보다 커야 합니다');
  startJob('/api/generate/rewrite', { scene: s, start, end, prompt: $('#rw-prompt').value.trim(), engine: s.engine,
                                      label: `✂ ${s.title} ${start}~${end}s 재작성` }, { sceneId: s.id, busy: '구간 재작성' });
});

// 일괄
$('#btn-gen-all-img').addEventListener('click', async () => {
  const ids = order().filter(id => !scene(id).image && scene(id).prompt.trim());
  if (!ids.length) return toast('이미지가 필요한 씬이 없습니다');
  toast(`${ids.length}개 이미지 생성 요청 (ComfyUI 대기열에 순서대로)`);
  ids.forEach(id => genImage(id));
});
$('#btn-gen-all-vid').addEventListener('click', () => {
  const ids = order().filter(id => scene(id).image && !scene(id).video);
  if (!ids.length) return toast('영상이 필요한 씬이 없습니다');
  toast(`${ids.length}개 영상 생성 요청`);
  ids.forEach(id => genVideo(id, { engine: $('#all-engine').value }));
});
$('#btn-autolink-all').addEventListener('click', async () => {
  const ids = order();
  if (!ids.length) return;
  if (!scene(ids[0]).image && !scene(ids[0]).video) return toast('첫 컷에 이미지가 필요합니다');
  if (!confirm(`${ids.length}컷을 순서대로 이어서 생성합니다 (앞 컷 끝 프레임 → 다음 컷 시작). 기존 영상은 덮어씁니다. 진행할까요?`)) return;
  const btn = $('#btn-autolink-all'); btn.disabled = true;
  const eng = $('#all-engine').value;
  for (let i = 0; i < ids.length; i++) {
    btn.textContent = `🔗 오토링크 ${i + 1}/${ids.length}…`;
    const j = await genVideo(ids[i], { autolink: i > 0, engine: eng });
    if (!j || j.status !== 'done') { toast(`오토링크 ${i + 1}번째 컷에서 중단`, 6000); break; }
  }
  btn.disabled = false; btn.textContent = '🔗 오토링크 롱비디오';
});
$('#btn-interrupt').addEventListener('click', async () => {
  await api('/api/interrupt', { body: {} }).catch(() => {});
  toast('ComfyUI 현재 작업 중단 요청');
});

// ═══════════ 타임라인 ═══════════
function renderTimeline() {
  const ids = order();
  let total = 0;
  $('#timeline').innerHTML = ids.map((id, i) => {
    const s = scene(id);
    const d = Number(s.duration) || 5;
    total += d;
    return `<div class="tl-clip ${state.selected === id ? 'selected' : ''}" data-id="${id}" style="width:${Math.max(60, d * 22)}px">
      <div class="tl-img" style="background-image:url('${s.image || s.linkedFrame || s.depth || ''}')"></div>
      <div class="tl-cap">${i + 1}. ${esc(s.title)} · ${d}s${s.video ? ' 🎬' : ''}${s.linkedFrame ? '🔗' : ''}</div></div>`;
  }).join('') || '<div class="muted small">씬을 추가하면 여기에 순서대로 표시됩니다</div>';
  $('#tl-total').textContent = `${ids.length}컷 · 약 ${Math.round(total)}초 (내레이션 길이에 맞춰 자동 연장)`;
  $$('#timeline .tl-clip').forEach(el => el.addEventListener('click', () => canvas.select(el.dataset.id)));
}

// ═══════════ 스토리보드 ═══════════
// ═══════════ AI 작가 · 대본 · 스토리보드 ═══════════
function storyText() { return ($('#script-modal').hidden ? $('#sb-story').value.trim() : ($('#script-story').value.trim() || $('#sb-story').value.trim())); }
function updateScriptCount() {
  const n = ($('#sb-script').value.match(/\[S#\d+\]/g) || []).length;
  $('#script-count').textContent = n ? `${n}컷` : '';
}
function openScriptRoom() {
  $('#script-story').value = $('#sb-story').value || state.project.story || '';
  if (!$('#sb-script').value) $('#sb-script').value = state.project.script || '';
  updateScriptCount();
  $('#script-modal').hidden = false;
}
async function writeScript(btn) {
  const story = storyText();
  if (!story) { toast('스토리나 아이디어를 먼저 적어주세요'); return null; }
  const label = btn.textContent;
  btn.disabled = true; btn.textContent = '⏳ AI 작가가 대본 쓰는 중…';
  try {
    const res = await api('/api/script', { body: { story, n: $('#sb-n').value, style: $('#sb-style').value, tone: $('#sb-tone').value } });
    $('#sb-script').value = res.script;
    state.project.story = story; state.project.script = res.script; markDirty();
    $('#script-note').textContent = res.note; updateScriptCount();
    toast('📝 ' + res.note, 4500);
    return res.script;
  } catch (e) { toast('대본 작성 실패: ' + e.message, 6000); return null; }
  finally { btn.disabled = false; btn.textContent = label; }
}
function applyBoard(res) {
  const p = state.project;
  if ($('#sb-replace').checked) { p.scenes = []; p.edges = []; }
  // 캐스팅: 같은 이름은 재사용
  const byName = Object.fromEntries(p.characters.map(c => [c.name, c]));
  (res.characters || []).forEach(c => { if (!byName[c.name]) { byName[c.name] = normChar(c); p.characters.push(byName[c.name]); } else if (c.description && !byName[c.name].description) byName[c.name].description = c.description; });
  const startY = p.scenes.length ? Math.max(...p.scenes.map(s => s.y)) + 380 : 0;
  let prev = null;
  res.scenes.forEach((sc, i) => {
    const { characterNames = [], ...rest } = sc;
    const s = newScene({ ...rest, characters: characterNames.map(n => byName[n]?.id).filter(Boolean),
                         x: (i % 5) * 310, y: startY + Math.floor(i / 5) * 360 });
    p.scenes.push(s);
    if (prev) p.edges.push({ from: prev.id, to: s.id });
    prev = s;
  });
  if (res.script) { p.script = res.script; $('#sb-script').value = res.script; updateScriptCount(); }
  if (res.title && (!p.title || $('#sb-replace').checked)) p.title = res.title;
  markDirty(); refreshAll(); canvas.fit();
  $('#script-modal').hidden = true;
  toast((res.title ? `🎬 「${res.title}」 ` : '') + res.note, 6000);
  saveProject(true);
}
async function buildBoard(text, btn) {
  const label = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = '⏳ 씬 나누는 중…'; }
  try {
    applyBoard(await api('/api/storyboard', { body: { script: text, n: $('#sb-n').value, style: $('#sb-style').value } }));
  } catch (e) { toast('스토리보드 실패: ' + e.message, 6000); }
  finally { if (btn) { btn.disabled = false; btn.textContent = label; } }
}
// 🎬 자동 씬 나누기: 스토리보드/긴 글은 그대로 분할, 짧은 아이디어는 대본부터 (서버에서 한 번에)
async function autoBoard() {
  const btn = $('#btn-quick-board');
  const text = $('#sb-story').value.trim();
  if (!text) return toast('아이디어나 스토리보드를 먼저 적어주세요');
  if (btn.disabled) return;
  if ($('#sb-replace').checked && state.project.scenes.some(s => s.image || s.video) &&
      !confirm('기존 씬(이미지/영상 포함)을 새 씬으로 교체합니다. 계속할까요?')) return;
  const label = btn.textContent, t0 = Date.now();
  btn.disabled = true;
  const tick = setInterval(() => { btn.textContent = `⏳ AI가 씬 나누는 중… ${Math.round((Date.now() - t0) / 1000)}초`; }, 500);
  try {
    state.project.story = text;
    const style = (state.project.artStyle === 'anime' ? '2D anime illustration, cel shading. ' : '') + $('#sb-style').value;
    applyBoard(await api('/api/autoboard', { body: { text, n: $('#sb-n').value, style, tone: $('#sb-tone').value } }));
  } catch (e) { toast('자동 씬 나누기 실패: ' + e.message, 7000); }
  finally { clearInterval(tick); btn.disabled = false; btn.textContent = label; }
}
// 입력하는 동안 스토리보드인지 아이디어인지 미리 알려주기
let detectTimer = null;
function updateDetect() {
  clearTimeout(detectTimer);
  detectTimer = setTimeout(async () => {
    const text = $('#sb-story').value.trim(), el = $('#sb-detect');
    if (!text) { el.textContent = '✍ 내용을 적으면 자동으로 판단합니다'; return; }
    try {
      const { count } = await api('/api/detect_scenes', { body: { text } });
      el.textContent = count >= 2 ? `📋 스토리보드 ${count}컷 인식 → 내용 그대로 씬으로 나눕니다`
        : text.length >= 600 ? '📖 긴 글 → AI가 흐름대로 씬을 나눕니다'
        : '💡 아이디어 → AI가 대본을 쓰고 씬·캐스팅까지 합니다';
    } catch (e) { /* 미리보기 실패는 무시 */ }
  }, 400);
}
$('#btn-write-script').addEventListener('click', async e => { const s = await writeScript(e.currentTarget); if (s) openScriptRoom(); });
$('#btn-rewrite-script').addEventListener('click', e => writeScript(e.currentTarget));
$('#btn-open-script').addEventListener('click', openScriptRoom);
$('#script-close').addEventListener('click', () => { $('#script-modal').hidden = true; });
$('#btn-quick-board').addEventListener('click', autoBoard);
$('#sb-story').addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); autoBoard(); } });
$('#sb-story').addEventListener('input', updateDetect);
$('#btn-storyboard').addEventListener('click', e => {
  const text = $('#sb-script').value.trim() || storyText();
  if (!text) return toast('대본이나 스토리를 입력하세요');
  buildBoard(text, e.currentTarget);
});
$('#sb-script').addEventListener('input', e => { state.project.script = e.target.value; markDirty(); updateScriptCount(); });
$('#sb-story').addEventListener('input', e => { state.project.story = e.target.value; markDirty(); });
$('#script-story').addEventListener('input', e => { $('#sb-story').value = e.target.value; state.project.story = e.target.value; markDirty(); });

$('#global-style').addEventListener('input', e => { state.project.globalStyle = e.target.value; markDirty(); });
// 🎨 화풍 모드 (실사 / 애니메이션)
function renderArtStyle() {
  const a = state.project.artStyle || 'real';
  $$('#art-style button').forEach(b => b.classList.toggle('on', b.dataset.art === a));
}
$$('#art-style button').forEach(b => b.addEventListener('click', () => {
  state.project.artStyle = b.dataset.art; markDirty(); renderArtStyle();
  toast(b.dataset.art === 'anime' ? '🎨 애니메이션 모드: 캐릭터·이미지·영상이 애니메이션 화풍으로 생성됩니다'
                                  : '🎥 실사 모드로 전환했습니다');
}));
$('#btn-add-scene').addEventListener('click', () => addScene());

// ═══════════ 캐스팅 ═══════════
const casting = new CastingStudio({
  state, uploadFile, toast, startJob: (ep, body, opts) => startJob(ep, body, opts),
  onChange: (light) => { markDirty(); renderCastChips(); if (!light) { canvas.render(); fillInspector(); } },
});
function renderCastChips() {
  const cs = state.project.characters;
  $('#cast-count').textContent = cs.length ? `${cs.length}명` : '';
  $('#cast-chips').innerHTML = cs.map(c => `<span class="chip" data-cid="${c.id}"><span class="av" style="background-image:url('${(c.refs && c.refs[0]) || c.sheet || ''}')"></span>${esc(c.name)}</span>`).join('')
    || '<span class="muted small">스토리보드를 만들면 자동 캐스팅됩니다</span>';
}
$('#cast-chips').addEventListener('click', e => { const c = e.target.closest('.chip'); if (c) casting.open(c.dataset.cid); });
$('#btn-casting').addEventListener('click', () => casting.open());

// ═══════════ 레이어 ═══════════
const layers = new LayerEditor({ state, api, uploadFile, toast, startJob, getScene: scene,
  onChange: () => { markDirty(); refreshAll(); } });

// ═══════════ 캔버스 도구 / 단축키 ═══════════
$('#btn-zoom-in').addEventListener('click', () => canvas.zoomAt(1.2));
$('#btn-zoom-out').addEventListener('click', () => canvas.zoomAt(1 / 1.2));
$('#btn-fit').addEventListener('click', () => canvas.fit());
$('#btn-arrange').addEventListener('click', () => canvas.arrange());
window.addEventListener('keydown', e => {
  const modalOpen = $$('.modal').some(m => !m.hidden);
  if (modalOpen || ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) return;
  if (e.key === 'Delete' && state.selected) deleteScene(state.selected);
  if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveProject(); }
  if ((e.ctrlKey || e.metaKey) && e.key === 'd' && state.selected) { e.preventDefault(); duplicateScene(state.selected); }
});

// ═══════════ BGM / 렌더 ═══════════
$('#btn-bgm').addEventListener('click', () => $('#bgm-file').click());
$('#bgm-file').addEventListener('change', async e => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  try {
    state.project.bgm = await uploadFile(f); state.project.bgmName = f.name;
    $('#bgm-name').textContent = '🎵 ' + f.name; markDirty(); toast('BGM 등록 완료');
  } catch (err) { toast('BGM 업로드 실패: ' + err.message); }
});
$('#btn-render').addEventListener('click', () => {
  const ids = order();
  if (!ids.length) return toast('씬이 없습니다');
  const [w, h] = $('#rd-size').value.split('x').map(Number);
  startJob('/api/render', { name: $('#proj-name').value, scenes: state.project.scenes, order: ids, label: '🚀 최종 렌더',
    opts: { width: w, height: h, fps: +$('#rd-fps').value, narration: $('#rd-tts').checked, subtitles: $('#rd-sub').checked,
            bgm: state.project.bgm, bgm_volume: +$('#rd-bgmvol').value } });
  toast('렌더 시작 — 작업 목록에서 진행률 확인');
});
$('#btn-ai-bgm').addEventListener('click', () => {
  const ids = order();
  const total = ids.reduce((a, id) => a + (Number(scene(id).duration) || 5), 0);
  const sec = Number($('#bgm-sec').value) || Math.max(20, Math.ceil(total + 3));
  startJob('/api/generate/bgm', { style: $('#bgm-style').value.trim(), seconds: sec, label: `🎼 AI BGM ${sec}초` });
  toast(`🎼 BGM ${sec}초 생성 시작 (1~2분)`);
});

function showFinal(url) {
  const v = $('#final-video');
  if (url) { v.src = url; $('#final-link').href = url; $('#final-link').hidden = false; }
  else { v.removeAttribute('src'); $('#final-link').hidden = true; }
}

// ═══════════ 프로젝트 저장/불러오기 (외부 변경 감지) ═══════════
async function saveProject(silent = false) {
  const name = $('#proj-name').value.trim() || '새_프로젝트';
  try {
    const r = await api('/api/projects/' + encodeURIComponent(name), { body: { ...state.project, name } });
    $('#proj-name').value = r.name;
    state.project.name = r.name;
    state.mtime = r.mtime;
    state.dirty = false;
    lsSet('jk_last_project', r.name);
    if (!silent) toast('💾 저장 완료: ' + r.name);
    loadProjectList();
  } catch (e) { if (!silent) toast('저장 실패: ' + e.message); }
}
async function loadProjectList() {
  const list = await api('/api/projects').catch(() => []);
  $('#proj-list').innerHTML = '<option value="">📂 불러오기…</option>' +
    list.map(p => `<option value="${esc(p.name)}">${esc(p.name)}</option>`).join('');
  return list;
}
async function openProject(name, silent = false) {
  try {
    const p = await api('/api/projects/' + encodeURIComponent(name));
    state.mtime = p._mtime || 0; delete p._mtime;
    state.project = Object.assign(emptyProject(name), p);
    state.project.scenes = state.project.scenes.map(s => newScene(s));
    state.project.characters = (state.project.characters || []).map(normChar);
    if (!scene(state.selected)) state.selected = null;
    $('#proj-name').value = state.project.name;
    $('#global-style').value = state.project.globalStyle || ''; renderArtStyle();
    $('#sb-story').value = state.project.story || ''; $('#sb-script').value = state.project.script || ''; updateDetect();
    $('#bgm-name').textContent = state.project.bgm ? '🎵 ' + (state.project.bgmName || 'BGM') : 'BGM 없음';
    if (state.project.bgm) { $('#bgm-preview').src = state.project.bgm; $('#bgm-preview').hidden = false; } else $('#bgm-preview').hidden = true;
    showFinal(state.project.lastRender);
    state.dirty = false;
    refreshAll();
    if (!silent) { canvas.fit(); toast('📂 불러옴: ' + name); }
    lsSet('jk_last_project', state.project.name);
  } catch (e) { toast('불러오기 실패: ' + e.message); }
}
$('#btn-save').addEventListener('click', () => saveProject());
$('#proj-list').addEventListener('change', e => { if (e.target.value) openProject(e.target.value); e.target.value = ''; });
$('#btn-new').addEventListener('click', () => {
  if (state.dirty && !confirm('저장하지 않은 변경이 있습니다. 새 프로젝트를 만들까요?')) return;
  const name = '프로젝트_' + new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '');
  state.project = emptyProject(name); state.mtime = 0;
  $('#proj-name').value = name; $('#global-style').value = ''; $('#bgm-name').textContent = 'BGM 없음';
  showFinal(null); state.selected = null; canvas.select(null); refreshAll();
});

// MCP 에이전트 등 외부에서 파일이 바뀌면 자동 반영
let warnedExternal = false;
setInterval(async () => {
  if (!state.project.name) return;
  const m = await api(`/api/projects/${encodeURIComponent(state.project.name)}/meta`).catch(() => null);
  if (!m || !m.exists || !state.mtime || m.mtime <= state.mtime + 0.01) return;
  if (!state.dirty) { await openProject(state.project.name, true); toast('🤖 외부(에이전트) 변경 사항을 불러왔습니다'); warnedExternal = false; }
  else if (!warnedExternal) { warnedExternal = true; toast('⚠ 파일이 외부에서 바뀌었습니다. 저장하면 덮어씁니다 (불러오기로 새로고침 가능)', 7000); }
}, 8000);
setInterval(() => { if (state.dirty && state.project.scenes.length) saveProject(true); }, 60000);
window.addEventListener('beforeunload', e => { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });

// ═══════════ 상태 표시 ═══════════
async function refreshStatus() {
  try {
    const st = await api('/api/status');
    $('#st-comfy').className = 'dot ' + (st.comfy ? 'on' : 'off'); $('#st-comfy').title = st.comfy_url;
    $('#st-claude').className = 'dot ' + (st.claude || st.gemini ? 'on' : 'off'); $('#st-claude').title = st.claude ? 'Claude 연결됨' : (st.gemini ? 'Gemini 사용' : 'AI 키 없음 → 로컬 Ollama');
    $('#st-fal').className = 'dot ' + (st.fal ? 'on' : 'off'); $('#st-fal').title = 'fal.ai (Kling/Seedance/Hailuo)';
    state.workflows = st.workflows;
  } catch { $('#st-comfy').className = 'dot off'; }
}
setInterval(refreshStatus, 10000);

// 서버의 모든 작업(에이전트·다른 창에서 시작한 것 포함)을 작업 목록과 노드 배지에 실시간 표시
setInterval(async () => {
  const list = await api('/api/jobs').catch(() => null);
  if (!list) return;
  const sceneIds = new Set(state.project.scenes.map(s => s.id));
  const busyNow = {};
  list.forEach(j => {
    state.jobs[j.id] = j;
    if ((j.status === 'running' || j.status === 'queued') && sceneIds.has(j.scene_id))
      busyNow[j.scene_id] = { image: '이미지', video: '영상', edit: '편집', rewrite: '구간 재작성' }[j.kind] || '작업';
  });
  const changed = JSON.stringify(busyNow) !== JSON.stringify(state._extBusy || {});
  Object.keys(state._extBusy || {}).forEach(id => { if (!busyNow[id]) delete state.busy[id]; });
  Object.assign(state.busy, busyNow);
  state._extBusy = busyNow;
  renderJobs();
  if (changed) { canvas.render(); fillInspector(); }
}, 3000);

// ═══════════ 설정 ═══════════
const SETTINGS_SCHEMA = [
  ['연결'],
  ['comfy_url', 'ComfyUI 주소'], ['claude_model', 'Claude 모델'],
  ['anthropic_api_key', 'Claude API 키 (비우면 유지)', 'password'], ['gemini_api_key', 'Gemini API 키 (비우면 환경변수)', 'password'],
  ['llm_order', '대본 AI 순서 (claude,gemini,ollama)'], ['gemini_model', 'Gemini 모델'], ['ollama_model', 'Ollama 모델 (로컬)'], ['fal_api_key', 'fal.ai API 키 (클라우드 영상)', 'password'],
  ['timeout', '생성 최대 대기(초)', 'number'],
  ['워크플로우 (workflows 폴더의 API 형식 JSON)'],
  ['wf_t2i', '텍스트→이미지', 'wf'], ['wf_depth', '깊이맵→이미지', 'wf'],
  ['wf_edit', '편집 모델 (캐스팅/라이트/멀티뷰/재현/합성)', 'wf'], ['wf_i2v', '이미지→영상', 'wf'],
  ['이미지 모델 (SDXL)'],
  ['ckpt', '체크포인트 파일명'], ['controlnet_depth', 'ControlNet Depth 파일명'],
  ['img_width', '가로', 'number'], ['img_height', '세로', 'number'],
  ['img_steps', '스텝', 'number'], ['img_cfg', 'CFG', 'number'],
  ['cn_strength', 'ControlNet 강도', 'number'], ['negative', '기본 네거티브'],
  ['편집 모델 (Qwen-Image-Edit 2509)'],
  ['qwen_unet', 'UNET 파일명'], ['qwen_clip', 'CLIP(Qwen2.5-VL) 파일명'], ['qwen_vae', 'VAE 파일명'],
  ['edit_steps', '스텝 (Lightning LoRA 쓰면 4~8)', 'number'], ['edit_cfg', 'CFG (Lightning 이면 1.0)', 'number'],
  ['영상 모델 (Wan 2.2 · 프레임 수는 4n+1)'],
  ['wan14_high_gguf', '⚡빠른 모드 고노이즈 GGUF'], ['wan14_low_gguf', '⚡빠른 모드 저노이즈 GGUF'], ['fast_width', '⚡빠른 모드 가로', 'number'], ['fast_height', '⚡빠른 모드 세로', 'number'],
  ['wan14_high', '14B 고노이즈 모델'], ['wan14_low', '14B 저노이즈 모델'],
  ['wan14_lora_high', '14B 고노이즈 Lightx2v LoRA'], ['wan14_lora_low', '14B 저노이즈 Lightx2v LoRA'],
  ['wan21_vae', '14B용 VAE (Wan 2.1)'], ['vid14_steps', '14B 스텝 (LoRA 사용 시 4)', 'number'], ['vid14_split', '고/저노이즈 전환 스텝', 'number'],
  ['wan_unet', '5B UNET 파일명'], ['wan_clip', 'CLIP(T5) 파일명'], ['wan_vae', '5B VAE 파일명'],
  ['vid_frames', '프레임 수', 'number'], ['vid_width', '가로', 'number'], ['vid_height', '세로', 'number'],
  ['vid_fps', 'FPS', 'number'], ['vid_steps', '스텝', 'number'], ['vid_cfg', 'CFG', 'number'],
  ['클라우드 영상 모델 (fal.ai 모델 ID)'],
  ['fal_kling', 'Kling'], ['fal_seedance', 'Seedance'], ['fal_hailuo', 'Hailuo'], ['cloud_duration', '길이(초)', 'number'],
  ['프레임 보간 · AI BGM'],
  ['interp_multiplier', '보간 배수 (2 = 16→32fps)', 'number'], ['rife_model', 'RIFE 모델'],
  ['wf_bgm', 'BGM 워크플로우', 'wf'], ['ace15_ckpt', 'ACE-Step 1.5 모델'], ['bgm_bpm', 'BGM BPM', 'number'], ['bgm_key', 'BGM 조성 (예: D minor)'],
  ['bgm_steps', 'BGM 스텝', 'number'], ['bgm_cfg', 'BGM CFG', 'number'], ['bgm_default_style', '기본 BGM 스타일'],
  ['내레이션 / 자막'],
  ['tts_engine', '내레이션 엔진 (voicebox / edge)'], ['voicebox_profile', 'Voicebox 프로필 이름'], ['voicebox_instruct', 'Voicebox 말투 지시'],
  ['tts_voice', 'edge-tts 목소리'], ['tts_rate', '말하기 속도 (예: +10%)'], ['font_path', '자막 폰트 경로'],
];
async function openSettings() {
  state.settings = await api('/api/settings');
  await refreshStatus();
  const wfs = state.workflows || [];
  $('#settings-form').innerHTML = SETTINGS_SCHEMA.map(([key, label, type]) => {
    if (!label) return `<h4>${key}</h4>`;
    const val = state.settings[key] ?? '';
    if (type === 'wf') {
      const opts = [...new Set([val, ...wfs])].filter(Boolean).map(w => `<option ${w === val ? 'selected' : ''}>${esc(w)}</option>`).join('');
      return `<label>${label}<select data-key="${key}">${opts}</select></label>`;
    }
    if (type === 'password')
      return `<label>${label}<input data-key="${key}" type="password" value="" placeholder="${esc(val || '미설정 (환경변수도 가능)')}"></label>`;
    return `<label>${label}<input data-key="${key}" type="${type === 'number' ? 'number' : 'text'}" step="any" value="${esc(val)}"></label>`;
  }).join('');
  $('#settings-modal').hidden = false;
}
$('#btn-settings').addEventListener('click', openSettings);
$('#set-close').addEventListener('click', () => ($('#settings-modal').hidden = true));
$('#set-save').addEventListener('click', async () => {
  const body = {};
  $$('#settings-form [data-key]').forEach(el => { body[el.dataset.key] = el.value; });
  try {
    state.settings = await api('/api/settings', { body });
    $('#settings-modal').hidden = true; toast('⚙ 설정 저장 완료'); refreshStatus();
  } catch (e) { toast('설정 저장 실패: ' + e.message); }
});

// ═══════════ 3D 디렉터 스테이지 ═══════════
let stage = null, stageSceneId = null;
async function openStage(id) {
  const s = scene(id);
  if (!s) return;
  if (!stage) {
    try {
      const mod = await import('./stage3d.js');
      $('#stage-modal').hidden = false;
      stage = new mod.Stage3D($('#stage-view'));
      bindStageUI();
    } catch (e) {
      $('#stage-modal').hidden = true;
      return toast('3D 엔진(Three.js) 로드 실패 — 인터넷 연결 확인: ' + e.message, 6000);
    }
  }
  stageSceneId = id;
  $('#stage-modal').hidden = false;
  $('#stage-scene-name').textContent = `씬: ${s.title}`;
  stage.setAspect((state.settings.img_width || 16) / (state.settings.img_height || 9));
  stage.load(s.stage);
  $('#st-fov').value = stage.camera.fov; $('#st-fov-val').textContent = Math.round(stage.camera.fov);
  setMedia('#st-preview', s.depth);
}
function bindStageUI() {
  $$('[data-add]').forEach(b => b.addEventListener('click', () => stage.add(b.dataset.add)));
  $$('[data-mode]').forEach(b => b.addEventListener('click', () => {
    stage.tc.setMode(b.dataset.mode);
    $$('[data-mode]').forEach(x => x.classList.toggle('active', x === b));
  }));
  $$('[data-cam]').forEach(b => b.addEventListener('click', () => stage.shot(b.dataset.cam)));
  $('#st-fov').addEventListener('input', e => { stage.setFov(+e.target.value); $('#st-fov-val').textContent = e.target.value; });
  $('#st-delete').addEventListener('click', () => stage.remove(stage.selected));
  $('#st-pose').addEventListener('click', () => {
    const p = stage.cyclePose();
    toast(p ? '포즈: ' + { stand: '서기', walk: '걷기', arms_up: '만세', point: '가리키기', sit: '앉기' }[p] : '인물을 먼저 선택하세요');
  });
  $('#st-close').addEventListener('click', () => {
    const s = scene(stageSceneId);
    if (s) { s.stage = stage.serialize(); markDirty(); }
    $('#stage-modal').hidden = true;
  });
  const capture = async kind => {
    const s = scene(stageSceneId); if (!s) return;
    const w = state.settings.img_width || 1344, h = state.settings.img_height || 768;
    const data = kind === 'depth' ? stage.captureDepth(w, h) : stage.captureRGB(w, h);
    try {
      const { url } = await api('/api/upload_dataurl', { body: { data, prefix: kind === 'depth' ? 'depth' : 'layout' } });
      s.stage = stage.serialize();
      if (kind === 'depth') { s.depth = url; s.useDepth = true; setMedia('#st-preview', url); toast('📸 깊이맵 적용 — 이미지 생성 시 이 구도가 사용됩니다'); }
      else { s.refs.push(url); toast('🖼 레이아웃을 씬 참조 이미지로 추가'); }
      markDirty(); refreshAll();
    } catch (e) { toast('캡처 저장 실패: ' + e.message); }
  };
  $('#st-cap-depth').addEventListener('click', () => capture('depth'));
  $('#st-cap-rgb').addEventListener('click', () => capture('rgb'));
}

// ═══════════ 시작 ═══════════
(async function init() {
  renderJobs();
  refreshStatus();
  state.settings = await api('/api/settings').catch(() => ({}));
  state.presets = await api('/api/presets').catch(() => state.presets);
  $('#light-preset').innerHTML = state.presets.lights.map(l => `<option value="${l.key}">${esc(l.label)}</option>`).join('');
  const engOpts = state.presets.engines.map(e => `<option value="${e.key}">${esc(e.label)}</option>`).join('');
  $('#scene-engine').innerHTML = engOpts; $('#all-engine').innerHTML = engOpts;
  const renderAngles = () => {
    $('#angle-picks').innerHTML = state.presets.angles.map(a =>
      `<span class="chip ${state.angles.has(a.key) ? 'on' : ''}" data-a="${a.key}">${esc(a.label)}</span>`).join('');
  };
  renderAngles();
  $('#angle-picks').addEventListener('click', e => {
    const a = e.target.closest('.chip')?.dataset.a; if (!a) return;
    state.angles.has(a) ? state.angles.delete(a) : state.angles.add(a); renderAngles();
  });
  const list = await loadProjectList();
  const urlProj = new URLSearchParams(location.search).get('project');   // ?project=이름 으로 바로 열기
  const last = urlProj || lsGet('jk_last_project');
  if (last && list.some(p => p.name === last)) await openProject(last);
  else refreshAll();
})();
