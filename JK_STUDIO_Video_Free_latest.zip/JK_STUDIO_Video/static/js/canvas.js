// ═══════════════════════════════════════════════
// JK STUDIO 영상 스튜디오 - 무한 캔버스 노드 편집기
// 팬/줌, 노드 드래그, 포트 연결(씬 순서), 연결 삭제
// ═══════════════════════════════════════════════

const NODE_W = 250;
const PORT_Y = 48; // 포트 중심 y (노드 상단 기준)

// 연결(edges)을 따라 씬 재생 순서 계산
export function computeOrder(scenes, edges) {
  const byId = Object.fromEntries(scenes.map(s => [s.id, s]));
  const next = {}, hasIn = new Set();
  edges.forEach(e => {
    if (byId[e.from] && byId[e.to]) { next[e.from] = e.to; hasIn.add(e.to); }
  });
  const heads = scenes.filter(s => !hasIn.has(s.id)).sort((a, b) => a.x - b.x || a.y - b.y);
  const order = [], seen = new Set();
  for (const h of heads) {
    let cur = h.id;
    while (cur && !seen.has(cur)) { seen.add(cur); order.push(cur); cur = next[cur]; }
  }
  // 순환 연결 등으로 빠진 씬은 x 위치 순으로 뒤에 추가
  scenes.filter(s => !seen.has(s.id)).sort((a, b) => a.x - b.x).forEach(s => order.push(s.id));
  return order;
}

export class NodeCanvas {
  /**
   * @param {HTMLElement} viewport
   * @param {object} cb  { getScenes, getEdges, setEdges, onSelect, onChange, onAction, getBusy }
   */
  constructor(viewport, cb) {
    this.vp = viewport;
    this.world = viewport.querySelector('#world');
    this.svg = viewport.querySelector('#edges');
    this.cb = cb;
    this.view = { x: 60, y: 60, z: 1 };
    this.selected = null;
    this.nodeEls = {};
    this._bindViewport();
    this.applyView();
  }

  // ── 뷰 변환 ──
  applyView() {
    const { x, y, z } = this.view;
    this.world.style.transform = `translate(${x}px, ${y}px) scale(${z})`;
    this.vp.style.backgroundPosition = `${x}px ${y}px`;
    this.vp.style.backgroundSize = `${24 * z}px ${24 * z}px`;
    const lbl = document.getElementById('zoom-label');
    if (lbl) lbl.textContent = Math.round(z * 100) + '%';
  }
  toWorld(clientX, clientY) {
    const r = this.vp.getBoundingClientRect();
    return { x: (clientX - r.left - this.view.x) / this.view.z, y: (clientY - r.top - this.view.y) / this.view.z };
  }
  zoomAt(factor, cx, cy) {
    const r = this.vp.getBoundingClientRect();
    if (cx === undefined) { cx = r.left + r.width / 2; cy = r.top + r.height / 2; }
    const mx = cx - r.left, my = cy - r.top;
    const nz = Math.min(2.5, Math.max(0.15, this.view.z * factor));
    this.view.x = mx - (mx - this.view.x) * (nz / this.view.z);
    this.view.y = my - (my - this.view.y) * (nz / this.view.z);
    this.view.z = nz;
    this.applyView();
  }
  fit() {
    const scenes = this.cb.getScenes();
    if (!scenes.length) { this.view = { x: 60, y: 60, z: 1 }; return this.applyView(); }
    const minX = Math.min(...scenes.map(s => s.x)), minY = Math.min(...scenes.map(s => s.y));
    const maxX = Math.max(...scenes.map(s => s.x + NODE_W)), maxY = Math.max(...scenes.map(s => s.y + 290));
    const r = this.vp.getBoundingClientRect();
    const z = Math.min(1.2, Math.max(0.15, Math.min((r.width - 80) / (maxX - minX), (r.height - 80) / (maxY - minY))));
    this.view = { z, x: (r.width - (maxX - minX) * z) / 2 - minX * z, y: (r.height - (maxY - minY) * z) / 2 - minY * z };
    this.applyView();
  }

  _bindViewport() {
    // 휠 줌
    this.vp.addEventListener('wheel', e => {
      e.preventDefault();
      this.zoomAt(Math.exp(-e.deltaY * 0.0015), e.clientX, e.clientY);
    }, { passive: false });

    // 빈 곳 드래그 = 화면 이동
    this.vp.addEventListener('pointerdown', e => {
      if (e.target !== this.vp && e.target !== this.world && e.target !== this.svg) return;
      if (e.target.closest && e.target.closest('.canvas-tools')) return;
      const sx = e.clientX, sy = e.clientY, ox = this.view.x, oy = this.view.y;
      let moved = false;
      this.vp.classList.add('panning');
      const mv = ev => {
        if (Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) > 3) moved = true;
        this.view.x = ox + ev.clientX - sx; this.view.y = oy + ev.clientY - sy; this.applyView();
      };
      const up = () => {
        this.vp.classList.remove('panning');
        window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
        if (!moved) this.select(null);
      };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    });

    // 더블클릭 = 그 위치에 새 씬
    this.vp.addEventListener('dblclick', e => {
      if (e.target !== this.vp && e.target !== this.world) return;
      const p = this.toWorld(e.clientX, e.clientY);
      this.cb.onAction('add-at', null, { x: p.x - NODE_W / 2, y: p.y - 40 });
    });
  }

  // ── 선택 ──
  select(id) {
    this.selected = id;
    Object.entries(this.nodeEls).forEach(([nid, el]) => el.classList.toggle('selected', nid === id));
    this.cb.onSelect(id);
  }

  // ── 전체 다시 그리기 ──
  render() {
    const scenes = this.cb.getScenes();
    const order = computeOrder(scenes, this.cb.getEdges());
    const idx = Object.fromEntries(order.map((id, i) => [id, i + 1]));
    // 사라진 노드 제거
    Object.keys(this.nodeEls).forEach(id => {
      if (!scenes.find(s => s.id === id)) { this.nodeEls[id].remove(); delete this.nodeEls[id]; }
    });
    scenes.forEach(s => {
      let el = this.nodeEls[s.id];
      if (!el) { el = this._createNode(s); this.nodeEls[s.id] = el; this.world.appendChild(el); }
      this._fillNode(el, s, idx[s.id]);
    });
    this.drawEdges();
  }

  updateNode(id) {
    const s = this.cb.getScenes().find(x => x.id === id);
    const el = this.nodeEls[id];
    if (!s || !el) return;
    const order = computeOrder(this.cb.getScenes(), this.cb.getEdges());
    this._fillNode(el, s, order.indexOf(id) + 1);
  }

  _createNode(s) {
    const el = document.createElement('div');
    el.className = 'node';
    el.dataset.id = s.id;
    el.innerHTML = `
      <div class="port in" title="이전 씬에서 연결"></div>
      <div class="port out" title="드래그해서 다음 씬에 연결"></div>
      <div class="node-head"><span class="node-idx"></span><span class="node-title"></span><span class="node-dur"></span></div>
      <div class="node-thumb"></div>
      <div class="node-prompt"></div>
      <div class="node-foot">
        <button class="btn" data-act="img" title="이미지 생성">🎨</button>
        <button class="btn" data-act="vid" title="이미지→영상">🎬</button>
        <button class="btn" data-act="stage" title="3D 스테이지">🧊</button>
        <button class="btn" data-act="dup" title="복제">⧉</button>
        <button class="btn" data-act="del" title="삭제">🗑</button>
      </div>`;

    // 버튼
    el.querySelectorAll('[data-act]').forEach(b => b.addEventListener('pointerdown', e => e.stopPropagation()));
    el.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', e => {
      e.stopPropagation();
      this.cb.onAction(b.dataset.act, s.id);
    }));

    // 노드 드래그
    el.addEventListener('pointerdown', e => {
      if (e.target.classList.contains('port')) return;
      e.stopPropagation();
      this.select(s.id);
      const scene = this.cb.getScenes().find(x => x.id === s.id);
      const sx = e.clientX, sy = e.clientY, ox = scene.x, oy = scene.y;
      let moved = false;
      const mv = ev => {
        moved = true;
        scene.x = Math.round(ox + (ev.clientX - sx) / this.view.z);
        scene.y = Math.round(oy + (ev.clientY - sy) / this.view.z);
        el.style.left = scene.x + 'px'; el.style.top = scene.y + 'px';
        this.drawEdges();
      };
      const up = () => {
        window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
        if (moved) { this.render(); this.cb.onChange(); }
      };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    });

    // 출력 포트 → 연결 드래그
    el.querySelector('.port.out').addEventListener('pointerdown', e => {
      e.stopPropagation(); e.preventDefault();
      const temp = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      temp.setAttribute('class', 'temp');
      this.svg.appendChild(temp);
      const scene = this.cb.getScenes().find(x => x.id === s.id);
      const from = { x: scene.x + NODE_W, y: scene.y + PORT_Y };
      const mv = ev => { temp.setAttribute('d', this._curve(from, this.toWorld(ev.clientX, ev.clientY))); };
      const up = ev => {
        window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
        temp.remove();
        const target = document.elementFromPoint(ev.clientX, ev.clientY);
        const nodeEl = target && target.closest('.node');
        if (nodeEl && nodeEl.dataset.id !== s.id) this.connect(s.id, nodeEl.dataset.id);
      };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    });

    // 썸네일 영상은 마우스 올리면 재생
    el.addEventListener('mouseenter', () => { const v = el.querySelector('video'); if (v) v.play().catch(() => {}); });
    el.addEventListener('mouseleave', () => { const v = el.querySelector('video'); if (v) v.pause(); });
    return el;
  }

  _fillNode(el, s, index) {
    el.style.left = s.x + 'px';
    el.style.top = s.y + 'px';
    el.querySelector('.node-idx').textContent = index || '?';
    el.querySelector('.node-title').textContent = s.title || '제목 없음';
    el.querySelector('.node-dur').textContent = (s.duration || 5) + 's';
    el.querySelector('.node-prompt').textContent = s.prompt || '(프롬프트 없음)';
    el.classList.toggle('selected', this.selected === s.id);

    // 썸네일: 영상 > 이미지 > 깊이맵 > 빈칸 (바뀐 경우만 교체)
    const src = s.video || s.image || s.depth || '';
    const key = src + '|' + (s.image || s.linkedFrame || '');
    const kind = s.video ? 'video' : (src ? 'img' : 'none');
    const th = el.querySelector('.node-thumb');
    if (th.dataset.src !== key) {
      th.dataset.src = key;
      const poster = s.image || s.linkedFrame || '';
      if (kind === 'video') th.innerHTML = `<video src="${src}" poster="${poster}" muted loop preload="metadata"></video>`;
      else if (kind === 'img') th.innerHTML = `<img src="${src}" draggable="false">`;
      else th.innerHTML = '🎞';
      th.insertAdjacentHTML('beforeend', '<div class="node-badges"></div>');
    }
    const busy = this.cb.getBusy(s.id);
    const badges = [];
    if (s.depth) badges.push('<span class="badge">3D</span>');
    if (s.image) badges.push('<span class="badge">IMG</span>');
    if (s.video) badges.push('<span class="badge">VID</span>');
    if (s.linkedFrame) badges.push('<span class="badge">🔗</span>');
    if (busy) badges.push(`<span class="badge busy">⏳ ${busy}</span>`);
    const bEl = th.querySelector('.node-badges');
    if (bEl) bEl.innerHTML = badges.join('');

    // 출연 캐릭터 아바타
    let cast = th.querySelector('.node-cast');
    if (!cast) { cast = document.createElement('div'); cast.className = 'node-cast'; th.appendChild(cast); }
    const chars = (this.cb.getCharacters ? this.cb.getCharacters() : []).filter(c => (s.characters || []).includes(c.id));
    cast.innerHTML = chars.map(c => {
      const img = (c.refs && c.refs[0]) || c.sheet || '';
      return `<span class="av" title="${c.name}" style="background-image:url('${img}')"></span>`;
    }).join('');
    if (s.variants && s.variants.length > 1) badges.push(`<span class="badge">×${s.variants.length}</span>`);
    if (bEl) bEl.innerHTML = badges.join('');
  }

  // ── 연결 ──
  connect(from, to) {
    // 한 씬은 다음 씬 1개, 이전 씬 1개만 (선형 스토리)
    let edges = this.cb.getEdges().filter(e => e.from !== from && e.to !== to);
    // 순환 방지: to 에서 출발해 from 에 닿으면 거부
    const next = Object.fromEntries(edges.map(e => [e.from, e.to]));
    let cur = to, guard = 0;
    while (cur && guard++ < 1000) { if (cur === from) return; cur = next[cur]; }
    edges.push({ from, to });
    this.cb.setEdges(edges);
    this.render();
    this.cb.onChange();
  }

  _curve(a, b) {
    const dx = Math.max(60, Math.abs(b.x - a.x) * 0.5);
    return `M ${a.x} ${a.y} C ${a.x + dx} ${a.y}, ${b.x - dx} ${b.y}, ${b.x} ${b.y}`;
  }

  drawEdges() {
    const scenes = this.cb.getScenes();
    const byId = Object.fromEntries(scenes.map(s => [s.id, s]));
    this.svg.querySelectorAll('path:not(.temp)').forEach(p => p.remove());
    this.cb.getEdges().forEach(e => {
      const a = byId[e.from], b = byId[e.to];
      if (!a || !b) return;
      const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      p.setAttribute('d', this._curve({ x: a.x + NODE_W, y: a.y + PORT_Y }, { x: b.x, y: b.y + PORT_Y }));
      p.addEventListener('pointerdown', ev => ev.stopPropagation());
      p.addEventListener('click', ev => {
        ev.stopPropagation();
        this.cb.setEdges(this.cb.getEdges().filter(x => !(x.from === e.from && x.to === e.to)));
        this.render(); this.cb.onChange();
      });
      this.svg.appendChild(p);
    });
  }

  // ── 순서대로 가로 정렬 ──
  arrange() {
    const scenes = this.cb.getScenes();
    const order = computeOrder(scenes, this.cb.getEdges());
    const perRow = 5;
    order.forEach((id, i) => {
      const s = scenes.find(x => x.id === id);
      s.x = (i % perRow) * 310;
      s.y = Math.floor(i / perRow) * 360;
    });
    this.render(); this.fit(); this.cb.onChange();
  }
}
