@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   JK STUDIO 영상 스튜디오 v3.0 - 설치
echo   JASON KINGDOM STUDIO
echo ============================================
where python >nul 2>nul || (echo [오류] Python 3.11 이상을 먼저 설치하세요: https://www.python.org && pause && exit /b 1)
python -m venv venv
venv\Scripts\python.exe -m pip install --upgrade pip
venv\Scripts\pip.exe install -r requirements.txt
echo.
echo 설치 완료! JK_STUDIO_실행.bat 으로 실행하세요.
pause
