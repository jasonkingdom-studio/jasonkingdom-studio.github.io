# -*- coding: utf-8 -*-
"""
JK MUSIC Studio PRO — 보관함 일괄 리마스터 (remaster_all.py)
────────────────────────────────────────────────────────────
보관함의 모든 곡을 AI 원본(audio.flac)에서 현재 앱과 같은 '클린 마스터'로 다시 만든다.
· 기존 MP3 는 outputs/_backup_mp3_날짜시간/ 에 먼저 백업 (되돌리기 가능)
· 곡 정보(meta.json)의 마스터링 항목도 갱신
· 앱에서 작곡이 진행 중이면 끝날 때까지 기다린다

사용법: python remaster_all.py
"""
import re
import sys
import ast
import json
import time
import shutil
import subprocess
import urllib.request
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

BASE = Path(__file__).resolve().parent
OUT = BASE / "outputs"
TARGET_LUFS = -14.0
LIMITER = "alimiter=limit=0.89:attack=5:release=80:level=0"


def clean_body():
    """server.py 의 MASTER_CLEAN_BODY 를 그대로 읽어 앱과 똑같은 처리를 보장"""
    tree = ast.parse((BASE / "server.py").read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(getattr(t, "id", "") == "MASTER_CLEAN_BODY" for t in node.targets):
            return ast.literal_eval(node.value)
    raise RuntimeError("server.py 에서 MASTER_CLEAN_BODY 를 찾지 못했습니다")


def integrated(src, af):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(src), "-af", af + ",ebur128=peak=true",
                        "-f", "null", "-"], capture_output=True, text=True, encoding="utf-8", errors="replace").stderr
    s = r[r.rfind("Summary:"):]
    return float(re.search(r"I:\s*(-?[\d.]+) LUFS", s).group(1)), float(re.search(r"Peak:\s*(-?[\d.]+)", s).group(1))


def wait_idle():
    while True:
        try:
            with urllib.request.urlopen("http://127.0.0.1:7860/api/jobs/active", timeout=5) as r:
                if not json.loads(r.read().decode("utf-8")).get("jobs"):
                    return
        except Exception:
            return
        print("⏳ 앱에서 작곡 중 — 끝날 때까지 기다립니다…", flush=True)
        time.sleep(20)


def main():
    body = clean_body()
    wait_idle()
    backup = OUT / f"_backup_mp3_{time.strftime('%Y%m%d_%H%M%S')}"
    backup.mkdir(parents=True, exist_ok=True)

    # (원본 flac, 결과 mp3, meta.json 또는 None, 표시 이름)
    targets = []
    for d in sorted(OUT.glob("song_*")):
        flac, mp3 = d / "audio.flac", OUT / f"{d.name}.mp3"
        if d.is_dir() and flac.exists():
            meta = d / "meta.json"
            title = d.name
            if meta.exists():
                try:
                    title = json.loads(meta.read_text(encoding="utf-8")).get("title", d.name)
                except Exception:
                    pass
            targets.append((flac, mp3, meta if meta.exists() else None, title))
    if (OUT / "jk_song.flac").exists():
        targets.append((OUT / "jk_song.flac", OUT / "jk_song.mp3", None, "[JK MUSIC #1] 비 내린 거리 위에"))

    print(f"🎚 클린 마스터 리마스터 대상 {len(targets)}곡 · 백업 폴더: {backup}", flush=True)
    ok, fail = 0, []
    for flac, mp3, meta, title in targets:
        try:
            if mp3.exists():
                shutil.copy2(mp3, backup / mp3.name)
            gain = max(-12.0, min(12.0, TARGET_LUFS - integrated(flac, body)[0]))
            tmp = mp3.with_suffix(".tmp.mp3")
            subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(flac),
                            "-af", f"{body},volume={gain:.2f}dB,{LIMITER}", "-ar", "44100", "-b:a", "320k", str(tmp)],
                           check=True)
            tmp.replace(mp3)                                   # 완성된 뒤에만 교체(중간 실패 시 기존 파일 보존)
            i, pk = integrated(mp3, "anull")
            if meta:
                m = json.loads(meta.read_text(encoding="utf-8"))
                m["mastering"] = "클린 마스터링 (일괄 리마스터)"
                m["remastered_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
                meta.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
            ok += 1
            print(f"  ✅ {title:<40} {i:6.1f} LUFS · 피크 {pk:5.1f}", flush=True)
        except Exception as e:
            fail.append(title)
            print(f"  ❌ {title}: {e}", flush=True)
    print(f"\n완료: 성공 {ok}곡 · 실패 {len(fail)}곡" + (f" → {fail}" if fail else ""), flush=True)


if __name__ == "__main__":
    main()
