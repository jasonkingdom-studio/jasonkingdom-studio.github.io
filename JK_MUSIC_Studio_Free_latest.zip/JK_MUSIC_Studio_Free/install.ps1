﻿# ════════════════════════════════════════════════════════════════
#  JK MUSIC Studio — 설치 프로그램 (install.ps1)
#  install.bat 을 더블클릭하면 실행됩니다.
#  1) 그래픽카드·디스크 확인  2) Python 3.12 가상환경(uv)  3) AI·오디오 패키지
#  4) ffmpeg  5) 작곡 모델(YuE2, 공식 저장소에서 직접 다운로드)  6) 바탕화면 바로가기
#  여러 번 실행해도 안전합니다(이미 된 단계는 건너뜀, 모델은 이어받기).
# ════════════════════════════════════════════════════════════════
# 외부 프로그램(uv·python·ffmpeg)은 진행 메시지를 stderr 로 내보내므로 "Stop" 으로 두면
# Windows PowerShell 5.1 이 이를 오류로 오인해 조용히 멈춘다 → 성공 여부는 $LASTEXITCODE 로 판단하고,
# 반드시 멈춰야 하는 명령에만 -ErrorAction Stop 을 붙인다.
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"          # Invoke-WebRequest 속도 저하 방지
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$App = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $App
$Tools = Join-Path $App "tools"
$Log = Join-Path $App "install_log.txt"
New-Item -ItemType Directory -Force $Tools | Out-Null
Start-Transcript -Path $Log -Append | Out-Null

function Step($n, $msg) { Write-Host ""; Write-Host "[$n/6] $msg" -ForegroundColor Cyan }
function Ok($msg)       { Write-Host "   ✔ $msg" -ForegroundColor Green }
function Warn($msg)     { Write-Host "   ⚠ $msg" -ForegroundColor Yellow }
function Fail($msg) {
    Write-Host ""; Write-Host "   ✖ $msg" -ForegroundColor Red
    Write-Host "   자세한 기록: $Log" -ForegroundColor Red
    Stop-Transcript | Out-Null; if ($env:JK_INSTALL_AUTO -ne "1") { Read-Host "엔터를 누르면 창이 닫힙니다" }; exit 1
}
function Download($url, $out) {
    for ($i = 1; $i -le 3; $i++) {
        try { Invoke-WebRequest $url -OutFile $out -UseBasicParsing -TimeoutSec 600 -ErrorAction Stop; return }
        catch { Warn "다운로드 재시도 $i/3 : $($_.Exception.Message)"; Start-Sleep 3 }
    }
    Fail "다운로드에 실패했습니다: $url  (인터넷 연결을 확인하고 install.bat 을 다시 실행해 주세요)"
}

Write-Host "════════════════════════════════════════════" -ForegroundColor Magenta
Write-Host "   JK MUSIC Studio 설치를 시작합니다" -ForegroundColor Magenta
Write-Host "   (처음 설치는 인터넷 속도에 따라 20~60분 걸립니다)" -ForegroundColor Magenta
Write-Host "════════════════════════════════════════════" -ForegroundColor Magenta

# ── 1. 그래픽카드 · 디스크 확인 ─────────────────────────────────
Step 1 "그래픽카드와 저장 공간 확인"
$smi = Get-Command nvidia-smi -ErrorAction SilentlyContinue
if (-not $smi) { $smi = Get-Item "$env:SystemRoot\System32\nvidia-smi.exe" -ErrorAction SilentlyContinue }
if ($smi) {
    $gpu = (& $smi.Source --query-gpu=name,memory.total --format=csv,noheader 2>$null | Select-Object -First 1)
    Ok "그래픽카드: $gpu"
    $mem = [int](($gpu -split ",")[-1] -replace "[^0-9]", "")
    if ($mem -gt 0 -and $mem -lt 15000) { Warn "그래픽카드 메모리가 16GB 보다 작습니다. 긴 곡은 메모리 부족으로 실패할 수 있습니다." }
} else {
    Warn "NVIDIA 그래픽카드(또는 드라이버)를 찾지 못했습니다. 이 앱은 NVIDIA 그래픽카드가 있어야 작곡할 수 있습니다."
    $a = if ($env:JK_INSTALL_AUTO -eq "1") { "n" } else { Read-Host "   그래도 설치를 계속할까요? (y/n)" }
    if ($a -ne "y") { Fail "설치를 취소했습니다." }
}
$drive = (Get-Item $App).PSDrive
$freeGB = [math]::Round($drive.Free / 1GB)
if ($freeGB -lt 20) { Fail "저장 공간이 부족합니다. $($drive.Name): 드라이브에 20GB 이상 필요합니다 (현재 여유 ${freeGB}GB)." }
Ok "저장 공간 여유 ${freeGB}GB"

# ── 2. uv + Python 3.12 가상환경 ─────────────────────────────────
Step 2 "Python 실행 환경 준비"
$uv = Join-Path $Tools "uv\uv.exe"
if (-not (Test-Path $uv)) {
    $zip = Join-Path $Tools "uv.zip"
    Download "https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip" $zip
    try { Expand-Archive $zip -DestinationPath (Join-Path $Tools "uv") -Force -ErrorAction Stop } catch { Fail "uv 압축 해제 실패: $($_.Exception.Message)" }
    Remove-Item $zip
}
if (-not (Test-Path $uv)) { Fail "uv 를 준비하지 못했습니다." }
$env:UV_CACHE_DIR = Join-Path $Tools "uv-cache"          # 모든 파일을 앱 폴더 안에 보관
$env:UV_PYTHON_INSTALL_DIR = Join-Path $Tools "python"
$env:UV_LINK_MODE = "copy"
$py = Join-Path $App ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) {
    & $uv venv (Join-Path $App ".venv") --python 3.12 --python-preference only-managed
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $py)) { Fail "Python 3.12 환경을 만들지 못했습니다." }
}
Ok "Python: $(& $py --version)"

# ── 3. 패키지 (PyTorch CUDA 12.8 · YuE2 엔진 · 서버 · Demucs) ───────
Step 3 "AI·오디오 패키지 설치 (PyTorch 약 3GB, 한 번만 받습니다)"
& $uv pip install --python $py -r (Join-Path $App "requirements.txt") `
    --extra-index-url https://download.pytorch.org/whl/cu128 --index-strategy unsafe-best-match
if ($LASTEXITCODE -ne 0) { Fail "패키지 설치에 실패했습니다." }
& $uv pip install --python $py (Join-Path $App "engine\YuE")
if ($LASTEXITCODE -ne 0) { Fail "YuE2 작곡 엔진 설치에 실패했습니다." }
$chk = & $py -c "import torch,yue2,fastapi,demucs;print('torch',torch.__version__,'| GPU', torch.cuda.is_available())"
if ($LASTEXITCODE -ne 0) { Fail "설치된 패키지를 불러오지 못했습니다." }
Ok $chk
# 설치가 끝난 패키지의 다운로드 캐시는 지워서 저장 공간 약 3~4GB 절약
Remove-Item $env:UV_CACHE_DIR -Recurse -Force -ErrorAction SilentlyContinue

# ── 4. ffmpeg ─────────────────────────────────────────────────
Step 4 "오디오 도구 ffmpeg 준비"
$ff = Join-Path $Tools "ffmpeg\bin\ffmpeg.exe"
if (-not (Test-Path $ff)) {
    $zip = Join-Path $Tools "ffmpeg.zip"
    Download "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip" $zip
    $tmp = Join-Path $Tools "ffmpeg_tmp"
    try { Expand-Archive $zip -DestinationPath $tmp -Force -ErrorAction Stop } catch { Fail "ffmpeg 압축 해제 실패: $($_.Exception.Message)" }
    $inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
    if (Test-Path (Join-Path $Tools "ffmpeg")) { Remove-Item (Join-Path $Tools "ffmpeg") -Recurse -Force }
    try { Move-Item $inner.FullName (Join-Path $Tools "ffmpeg") -ErrorAction Stop } catch { Fail "ffmpeg 설치 실패: $($_.Exception.Message)" }
    Remove-Item $tmp -Recurse -Force; Remove-Item $zip
}
if (-not (Test-Path $ff)) { Fail "ffmpeg 를 준비하지 못했습니다." }
Ok ((& $ff -hide_banner -version | Select-Object -First 1))

# ── 5. 작곡 모델 (공식 Hugging Face 저장소에서 직접 받음) ───────────
Step 5 "작곡 모델 YuE2 다운로드 (약 7.4GB · 중간에 끊겨도 다시 실행하면 이어받습니다)"
& $py -X utf8 (Join-Path $App "download_models.py")
if ($LASTEXITCODE -ne 0) { Fail "모델 다운로드에 실패했습니다. 인터넷 연결을 확인하고 download_models.bat 을 실행해 주세요." }

# ── 6. 바탕화면 바로가기 ───────────────────────────────────────
Step 6 "바탕화면 바로가기 만들기"
$desk = [Environment]::GetFolderPath("Desktop")
$lnk = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desk "JK MUSIC Studio.lnk"))
$lnk.TargetPath = "$env:SystemRoot\System32\wscript.exe"
$lnk.Arguments = '"' + (Join-Path $App "start_jk_music.vbs") + '"'
$lnk.WorkingDirectory = $App
$ico = Join-Path $App "static\jk_music.ico"
if (Test-Path $ico) { $lnk.IconLocation = $ico }
$lnk.Save()
Ok "바탕화면에 'JK MUSIC Studio' 아이콘을 만들었습니다"

Write-Host ""
Write-Host "════════════════════════════════════════════" -ForegroundColor Green
Write-Host "   설치 완료! 바탕화면의 'JK MUSIC Studio' 를 실행하세요." -ForegroundColor Green
Write-Host "   처음 실행은 1~2분 정도 걸릴 수 있습니다." -ForegroundColor Green
Write-Host "════════════════════════════════════════════" -ForegroundColor Green
Stop-Transcript | Out-Null
$a = if ($env:JK_INSTALL_AUTO -eq "1") { "n" } else { Read-Host "지금 바로 실행할까요? (y/n)" }
if ($a -eq "y") { Start-Process "$env:SystemRoot\System32\wscript.exe" -ArgumentList ('"' + (Join-Path $App "start_jk_music.vbs") + '"') }
