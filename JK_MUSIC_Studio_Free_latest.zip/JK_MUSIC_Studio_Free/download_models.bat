@echo off
chcp 65001 >nul
title JK MUSIC Studio - Model download
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Please run install.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -X utf8 download_models.py
pause
