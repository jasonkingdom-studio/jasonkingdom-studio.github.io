# -*- coding: utf-8 -*-
"""
JK MUSIC Studio PRO - 옵션 확장 모듈 (music_options.py)
────────────────────────────────────────────────────────────
music_brain 을 불러와 다음을 확장·교체한다.
 1) 장르 추가 (시티팝·보사노바·가스펠·하우스·드럼앤베이스·파워발라드·민요퓨전 등)
 2) 보컬 확장 (트로트 꺾기, 래퍼, 소리꾼, 팝페라, 그로울, 아이돌 그룹 등) + 장르별 추천 보컬
 3) 분위기 확장
 4) 장르별 핵심 악기(한글 라벨) + 장르 추천 추가 악기 + 공통 악기
 5) build_style 교체: 화면에서 켠 악기 칩을 그대로 반영(inst_explicit)
 6) Gemini 과부하(503/429/500) 자동 재시도 + 다른 모델 우회
"""
import re
import time
import hashlib
import urllib.request
import urllib.error
import music_brain as mb

_g = mb._g

# ════════════════════════════════════════════════════════════════
# 1. 장르 추가
# ════════════════════════════════════════════════════════════════
mb.LYRIC_RULES["citypop"] = ("도시의 밤·해안도로 드라이브·세련된 사랑의 이미지. 가볍고 산뜻한 어휘, "
                             "후렴은 부드럽게 반복되는 훅, 영어 구절 한두 개 허용.")
mb.LYRIC_RULES["gospel"] = "희망·감사·구원·위로의 메시지. 콜앤리스폰스(선창-응답) 구절, 후렴은 합창으로 크게 반복."
mb.LYRIC_RULES["country"] = "고향·길·가족·트럭·작은 마을의 이야기. 구체적인 인물과 장소가 나오는 서사형."

_g("시티팝", "Japanese-Korean city pop", 104, (96, 116), "major",
   ["Rhodes electric piano", "slap bass", "clean funk guitar", "brass stabs", "lush synth pads"],
   "smooth four-on-the-floor groove", "glossy 80s studio sheen, bright and airy",
   "smooth breezy pop vocal", "breezy, nostalgic, urban night", "citypop", "pop")
_g("보사노바", "bossa nova", 128, (110, 140), "major",
   ["nylon-string guitar", "upright bass", "soft brushed drums", "flute", "Rhodes piano"],
   "gentle bossa nova syncopation", "intimate warm acoustic room",
   "soft whispery bossa vocal", "relaxed, romantic, seaside", "jazz", "folk")
_g("가스펠 / CCM", "uplifting gospel", 88, (70, 110), "major",
   ["Hammond organ", "grand piano", "gospel choir", "bass", "claps and drums"],
   "swinging gospel groove", "big church hall reverb, warm live mix",
   "powerful soulful lead with choir responses", "uplifting, joyful, spiritual", "gospel", "pop")
_g("컨트리", "modern country", 96, (80, 120), "major",
   ["acoustic guitar", "banjo", "pedal steel guitar", "fiddle", "live drums"],
   "steady country two-step", "warm organic Nashville mix",
   "warm twangy storytelling vocal", "warm, hopeful, homesick", "country", "folk")
_g("얼터너티브 R&B", "alternative R&B", 76, (64, 90), "minor",
   ["atmospheric synth pads", "sub bass", "sparse trap drums", "reverb guitar"],
   "slow half-time groove", "moody spacious mix, dark reverb",
   "breathy falsetto R&B vocal", "moody, intimate, melancholic", "soul", "pop")
_g("딥 하우스", "deep house", 122, (118, 126), "minor",
   ["warm deep bass", "house piano chords", "four-on-the-floor kick", "shuffled hi-hats", "vocal chops"],
   "steady four-on-the-floor house groove", "warm club mix, subtle sidechain",
   "soulful house vocal", "late night, sensual, hypnotic", "edm")
_g("드럼 앤 베이스", "liquid drum and bass", 174, (168, 178), "minor",
   ["fast breakbeat drums", "rolling reese bass", "atmospheric pads", "piano"],
   "fast rolling breakbeats", "wide energetic mix, deep sub",
   "airy soaring vocal", "urgent, euphoric, nocturnal", "edm")
_g("파워 발라드 (록 발라드)", "power rock ballad", 70, (60, 80), "minor",
   ["overdriven electric guitar", "grand piano", "big rock drums", "strings", "guitar solo"],
   "slow build to anthemic chorus", "arena-sized reverb, huge dynamics",
   "powerful soaring rock ballad vocal", "dramatic, heartbreaking, anthemic", "ballad")
_g("민요 퓨전 (경기·남도)", "Korean folk minyo fusion", 96, (80, 120), "minor",
   ["gayageum", "janggu", "piri", "acoustic guitar", "bass"],
   "semachi jangdan 9/8 swing", "bright modern fusion mix with live traditional instruments",
   "Korean minyo vocal with rich sigimsae", "playful, heartfelt, communal", "gugak", "folk")
_g("뉴에이지 / 앰비언트", "new age ambient", 64, (50, 76), "major",
   ["soft felt piano", "ambient synth pads", "gentle strings", "wind chimes"],
   "floating free time", "vast soft reverb, calm airy mix",
   "ethereal airy vocal", "serene, healing, dreamy", "classical", "folk")
_g("걸그룹 팝", "K-pop girl group pop", 118, (108, 130), "major",
   ["bright synths", "punchy dance drums", "plucky bass", "vocal chops", "claps"],
   "bouncy dance-pop groove", "glossy loud K-pop mix",
   "bright youthful group vocals with rap part", "cute, confident, fresh", "kpop", "pop")
_g("정통 트로트 발라드", "slow traditional Korean trot ballad", 76, (66, 88), "minor",
   ["accordion", "electric guitar", "strings", "brass", "soft drums"],
   "slow sentimental trot rhythm", "warm classic Korean adult contemporary mix",
   "deep trot vocal with heavy kkeokki and vibrato", "sorrowful, nostalgic, heartfelt", "trot", "ballad")

GENRE_LABELS = {
    "제이슨 플럭서스 굿": "🔮 제이슨 플럭서스 굿 (Fluxus Gut Ritual)",
    "제이슨 아방가르드 선시": "🧘 제이슨 아방가르드 선시 (Avant-Garde Zen)",
    "제이슨 북극 샤먼 트랜스": "❄️ 제이슨 북극 샤먼 트랜스 (Snow Raven Khomus)",
    "제이슨 천지공사 메탈": "⚡ 제이슨 천지공사 메탈 (Cyber Shaman Metal)",
    "딥 소울 블루스": "🍷 딥 소울 블루스", "정통 델타 블루스": "🎸 정통 델타 블루스 (슬라이드 기타)",
    "시카고 일렉트릭 블루스": "⚡ 시카고 일렉트릭 블루스", "스무스 재즈 카페": "☕ 스무스 재즈 카페",
    "보사노바": "🌴 보사노바 (Bossa Nova)", "네오 소울 / R&B": "🍷 네오 소울 & 감성 R&B",
    "얼터너티브 R&B": "🌙 얼터너티브 R&B (Moody Falsetto)", "가스펠 / CCM": "⛪ 가스펠 / CCM",
    "그루비 펑크 디스코": "🕺 그루비 펑크 디스코", "루츠 레게 & 덥": "🏝️ 루츠 레게 & 덥",
    "트로피컬 레게톤": "🏖️ 트로피컬 레게톤", "애시드 재즈 / 펑크": "🍸 애시드 재즈 & 훵크",
    "시티팝": "🌃 시티팝 (City Pop)",
    "정통 심포니 오케스트라": "🎻 정통 심포니 오케스트라", "네오 클래시컬 피아노": "🎹 네오 클래시컬 피아노 & 첼로",
    "영화 OST 웅장 오케스트라": "🎬 영화 OST 웅장 서사", "뉴에이지 / 앰비언트": "🌿 뉴에이지 / 앰비언트 힐링",
    "오케스트럴 신스웨이브 퓨전": "🌌 신스웨이브 심포니 퓨전", "국악 EDM 크로스오버": "⚡ 국악 EDM 크로스오버",
    "재즈 힙합 퓨전": "☕ 재즈 힙합 퓨전", "펑크 록 퓨전": "🔥 훵크 록 퓨전",
    "국악 / 퓨전국악": "🇰🇷 국악 / 퓨전국악", "민요 퓨전 (경기·남도)": "🪘 민요 퓨전 (경기·남도)",
    "사물놀이 / 타악": "🥁 사물놀이 / 전통 타악", "판소리풍 웅장 발라드": "🏔️ 판소리풍 웅장 서사 발라드",
    "트로트 / 성인가요": "🎤 K-트로트 (신나는 뽕짝)", "정통 트로트 발라드": "🌹 정통 트로트 발라드 (애절한 꺾기)",
    "K-Pop 댄스": "✨ K-Pop 댄스", "걸그룹 팝": "💖 걸그룹 팝 (상큼 & 걸크러시)",
    "감성 팝 발라드": "🎹 감성 팝 발라드", "파워 발라드 (록 발라드)": "🔥 파워 발라드 (록 발라드)",
    "80s 신스웨이브": "🌆 80s 레트로 신스웨이브", "로파이 칠": "🎧 로파이 칠",
    "힙합 / 붐뱁 & 트랩": "🎤 힙합 (붐뱁 & 트랩)", "EDM 페스티벌": "🚀 EDM 페스티벌",
    "딥 하우스": "🌊 딥 하우스", "드럼 앤 베이스": "⚡ 드럼 앤 베이스 (Liquid DnB)",
    "인디 록 / 모던 록": "🎸 인디 록 / 모던 록", "하드 록 / 헤비메탈": "⚡ 하드 록 / 헤비메탈",
    "어쿠스틱 포크": "🏕️ 어쿠스틱 포크", "컨트리": "🤠 컨트리 (Country)",
}

GENRE_GROUPS = [
    ("🔮 제이슨 리추얼", ["제이슨 플럭서스 굿", "제이슨 아방가르드 선시", "제이슨 북극 샤먼 트랜스", "제이슨 천지공사 메탈"]),
    ("🔥 대중음악 & 댄스 & 팝", ["K-Pop 댄스", "걸그룹 팝", "감성 팝 발라드", "파워 발라드 (록 발라드)", "시티팝",
                           "80s 신스웨이브", "로파이 칠", "힙합 / 붐뱁 & 트랩", "EDM 페스티벌", "딥 하우스", "드럼 앤 베이스"]),
    ("🇰🇷 한국 전통 & 성인가요", ["트로트 / 성인가요", "정통 트로트 발라드", "국악 / 퓨전국악", "민요 퓨전 (경기·남도)",
                             "사물놀이 / 타악", "판소리풍 웅장 발라드"]),
    ("🎷 블루스 & 재즈 & 소울", ["딥 소울 블루스", "정통 델타 블루스", "시카고 일렉트릭 블루스", "스무스 재즈 카페", "보사노바",
                           "네오 소울 / R&B", "얼터너티브 R&B", "가스펠 / CCM"]),
    ("🕺 펑크 & 레게 & 그루브", ["그루비 펑크 디스코", "루츠 레게 & 덥", "트로피컬 레게톤", "애시드 재즈 / 펑크"]),
    ("🎸 록 & 메탈 & 포크", ["인디 록 / 모던 록", "하드 록 / 헤비메탈", "어쿠스틱 포크", "컨트리"]),
    ("🎻 클래식 & 시네마틱", ["정통 심포니 오케스트라", "네오 클래시컬 피아노", "영화 OST 웅장 오케스트라", "뉴에이지 / 앰비언트"]),
    ("✨ 현대 퓨전 & 크로스오버", ["오케스트럴 신스웨이브 퓨전", "국악 EDM 크로스오버", "재즈 힙합 퓨전", "펑크 록 퓨전"]),
]

# ════════════════════════════════════════════════════════════════
# 2. 보컬 확장 + 그룹 + 장르별 추천
# ════════════════════════════════════════════════════════════════
mb.VOCALS.update({
    "청아한 소녀 보컬 (걸그룹 톤)": ("female", "bright clear youthful female idol vocal"),
    "트로트 여성 (꺾기·바이브레이션)": ("female", "Korean trot female vocal with kkeokki ornaments and deep vibrato"),
    "재즈 여성 (스모키·스캣)": ("female", "smoky female jazz vocal with scat phrasing"),
    "국악 여성 소리꾼": ("female", "Korean traditional female sorikkun vocal with sigimsae ornaments"),
    "걸크러시 여성 래퍼": ("female", "fierce confident female rapper with sung hook"),
    "클래식 소프라노": ("female", "classical soprano vocal, operatic vibrato"),
    "트로트 남성 (구성진 꺾기)": ("male", "Korean trot male vocal with rich kkeokki bends and vibrato"),
    "랩 & 힙합 남성 (래퍼)": ("male", "male rapper with tight flow and punchlines, melodic hook"),
    "R&B 남성 팔세토": ("male", "silky male R&B vocal with falsetto runs"),
    "허스키 블루스 남성": ("male", "husky gritty male blues vocal"),
    "판소리 남성 소리꾼 (탁성)": ("male", "raspy Korean pansori male vocal, powerful tongseong"),
    "크로스오버 테너 (팝페라)": ("male", "classical crossover tenor, popera style"),
    "메탈 그로울 & 스크림": ("male", "metal growls and screams with clean chorus"),
    "아이돌 그룹 (멤버 파트 분배)": ("group", "K-pop idol group vocals, member parts, rap verse and harmonized chorus"),
    "보컬 + 래퍼 콜라보": ("group", "sung vocal chorus with featured rapper verses"),
    "어린이 합창": ("choir", "bright children's choir"),
})

VOCAL_GROUPS = [
    ("👩 여성 보컬", ["맑고 감미로운 여성 보컬", "파워풀한 여성 고음 보컬", "허스키하고 몽환적인 여성 보컬",
                  "소울풀한 흑인 여성 R&B 보컬", "청아한 소녀 보컬 (걸그룹 톤)", "트로트 여성 (꺾기·바이브레이션)",
                  "재즈 여성 (스모키·스캣)", "국악 여성 소리꾼", "걸크러시 여성 래퍼", "클래식 소프라노"]),
    ("👨 남성 보컬", ["따뜻하고 부드러운 남성 미성", "호소력 짙은 감성 발라드 남성", "거칠고 파워풀한 록 샤우팅 남성",
                  "중저음의 감미로운 바리톤 남성", "트로트 남성 (구성진 꺾기)", "랩 & 힙합 남성 (래퍼)",
                  "R&B 남성 팔세토", "허스키 블루스 남성", "판소리 남성 소리꾼 (탁성)", "크로스오버 테너 (팝페라)",
                  "메탈 그로울 & 스크림"]),
    ("👥 그룹 & 듀엣 & 합창", ["남녀 혼성 듀엣", "아이돌 그룹 (멤버 파트 분배)", "보컬 + 래퍼 콜라보",
                            "웅장한 가스펠 합창단", "어린이 합창"]),
    ("🎹 BGM / 연주곡 (보컬 없음)", ["보컬 없는 순수 연주곡", "감성 피아노 & 스트링 BGM", "영화/영상 OST 웅장 시네마틱 BGM",
                                "카페 & 휴식 로파이 칠 BGM", "명상 & 앰비언트 힐링 BGM"]),
]

REC_VOCALS = {
    "ballad": ["호소력 짙은 감성 발라드 남성", "파워풀한 여성 고음 보컬", "따뜻하고 부드러운 남성 미성", "맑고 감미로운 여성 보컬"],
    "kpop": ["아이돌 그룹 (멤버 파트 분배)", "청아한 소녀 보컬 (걸그룹 톤)", "걸크러시 여성 래퍼", "파워풀한 여성 고음 보컬"],
    "hiphop": ["랩 & 힙합 남성 (래퍼)", "걸크러시 여성 래퍼", "보컬 + 래퍼 콜라보", "R&B 남성 팔세토"],
    "trot": ["트로트 남성 (구성진 꺾기)", "트로트 여성 (꺾기·바이브레이션)", "남녀 혼성 듀엣"],
    "blues": ["허스키 블루스 남성", "소울풀한 흑인 여성 R&B 보컬", "중저음의 감미로운 바리톤 남성"],
    "jazz": ["재즈 여성 (스모키·스캣)", "중저음의 감미로운 바리톤 남성", "허스키하고 몽환적인 여성 보컬"],
    "soul": ["소울풀한 흑인 여성 R&B 보컬", "R&B 남성 팔세토", "허스키하고 몽환적인 여성 보컬"],
    "gospel": ["웅장한 가스펠 합창단", "소울풀한 흑인 여성 R&B 보컬", "R&B 남성 팔세토"],
    "funk": ["소울풀한 흑인 여성 R&B 보컬", "R&B 남성 팔세토", "남녀 혼성 듀엣"],
    "reggae": ["따뜻하고 부드러운 남성 미성", "허스키하고 몽환적인 여성 보컬"],
    "latin": ["허스키하고 몽환적인 여성 보컬", "R&B 남성 팔세토", "보컬 + 래퍼 콜라보"],
    "citypop": ["맑고 감미로운 여성 보컬", "따뜻하고 부드러운 남성 미성", "허스키하고 몽환적인 여성 보컬"],
    "classical": ["클래식 소프라노", "크로스오버 테너 (팝페라)", "감성 피아노 & 스트링 BGM"],
    "cinematic": ["크로스오버 테너 (팝페라)", "파워풀한 여성 고음 보컬", "웅장한 가스펠 합창단", "영화/영상 OST 웅장 시네마틱 BGM"],
    "gugak": ["국악 여성 소리꾼", "판소리 남성 소리꾼 (탁성)", "맑고 감미로운 여성 보컬"],
    "pansori": ["판소리 남성 소리꾼 (탁성)", "국악 여성 소리꾼"],
    "synth": ["허스키하고 몽환적인 여성 보컬", "따뜻하고 부드러운 남성 미성"],
    "lofi": ["허스키하고 몽환적인 여성 보컬", "따뜻하고 부드러운 남성 미성", "카페 & 휴식 로파이 칠 BGM"],
    "edm": ["파워풀한 여성 고음 보컬", "청아한 소녀 보컬 (걸그룹 톤)", "소울풀한 흑인 여성 R&B 보컬"],
    "rock": ["거칠고 파워풀한 록 샤우팅 남성", "호소력 짙은 감성 발라드 남성", "파워풀한 여성 고음 보컬"],
    "metal": ["메탈 그로울 & 스크림", "거칠고 파워풀한 록 샤우팅 남성"],
    "folk": ["따뜻하고 부드러운 남성 미성", "맑고 감미로운 여성 보컬", "남녀 혼성 듀엣"],
    "country": ["따뜻하고 부드러운 남성 미성", "맑고 감미로운 여성 보컬"],
    "ritual": ["판소리 남성 소리꾼 (탁성)", "국악 여성 소리꾼", "메탈 그로울 & 스크림"],
}

# ════════════════════════════════════════════════════════════════
# 3. 분위기 확장
# ════════════════════════════════════════════════════════════════
mb.MOODS.update({
    "몽환적이고 신비로운": ("dreamy, mysterious and ethereal", 0.95, "minor"),
    "희망차고 벅찬": ("hopeful, uplifting and triumphant", 1.04, "major"),
    "쓸쓸하고 고독한": ("lonely, desolate and bittersweet", 0.92, "minor"),
    "섹시하고 도발적인": ("sensual, seductive and confident", 0.98, "minor"),
    "레트로 향수": ("retro, nostalgic vintage feel", 1.0, None),
    "평화롭고 명상적인": ("peaceful, meditative and calm", 0.85, "major"),
    "긴장감 넘치는 스릴": ("tense, suspenseful and dramatic", 1.05, "minor"),
    "귀엽고 발랄한": ("cute, playful and bubbly", 1.08, "major"),
})
MOOD_LABELS = {
    "기본 장르 최적화": "✨ 기본 장르 최적화", "신나고 경쾌한 빠른 템포": "⚡ 신나고 경쾌한 업템포",
    "서정적이고 아련한 감성": "💧 서정적이고 아련한 감성", "웅장하고 비장한 서사": "🏔️ 웅장하고 비장한 시네마틱",
    "어둡고 그루비한 비트": "🌙 어둡고 묵직한 그루브", "따뜻하고 편안한 어쿠스틱 카페": "☕ 따뜻하고 포근한 어쿠스틱",
    "격정적이고 폭발적인 사운드": "🔥 격정적이고 폭발적인 클라이맥스", "몽환적이고 신비로운": "🔮 몽환적이고 신비로운",
    "희망차고 벅찬": "🌅 희망차고 벅찬", "쓸쓸하고 고독한": "🍂 쓸쓸하고 고독한", "섹시하고 도발적인": "💋 섹시하고 도발적인",
    "레트로 향수": "📻 레트로 향수", "평화롭고 명상적인": "🧘 평화롭고 명상적인", "긴장감 넘치는 스릴": "⚠️ 긴장감 넘치는 스릴",
    "귀엽고 발랄한": "🍭 귀엽고 발랄한",
}

# ════════════════════════════════════════════════════════════════
# 4. 악기: 한글 라벨 + 장르별 추천 추가 악기 + 공통 악기
# ════════════════════════════════════════════════════════════════
INST_KO = {
    "daebuk drum": "🥁 대북", "kkwaenggwari": "🔔 꽹과리", "jing gong": "🪘 징", "jing": "🪘 징", "haegeum": "🎻 해금",
    "prepared piano noise": "🎹 프리페어드 피아노", "temple bell": "🔔 범종", "daegeum": "🎋 대금", "low drone": "🌫️ 저음 드론",
    "sparse piano": "🎹 여백 피아노", "khomus jaw harp": "🎶 코무스(턱하프)", "shamanic frame drum": "🥁 샤먼 북",
    "rolling psytrance bass": "🔊 사이트랜스 베이스", "arctic wind pads": "❄️ 북극 바람 패드",
    "high-gain distorted guitars": "🎸 하이게인 디스토션 기타", "double-bass drums": "🥁 투베이스 드럼",
    "taepyeongso": "📯 태평소", "industrial synths": "🏭 인더스트리얼 신스",
    "crying electric blues guitar": "🎸 울부짖는 블루스 기타", "Hammond B3 organ": "🎹 해먼드 B3 오르간",
    "upright piano": "🎹 업라이트 피아노", "bass": "🎸 베이스", "brushed drums": "🥁 브러시 드럼",
    "resonator slide guitar": "🎸 리조네이터 슬라이드 기타", "harmonica": "🎵 하모니카", "foot stomp": "👢 발 구르기",
    "overdriven electric guitar": "🎸 오버드라이브 일렉기타", "walking bass": "🎸 워킹 베이스", "piano": "🎹 피아노",
    "shuffle drums": "🥁 셔플 드럼", "tenor saxophone": "🎷 테너 색소폰", "Rhodes electric piano": "🎹 로즈 전자피아노",
    "upright bass": "🎻 콘트라베이스", "jazz guitar": "🎸 재즈 기타", "warm fingered bass": "🎸 핑거 베이스",
    "laid-back drums": "🥁 레이드백 드럼", "soft guitar licks": "🎸 부드러운 기타 릭", "slap bass": "🕺 슬랩 베이스",
    "brass horn section": "🎺 브라스 섹션", "wah rhythm guitar": "🎸 와우 리듬기타", "clavinet": "🎹 클라비넷",
    "four-on-the-floor drums": "🥁 포온더플로어 드럼", "offbeat skank guitar": "🏝️ 오프비트 스캥크 기타",
    "deep dub bass": "🔊 딥 덥 베이스", "Hammond organ bubble": "🎹 오르간 버블", "one-drop drums": "🥁 원드롭 드럼",
    "dembow drums": "🥁 뎀보 리듬", "marimba": "🪵 마림바", "latin guitar": "🎸 라틴 기타", "deep 808 bass": "💥 808 베이스",
    "warm synth pads": "🎛️ 따뜻한 신스 패드", "muted trumpet": "🎺 뮤트 트럼펫", "breakbeat drums": "🥁 브레이크비트",
    "wah guitar": "🎸 와우 기타", "full string section": "🎻 풀 현악 섹션", "French horns": "📯 프렌치 호른",
    "woodwinds": "🪈 목관악기", "timpani": "🥁 팀파니", "harp": "🪕 하프", "felt grand piano": "🎹 펠트 그랜드 피아노",
    "solo cello": "🎻 솔로 첼로", "chamber strings": "🎻 실내악 현악", "massive brass": "🎺 거대한 금관",
    "soaring violins": "🎻 솟구치는 바이올린", "taiko drums": "🥁 타이코 북", "choir": "👥 합창",
    "low strings ostinato": "🎻 저음 현악 오스티나토", "analog synth arpeggios": "🎛️ 아날로그 신스 아르페지오",
    "orchestral brass": "🎺 오케스트라 금관", "violins": "🎻 바이올린", "driving synth bass": "🔊 드라이빙 신스베이스",
    "gated drums": "🥁 게이트 드럼", "taepyeongso lead": "📯 태평소 리드", "janggu": "🪘 장구",
    "festival supersaw synths": "🚀 페스티벌 슈퍼소우", "heavy kick": "💥 헤비 킥", "dusty jazz piano": "🎹 빈티지 재즈 피아노",
    "boom bap drums": "🥁 붐뱁 드럼", "distorted rhythm guitar": "🎸 디스토션 리듬기타", "tight rock drums": "🥁 타이트 록 드럼",
    "gayageum": "🪕 가야금", "soft strings": "🎻 부드러운 현악", "buk drum": "🥁 북", "brass section": "🎺 브라스",
    "electric organ": "🎹 전자 오르간", "bouncy synth bass": "🔊 통통 신스베이스", "accordion": "🪗 아코디언",
    "disco drums": "🥁 디스코 드럼", "grand strings": "🎻 웅장한 현악", "bright synth leads": "🎛️ 브라이트 신스 리드",
    "punchy EDM drums": "🥁 펀치 EDM 드럼", "deep synth bass": "🔊 딥 신스베이스", "vocal chops": "🗣️ 보컬 찹",
    "grand piano": "🎹 그랜드 피아노", "lush string section": "🎻 풍성한 현악", "soft drums": "🥁 소프트 드럼",
    "warm bass": "🎸 따뜻한 베이스", "analog synth leads": "🎛️ 아날로그 신스 리드", "arpeggiated bass": "🔊 아르페지오 베이스",
    "gated reverb drums": "🥁 게이트 리버브 드럼", "lush pads": "🎛️ 풍성한 패드", "dusty Rhodes chords": "🎹 빈티지 로즈 코드",
    "mellow bass": "🎸 멜로우 베이스", "soft boom bap drums": "🥁 소프트 붐뱁", "vinyl crackle": "📀 LP 잡음",
    "heavy 808 bass": "💥 헤비 808 베이스", "trap hi-hats": "🥁 트랩 하이햇", "dark piano": "🎹 다크 피아노",
    "bell melody": "🔔 벨 멜로디", "supersaw leads": "🚀 슈퍼소우 리드", "big room kick": "💥 빅룸 킥", "plucks": "🎛️ 플럭",
    "risers": "📈 라이저", "sub bass": "🔊 서브 베이스", "overdriven electric guitars": "🎸 오버드라이브 기타",
    "live drums": "🥁 라이브 드럼", "driving bass": "🎸 드라이빙 베이스", "heavy distorted guitar riffs": "🎸 헤비 리프",
    "guitar solo": "🎸 기타 솔로", "fingerpicked acoustic guitar": "🎸 핑거피킹 통기타", "violin": "🎻 바이올린",
    "light percussion": "🪇 가벼운 퍼커션", "clean funk guitar": "🎸 클린 펑크 기타", "brass stabs": "🎺 브라스 스탭",
    "lush synth pads": "🎛️ 풍성한 신스 패드", "nylon-string guitar": "🎸 나일론 기타", "soft brushed drums": "🥁 부드러운 브러시",
    "flute": "🪈 플루트", "Rhodes piano": "🎹 로즈 피아노", "Hammond organ": "🎹 해먼드 오르간", "gospel choir": "⛪ 가스펠 합창",
    "claps and drums": "👏 박수 & 드럼", "acoustic guitar": "🎸 통기타", "banjo": "🪕 밴조", "pedal steel guitar": "🎸 페달 스틸",
    "fiddle": "🎻 피들", "atmospheric synth pads": "🌫️ 공간감 신스 패드", "sparse trap drums": "🥁 미니멀 트랩 드럼",
    "reverb guitar": "🎸 리버브 기타", "warm deep bass": "🔊 딥 하우스 베이스", "house piano chords": "🎹 하우스 피아노",
    "four-on-the-floor kick": "💥 포온더플로어 킥", "shuffled hi-hats": "🥁 셔플 하이햇", "fast breakbeat drums": "🥁 고속 브레이크비트",
    "rolling reese bass": "🔊 리스 베이스", "atmospheric pads": "🌫️ 공간감 패드", "big rock drums": "🥁 빅 록 드럼",
    "strings": "🎻 현악", "piri": "🎋 피리", "soft felt piano": "🎹 소프트 펠트 피아노", "ambient synth pads": "🌫️ 앰비언트 패드",
    "gentle strings": "🎻 잔잔한 현악", "wind chimes": "🎐 윈드차임", "bright synths": "🎛️ 밝은 신스",
    "punchy dance drums": "🥁 펀치 댄스 드럼", "plucky bass": "🔊 플럭 베이스", "claps": "👏 클랩", "electric guitar": "🎸 일렉기타",
    "brass": "🎺 금관", "throat singing": "🗣️ 호미 배음창", "dub bass": "🔊 덥 베이스", "lead electric guitar": "🎸 리드 일렉기타",
    "lush strings": "🎻 풍성한 현악", "punchy drums": "🥁 펀치 드럼", "warm brass section": "🎺 따뜻한 브라스",
    "analog synth lead": "🎛️ 아날로그 리드", "synth arpeggios": "🎛️ 신스 아르페지오", "trumpets": "🎺 트럼펫",
    "soprano saxophone": "🎷 소프라노 색소폰", "trombone": "🎺 트롬본", "vibraphone": "🎵 비브라폰", "tabla": "🪘 타블라",
    "sitar": "🪕 시타르", "shakuhachi": "🎋 샤쿠하치", "erhu": "🎻 얼후", "bagpipes": "🎵 백파이프", "celesta": "🔔 첼레스타",
    "music box": "🎁 오르골", "glockenspiel": "🔔 글로켄슈필", "congas": "🪘 콩가", "bongos": "🪘 봉고", "shaker": "🪇 셰이커",
    "tambourine": "🪇 탬버린", "cowbell": "🔔 카우벨", "organ": "🎹 오르간", "mandolin": "🪕 만돌린", "ukulele": "🪕 우쿨렐레",
    "12-string guitar": "🎸 12현 기타", "fretless bass": "🎸 프렛리스 베이스", "talkbox": "🗣️ 토크박스",
    "vocoder": "🤖 보코더", "string quartet": "🎻 현악 4중주", "cello section": "🎻 첼로 섹션", "oboe": "🪈 오보에",
    "clarinet": "🪈 클라리넷", "piccolo": "🪈 피콜로", "tuba": "📯 튜바", "geomungo": "🪕 거문고", "ajaeng": "🎻 아쟁",
    "saenghwang": "🎵 생황", "sogeum": "🎋 소금", "danso": "🎋 단소", "kkwaenggwari small gong": "🔔 꽹과리",
    "pungmul percussion": "🥁 풍물 타악", "hand drum": "🪘 핸드드럼", "rain stick": "🌧️ 레인스틱", "singing bowl": "🥣 싱잉볼",
    "didgeridoo": "🎵 디저리두", "tongue drum": "🥁 텅드럼", "handpan": "🥁 핸드팬", "kalimba": "🎵 칼림바",
    "synth bass": "🔊 신스 베이스", "chiptune synth": "👾 칩튠 신스", "turntable scratches": "💿 턴테이블 스크래치",
    "sampled soul vocals": "🗣️ 소울 보컬 샘플", "orchestral hits": "💥 오케스트라 히트", "piano ballad chords": "🎹 발라드 피아노 코드",
    "cajon": "🪘 카혼", "steel drums": "🥁 스틸 드럼", "horn section": "🎺 호른 섹션", "saxophone": "🎷 색소폰",
}

GENRE_EXTRAS = {
    "제이슨 플럭서스 굿": ["taepyeongso", "ajaeng", "singing bowl", "turntable scratches"],
    "제이슨 아방가르드 선시": ["singing bowl", "geomungo", "ajaeng", "rain stick"],
    "제이슨 북극 샤먼 트랜스": ["throat singing", "didgeridoo", "tongue drum", "singing bowl"],
    "제이슨 천지공사 메탈": ["kkwaenggwari", "orchestral hits", "choir", "vocoder"],
    "딥 소울 블루스": ["saxophone", "horn section", "harmonica", "organ"],
    "정통 델타 블루스": ["acoustic guitar", "mandolin", "tambourine", "upright bass"],
    "시카고 일렉트릭 블루스": ["Hammond organ", "saxophone", "horn section"],
    "스무스 재즈 카페": ["soprano saxophone", "vibraphone", "muted trumpet", "flute"],
    "보사노바": ["vibraphone", "shaker", "clarinet", "string quartet"],
    "네오 소울 / R&B": ["saxophone", "string quartet", "fretless bass", "talkbox"],
    "얼터너티브 R&B": ["vocoder", "piano", "deep 808 bass", "string quartet"],
    "가스펠 / CCM": ["tambourine", "brass section", "string quartet", "electric guitar"],
    "그루비 펑크 디스코": ["talkbox", "congas", "string quartet", "cowbell"],
    "루츠 레게 & 덥": ["horn section", "harmonica", "bongos", "piano"],
    "트로피컬 레게톤": ["steel drums", "congas", "trumpets", "vocal chops"],
    "애시드 재즈 / 펑크": ["vibraphone", "flute", "congas", "saxophone"],
    "시티팝": ["saxophone", "string quartet", "vibraphone", "vocoder"],
    "정통 심포니 오케스트라": ["oboe", "clarinet", "celesta", "tuba", "piccolo"],
    "네오 클래시컬 피아노": ["string quartet", "celesta", "music box", "harp"],
    "영화 OST 웅장 오케스트라": ["orchestral hits", "cello section", "timpani", "harp", "ajaeng"],
    "뉴에이지 / 앰비언트": ["handpan", "kalimba", "singing bowl", "flute", "harp"],
    "오케스트럴 신스웨이브 퓨전": ["choir", "electric guitar", "timpani", "vocoder"],
    "국악 EDM 크로스오버": ["gayageum", "daegeum", "kkwaenggwari", "vocal chops"],
    "재즈 힙합 퓨전": ["saxophone", "vinyl crackle", "turntable scratches", "vibraphone"],
    "펑크 록 퓨전": ["horn section", "talkbox", "congas", "organ"],
    "국악 / 퓨전국악": ["geomungo", "ajaeng", "piri", "saenghwang", "danso"],
    "민요 퓨전 (경기·남도)": ["haegeum", "daegeum", "kkwaenggwari", "accordion"],
    "사물놀이 / 타악": ["taepyeongso", "pungmul percussion", "daebuk drum"],
    "판소리풍 웅장 발라드": ["ajaeng", "daegeum", "choir", "timpani"],
    "트로트 / 성인가요": ["saxophone", "electric guitar", "tambourine", "strings"],
    "정통 트로트 발라드": ["saxophone", "haegeum", "piano", "harmonica"],
    "K-Pop 댄스": ["electric guitar", "orchestral hits", "claps", "heavy 808 bass"],
    "걸그룹 팝": ["music box", "glockenspiel", "electric guitar", "brass stabs"],
    "감성 팝 발라드": ["acoustic guitar", "cello section", "celesta", "choir"],
    "파워 발라드 (록 발라드)": ["organ", "choir", "timpani", "acoustic guitar"],
    "80s 신스웨이브": ["saxophone", "electric guitar", "vocoder", "chiptune synth"],
    "로파이 칠": ["kalimba", "saxophone", "acoustic guitar", "rain stick"],
    "힙합 / 붐뱁 & 트랩": ["sampled soul vocals", "turntable scratches", "string quartet", "choir"],
    "EDM 페스티벌": ["vocal chops", "piano", "orchestral hits", "electric guitar"],
    "딥 하우스": ["saxophone", "congas", "organ", "shaker"],
    "드럼 앤 베이스": ["string quartet", "vocal chops", "saxophone", "piano"],
    "인디 록 / 모던 록": ["synth bass", "acoustic guitar", "tambourine", "organ"],
    "하드 록 / 헤비메탈": ["organ", "choir", "orchestral hits", "timpani"],
    "어쿠스틱 포크": ["mandolin", "harmonica", "banjo", "cello section", "ukulele"],
    "컨트리": ["harmonica", "mandolin", "organ", "12-string guitar"],
}

COMMON_INSTRUMENTS = ["piano", "acoustic guitar", "electric guitar", "strings", "violin", "solo cello", "saxophone",
                      "trumpets", "flute", "organ", "synth bass", "lush pads", "heavy 808 bass", "live drums",
                      "gayageum", "haegeum", "daegeum", "janggu", "choir", "music box"]

def genre_slug(genre: str) -> str:
    """한글 장르 키 → 안전한 파일명 (영문 장르명 + 해시 6자리, 항상 같은 값)"""
    p = mb.get_profile(genre)
    base = re.sub(r"[^a-z0-9]+", "-", p["en"].lower()).strip("-")[:40] or "genre"
    return f"{base}-{hashlib.md5(genre.encode('utf-8')).hexdigest()[:6]}"

def _inst_item(en):
    return {"en": en, "label": INST_KO.get(en, "🎵 " + en)}

# 기존 드롭다운 프리셋은 유지 (music_brain.INSTRUMENT_FOCUS)

# ════════════════════════════════════════════════════════════════
# 5. build_style 교체 — 화면에서 켠 악기 칩을 그대로 반영
# ════════════════════════════════════════════════════════════════
def build_style(genre, vocal, mood="기본 장르 최적화", inst_focus="기본 편성", chips=None,
                dynamics="스튜디오 마스터링 & 와이드 다이내믹스", lang="auto",
                bpm=None, key_mode="auto", title="", topic="", inst_explicit=False):
    p = mb.get_profile(genre)
    lang = mb.resolve_lang(lang, title, topic)
    v_kind, v_desc = mb.VOCALS.get(vocal, ("custom", vocal or ""))
    instrumental = v_kind == "inst"
    m_desc, m_mult, m_key = mb.MOODS.get(mood, (mood if mood and mood != "기본 장르 최적화" else None, 1.0, None))

    if bpm:
        final_bpm = max(40, min(220, int(bpm)))
    else:
        lo, hi = p["rng"]
        final_bpm = max(lo, min(hi, int(round(p["bpm"] * m_mult))))
    mode = key_mode if key_mode in ("major", "minor") else (m_key or p["key"])
    key = mb._pick_key(genre, mode, title)

    preset = mb.INSTRUMENT_FOCUS.get(inst_focus, [])
    chips = [c for c in (chips or []) if c and c.strip()]
    if inst_explicit and chips:
        instruments = mb._dedupe(preset + chips)[:8]          # 화면에서 켠 악기 그대로
    else:
        instruments = mb._dedupe(preset + chips + p["inst"])[:6]

    parts = []
    if not instrumental:
        parts += ["Korean" if lang == "ko" else "English", v_desc, p["vox"]]
    else:
        parts.append("instrumental, no vocals")
        extra = v_desc.replace("instrumental, no vocals", "").strip(" ,")
        if extra:
            parts.append(extra)
    parts += [p["en"], ", ".join(instruments), p["groove"], m_desc or p["mood"], p["tex"]]
    d = mb.DYNAMICS.get(dynamics, "")
    if d and instrumental:
        d = d.replace(", clear vocal mix", "")
    if d:
        parts.append(d)
    parts += [f"{final_bpm} BPM", key]

    pieces = mb._dedupe([pc for x in parts if x for pc in x.split(", ")])
    pieces = [pc for pc in pieces
              if len(pc.split()) < 2
              or not any(pc.lower() != o.lower() and pc.lower() in o.lower() for o in pieces)]
    style = ", ".join(pieces)
    lang_label = "연주곡" if instrumental else ("한국어" if lang == "ko" else "English")
    summary = f"{final_bpm} BPM · {key} · {lang_label} · 악기 {len(instruments)}종"
    return dict(style=style, bpm=final_bpm, key=key, lang=lang, instrumental=instrumental,
                summary=summary, instruments=instruments)

mb.build_style = build_style

# ════════════════════════════════════════════════════════════════
# 6. Gemini 과부하 자동 재시도 + 모델 우회
# ════════════════════════════════════════════════════════════════
def _gemini_models():
    return mb._dedupe([m for m in [mb._env("GEMINI_MODEL"), "gemini-2.5-flash", "gemini-2.5-flash-lite",
                                   "gemini-2.0-flash", "gemini-flash-latest"] if m])

def _call_gemini(prompt, key):
    last = None
    for model in _gemini_models():
        for attempt in range(3):                       # 모델마다 최대 3회 (2초 → 5초 대기)
            try:
                cfg = {"temperature": 0.85, "maxOutputTokens": 4096}
                if model.startswith("gemini-2.5"):
                    cfg["thinkingConfig"] = {"thinkingBudget": 0}
                res = mb._post_json(
                    f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}",
                    {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": cfg}, {})
                cand = res["candidates"][0]
                text = "".join(p.get("text", "") for p in cand.get("content", {}).get("parts", []))
                if text.strip():
                    return text
                last = RuntimeError(f"{model}: 빈 응답")
                break
            except urllib.error.HTTPError as e:
                last = RuntimeError(f"{model}: HTTP {e.code}")
                if e.code in (429, 500, 503) and attempt < 2:
                    time.sleep(2 if attempt == 0 else 5)
                    continue
                break                                   # 다른 오류(404 등)는 다음 모델로
            except Exception as e:
                last = e
                break
    raise RuntimeError(f"Gemini 전체 모델이 일시적으로 응답하지 않습니다 (마지막 오류: {last}). 잠시 후 다시 시도해 주세요.")

mb._call_gemini = _call_gemini

# ════════════════════════════════════════════════════════════════
# 7. 화면용 옵션 전체
# ════════════════════════════════════════════════════════════════
def options():
    genres = {}
    for name, p in mb.G.items():
        genres[name] = {
            "bpm": p["bpm"], "range": list(p["rng"]), "key": p["key"], "cat": p["cat"],
            "core": [_inst_item(i) for i in p["inst"]],
            "extras": [_inst_item(i) for i in GENRE_EXTRAS.get(name, []) if i not in p["inst"]],
            "rec_vocals": REC_VOCALS.get(p["cat"], []),
            "slug": genre_slug(name),
        }
    grouped = []
    listed = set()
    for label, names in GENRE_GROUPS:
        items = [{"value": n, "label": GENRE_LABELS.get(n, n)} for n in names if n in mb.G]
        listed.update(n for n in names)
        grouped.append({"label": label, "items": items})
    rest = [n for n in mb.G if n not in listed]
    if rest:
        grouped.append({"label": "기타", "items": [{"value": n, "label": n} for n in rest]})
    return {
        "genre_groups": grouped,
        "vocal_groups": [{"label": l, "items": [{"value": v, "label": v} for v in vs]} for l, vs in VOCAL_GROUPS],
        "moods": [{"value": m, "label": MOOD_LABELS.get(m, m)} for m in mb.MOODS],
        "inst_presets": [{"value": k, "label": k} for k in mb.INSTRUMENT_FOCUS],
        "common_instruments": [_inst_item(i) for i in COMMON_INSTRUMENTS],
        "genres": genres,
    }
