# -*- coding: utf-8 -*-
"""
JK MUSIC Studio PRO — 장르 미리듣기 샘플 일괄 생성 (generate_previews.py)
────────────────────────────────────────────────────────────
· music_brain.G 의 모든 장르에 대해 기본 스타일(연주곡)로 짧은 곡을 YuE2로 생성하고
  가장 풍성한 구간 15초를 잘라 static/previews/{slug}.mp3 로 저장한다.
· 이미 파일이 있으면 건너뛰므로 여러 번 실행해도 안전하다(중단 후 이어서 생성 가능).
· 앱 서버가 작곡 중이면 GPU가 겹치지 않도록 끝날 때까지 기다린다.

사용법
  python generate_previews.py                 # 전체 장르 (최초 1회)
  python generate_previews.py --limit 3       # 앞에서 3개만
  python generate_previews.py --genres "시티팝,보사노바"
  python generate_previews.py --force         # 이미 있어도 다시 생성
"""
import os
import sys
import time
import json
import shutil
import argparse
import subprocess
import urllib.request
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))
import music_brain as mb
import music_options as mo          # 확장 장르·build_style 적용

PREVIEW_DIR = BASE_DIR / "static" / "previews"
MODEL_DIR = BASE_DIR / "models" / "YuE2-3B"
VAE_DIR = BASE_DIR / "models" / "YuE2-Vae"
SERVER = "http://127.0.0.1:7860"
FFMPEG = shutil.which("ffmpeg")

# 미리듣기용 짧은 연주곡 골격 (섹션이 적을수록 짧게 생성됨)
PREVIEW_LYRICS = "[Intro]\n\n[Chorus]\n\n[Outro]"
PREVIEW_VOCAL = "보컬 없는 순수 연주곡"


def server_busy() -> bool:
    """앱 서버에서 작곡이 진행 중인지 확인 (서버가 꺼져 있으면 한가한 것으로 봄)"""
    try:
        with urllib.request.urlopen(f"{SERVER}/api/jobs/active", timeout=5) as r:
            return bool(json.loads(r.read().decode("utf-8")).get("jobs"))
    except Exception:
        return False


def wait_server_idle():
    shown = False
    while server_busy():
        if not shown:
            print("  ⏳ 앱에서 작곡이 진행 중입니다. 끝날 때까지 기다립니다…", flush=True)
            shown = True
        time.sleep(20)


def cut_preview(flac: Path, mp3: Path, duration: float, seconds: int):
    """곡의 1/3 지점(도입부 이후 풍성한 구간)부터 N초 자르고 페이드 처리"""
    start = max(0.0, min(duration * 0.33, duration - seconds))
    fade_out = max(0.0, seconds - 1.5)
    cmd = [FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.2f}", "-t", str(seconds),
           "-i", str(flac), "-af", f"afade=t=in:st=0:d=0.6,afade=t=out:st={fade_out}:d=1.5,loudnorm=I=-16:TP=-1.5",
           "-ar", "44100", "-b:a", "192k", str(mp3)]
    subprocess.run(cmd, check=True)


def main():
    ap = argparse.ArgumentParser(description="장르 미리듣기 샘플 생성")
    ap.add_argument("--genres", default="", help="쉼표로 구분한 장르 이름 (기본: 전체)")
    ap.add_argument("--limit", type=int, default=0, help="앞에서부터 N개만 생성")
    ap.add_argument("--seconds", type=int, default=15, help="미리듣기 길이(초)")
    ap.add_argument("--force", action="store_true", help="이미 있어도 다시 생성")
    args = ap.parse_args()

    if not FFMPEG:
        sys.exit("❌ ffmpeg 를 찾을 수 없습니다.")
    PREVIEW_DIR.mkdir(parents=True, exist_ok=True)

    genres = [g.strip() for g in args.genres.split(",") if g.strip()] or list(mb.G.keys())
    unknown = [g for g in genres if g not in mb.G]
    if unknown:
        sys.exit(f"❌ 알 수 없는 장르: {unknown}")
    todo = [g for g in genres if args.force or not (PREVIEW_DIR / f"{mo.genre_slug(g)}.mp3").exists()]
    if args.limit:
        todo = todo[:args.limit]
    print(f"🎧 미리듣기 생성 대상 {len(todo)}개 (전체 {len(genres)}개 중, 이미 있는 것은 건너뜀)", flush=True)
    if not todo:
        return

    from yue2 import YuE2Pipeline
    wait_server_idle()
    t_load = time.time()
    pipe = YuE2Pipeline.from_pretrained(str(MODEL_DIR), vae=str(VAE_DIR), local_files_only=True,
                                        device="cuda", backend="torch-eager", memory_budget_gib=15,
                                        progress=False)
    print(f"✅ YuE2 로드 완료 ({time.time() - t_load:.0f}초)", flush=True)

    ok, fail, t_all = 0, [], time.time()
    tmp_dir = PREVIEW_DIR / "_tmp"
    tmp_dir.mkdir(exist_ok=True)
    for i, genre in enumerate(todo, 1):
        slug = mo.genre_slug(genre)
        out = PREVIEW_DIR / f"{slug}.mp3"
        info = mb.build_style(genre, PREVIEW_VOCAL, title=genre)
        print(f"[{i}/{len(todo)}] {genre} → {out.name}\n   🎛 {info['style'][:110]}…", flush=True)
        wait_server_idle()
        t0 = time.time()
        try:
            song = pipe(id=f"preview_{slug}", style=info["style"], lyrics=PREVIEW_LYRICS, cot="full", seed=2026)
            flac = tmp_dir / f"{slug}.flac"
            song.save(flac)
            dur = len(song.audio) / song.sample_rate
            cut_preview(flac, out, dur, args.seconds)
            flac.unlink(missing_ok=True)
            ok += 1
            print(f"   ✅ 완료 (원곡 {dur:.0f}초 → {args.seconds}초 미리듣기, {time.time() - t0:.0f}초 소요)", flush=True)
        except Exception as e:
            fail.append(genre)
            print(f"   ❌ 실패: {e}", flush=True)
    shutil.rmtree(tmp_dir, ignore_errors=True)
    try:
        pipe.close()
    except Exception:
        pass
    mins = (time.time() - t_all) / 60
    print(f"\n🎉 끝: 성공 {ok}개 · 실패 {len(fail)}개 · 총 {mins:.1f}분" + (f"\n   실패 장르: {fail}" if fail else ""), flush=True)


if __name__ == "__main__":
    main()
