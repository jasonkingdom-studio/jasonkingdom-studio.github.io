# -*- coding: utf-8 -*-
"""
JK MUSIC Studio PRO — 스템 기반 자동 보컬 밸런싱 v2 (vocal_balance.py)
────────────────────────────────────────────────────────────
문제: 완성곡에서 가사가 "들렸다 안 들렸다" 함.
측정: 보컬 자체의 크기보다 '반주 대비 보컬 크기'가 곡 안에서 15dB 가까이 출렁임
      (반주가 커지는 후렴·간주 근처에서 보컬이 묻힘). speechnorm 은 보컬 단독 크기만 맞추고,
      사이드체인 덕킹은 반주까지 출렁이게 해 오히려 불안정했다.
해결: 전문 스튜디오의 '보컬 라이더' 방식
      → 0.05초마다 보컬과 반주의 크기를 비교해, 보컬이 항상 반주보다 일정한 만큼 위에 있도록
        보컬 볼륨만 부드럽게 올리고 내린다(±10dB 이내). 반주는 건드리지 않는다.

처리 순서
  audio.flac → Demucs 2스템(vocals / no_vocals)
            → ① 보컬 라이더(반주 대비 일정 레벨 유지)
            → ② 게이트(무음·번짐 증폭 방지) + 가벼운 압축(음절 피크 정리)
            → ③ 보컬 + 반주 합산 + 피크 보호 리미터 → remixed.flac

★ 어떤 단계에서 실패해도 예외를 밖으로 던지지 않고 원본 flac 을 그대로 돌려준다.
환경변수 JK_DEMUCS_MODULE : Demucs 모듈 이름(기본 demucs) — 폴백 테스트 시 틀린 이름을 넣어 흉내낸다.
"""
import os
import sys
import time
import shutil
import subprocess
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import lfilter

FFMPEG = shutil.which("ffmpeg")

# ── 보컬 라이더 설정 ──────────────────────────────────────────────
RIDER_HOP_SEC = 0.05          # 분석 간격
RIDER_WIN_SEC = 0.40          # 크기 측정 창(사람 귀의 순간 음량 감각과 비슷한 400ms)
RIDER_MAX_GAIN_DB = 10.0      # 최대 올림/내림 폭
RIDER_PRESENCE_DB = 1.5       # 곡 평균보다 보컬을 살짝 더 앞으로
RIDER_SMOOTH_SEC = 0.25       # 게인 변화 부드럽게(너무 빠르면 울렁임)
RIDER_ACTIVE_RANGE_DB = 30.0  # 보컬 최대치 대비 이 범위 안이면 '노래하는 중'으로 판단
RIDER_PASSES = 2              # 2회 반복 적용(1회로는 수렴이 덜 됨: 실측 17.5→10.5dB, 2회 7.8dB)
RIDER_RELEASE_DB_PER_SEC = 4.0  # 노래가 멈추면 게인을 초당 4dB 씩 0dB 로 되돌림(마지막 소절 뒤 잡음 증폭 방지)

# ── 라이더 뒤 보컬 후처리: 매우 가벼운 피크 정리만 ──
#  (이전의 게이트는 조용히 부르는 소절 끝을 잘라 오히려 편차를 키워서 제거 — 실측 10.1→12.7dB 악화)
VOCAL_POST = "acompressor=threshold=0.25:ratio=2:attack=5:release=120:makeup=1:knee=4"

# ── 재합성: 합산 후 피크 보호 (덕킹 없음 — 반주는 원래 그대로) ──
REMIX_GRAPH = ("[0:a][1:a]amix=inputs=2:normalize=0:duration=longest[mix];"
               "[mix]alimiter=limit=0.97:attack=5:release=50:level=0[out]")


def _run(cmd, timeout):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout or "").strip()[-300:])
    return r


def _biquad(kind, fc, sr, G=0.0, Q=0.7071):
    """RBJ 바이쿼드 계수 (high-shelf / high-pass)"""
    A = 10 ** (G / 40); w0 = 2 * np.pi * fc / sr; al = np.sin(w0) / (2 * Q); cw = np.cos(w0)
    if kind == "shelf":
        b = [A * ((A + 1) + (A - 1) * cw + 2 * np.sqrt(A) * al), -2 * A * ((A - 1) + (A + 1) * cw),
             A * ((A + 1) + (A - 1) * cw - 2 * np.sqrt(A) * al)]
        a = [(A + 1) - (A - 1) * cw + 2 * np.sqrt(A) * al, 2 * ((A - 1) - (A + 1) * cw),
             (A + 1) - (A - 1) * cw - 2 * np.sqrt(A) * al]
    else:
        b = [(1 + cw) / 2, -(1 + cw), (1 + cw) / 2]
        a = [1 + al, -2 * cw, 1 - al]
    return np.array(b) / a[0], np.array(a) / a[0]


def _k_weight(x, sr):
    """사람 귀 감도에 맞춘 K-가중(방송 음량 측정 표준 ITU BS.1770) — 저음 에너지에 속지 않도록"""
    b, a = _biquad("shelf", 1681.97, sr, G=3.99984, Q=0.7071752)
    x = lfilter(b, a, x)
    b, a = _biquad("hp", 38.13, sr, Q=0.5003270)
    return lfilter(b, a, x)


def _frame_db(x, sr):
    """모노 신호의 이동 RMS(dBFS) — hop 간격으로 계산"""
    hop, win = int(sr * RIDER_HOP_SEC), int(sr * RIDER_WIN_SEC)
    c = np.concatenate([[0.0], np.cumsum(x.astype(np.float64) ** 2)])
    centers = np.arange(0, len(x), hop)
    lo = np.clip(centers - win // 2, 0, len(x))
    hi = np.clip(centers + win // 2, 0, len(x))
    ms = (c[hi] - c[lo]) / np.maximum(hi - lo, 1)
    return centers, 10 * np.log10(ms + 1e-12)


def _smooth(g, n):
    """이동 평균(양방향) — 게인 곡선을 부드럽게"""
    if n <= 1:
        return g
    k = np.ones(n) / n
    pad = np.pad(g, (n, n), mode="edge")
    return np.convolve(pad, k, mode="same")[n:-n]


def vocal_rider(vocals_path: Path, backing_path: Path, out_path: Path):
    """반주 대비 보컬 크기를 일정하게 유지하도록 보컬 볼륨을 자동으로 조절해 저장.
    반환: (적용 전 반주대비 편차 dB, 적용 후 편차 dB) — 10~90% 구간 폭"""
    v, sr = sf.read(str(vocals_path), dtype="float32", always_2d=True)
    b, sr_b = sf.read(str(backing_path), dtype="float32", always_2d=True)
    if sr != sr_b:
        raise RuntimeError("보컬/반주 샘플레이트가 다릅니다")
    n = min(len(v), len(b))
    v, b = v[:n], b[:n]
    centers, bdb = _frame_db(_k_weight(b.mean(axis=1), sr), sr)
    spread = lambda a, m: float(np.percentile(a[m], 90) - np.percentile(a[m], 10))
    decay = RIDER_RELEASE_DB_PER_SEC * RIDER_HOP_SEC

    rode, first = v, None
    for _ in range(RIDER_PASSES):
        _, vdb = _frame_db(_k_weight(rode.mean(axis=1), sr), sr)
        active = (vdb > vdb.max() - RIDER_ACTIVE_RANGE_DB) & (vdb > -55)
        if active.sum() < 20:
            raise RuntimeError("노래하는 구간을 찾지 못했습니다(연주곡이거나 보컬이 너무 작음)")
        rel = vdb - bdb                                   # 반주 대비 보컬 크기(귀 기준)
        if first is None:
            first = (rel, active)
        target = np.median(rel[active]) + RIDER_PRESENCE_DB
        gain = np.where(active, np.clip(target - rel, -RIDER_MAX_GAIN_DB, RIDER_MAX_GAIN_DB), np.nan)

        # 노래하지 않는 구간은 직전 게인에서 초당 4dB 씩 0dB 로 복귀(쉼표마다 울렁이지 않게)
        out, last = np.zeros_like(rel), 0.0
        for i, g in enumerate(gain):
            last = (last - np.sign(last) * min(abs(last), decay)) if np.isnan(g) else g
            out[i] = last
        out = _smooth(out, max(1, int(RIDER_SMOOTH_SEC / RIDER_HOP_SEC)))
        lin = (10 ** (np.interp(np.arange(n), centers, out) / 20)).astype(np.float32)
        rode = rode * lin[:, None]

    sf.write(str(out_path), rode, sr, subtype="FLOAT")
    _, vdb2 = _frame_db(_k_weight(rode.mean(axis=1), sr), sr)
    rel0, act0 = first
    return round(spread(rel0, act0), 1), round(spread(vdb2 - bdb, act0), 1)


def balance_vocals(flac: Path, work_dir: Path, device: str = "cuda", timeout: int = 900):
    """
    반환: (마스터링에 넣을 파일 경로, 결과 설명 문자열, 소요 초)
    실패하면 (원본 flac, "건너뜀: 이유", 소요 초)
    """
    t0 = time.time()
    flac, work_dir = Path(flac), Path(work_dir)
    try:
        if not FFMPEG:
            raise RuntimeError("ffmpeg 없음")
        stem_root = work_dir / "_balance"
        shutil.rmtree(stem_root, ignore_errors=True)
        stem_root.mkdir(parents=True, exist_ok=True)

        # 1) Demucs 2스템 분리 (/api/separate-stems 와 같은 호출 방식)
        module = os.environ.get("JK_DEMUCS_MODULE", "demucs")
        _run([sys.executable, "-m", module, "-d", device, "-n", "htdemucs", "--two-stems", "vocals",
              "--out", str(stem_root), str(flac)], timeout)
        sdir = stem_root / "htdemucs" / flac.stem
        vocals, backing = sdir / "vocals.wav", sdir / "no_vocals.wav"
        if not (vocals.exists() and backing.exists()):
            raise RuntimeError("분리 결과 파일(vocals/no_vocals)이 없습니다")

        # 2) 보컬 라이더: 반주 대비 보컬 크기를 일정하게
        rode = sdir / "vocals_rode.wav"
        before, after = vocal_rider(vocals, backing, rode)

        # 3) 게이트 + 가벼운 압축
        leveled = sdir / "vocals_leveled.wav"
        _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(rode),
              "-af", VOCAL_POST, "-c:a", "pcm_f32le", str(leveled)], 300)

        # 4) 재합성 (반주는 원래 그대로)
        remixed = work_dir / "remixed.flac"
        _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(leveled), "-i", str(backing),
              "-filter_complex", REMIX_GRAPH, "-map", "[out]", "-ar", "48000", "-c:a", "flac",
              "-sample_fmt", "s32", str(remixed)], 300)
        if not remixed.exists() or remixed.stat().st_size == 0:
            raise RuntimeError("재합성 파일이 비어 있습니다")
        return remixed, f"보컬 라이더 적용 (반주 대비 편차 {before}→{after}dB)", round(time.time() - t0, 1)
    except Exception as e:
        print(f"[보컬 밸런싱 건너뜀 → 기존 방식으로 마스터링] {e}")
        return flac, f"건너뜀: {str(e)[:120]}", round(time.time() - t0, 1)
