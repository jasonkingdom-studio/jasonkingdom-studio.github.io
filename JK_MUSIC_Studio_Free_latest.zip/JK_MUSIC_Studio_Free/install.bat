@echo off
chcp 65001 >nul
title JK MUSIC Studio - Install
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
