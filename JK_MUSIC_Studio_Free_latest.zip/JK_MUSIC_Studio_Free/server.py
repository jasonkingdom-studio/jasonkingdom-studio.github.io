# -*- coding: utf-8 -*-
"""
JK MUSIC Studio PRO — 로컬 AI 작곡 서버 v3
────────────────────────────────────────────────────────────
· YuE2 풀송(보컬+반주) 생성 : 백그라운드 작업 대기열 + 실제 진행률 + 취소
· 장르 설계 엔진(music_brain + music_options) : 스타일 프롬프트 자동 설계
· 제목 중심 AI 작사 : Claude → Gemini(과부하 자동 재시도)
· 7단계 스튜디오 마스터링(ffmpeg) · Demucs 스템 분리 · 보관함(이름 변경/휴지통)
실행: python server.py  →  http://127.0.0.1:7860
"""
import os
import re
import sys
import json
import time
import uuid
import queue
import shutil
import threading
import traceback
import subprocess
from pathlib import Path
from typing import List, Optional

# 콘솔 한글 출력
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import torch
from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from pydantic import BaseModel

import music_brain as mb
import music_options as mo   # 장르/보컬/분위기/악기 확장 + Gemini 재시도 적용
import vocal_balance as vb   # 스템 기반 자동 보컬 밸런싱 (실패 시 원본으로 폴백)
# 보컬 밸런싱 사용 여부 — 2026-09-24 청취 평가에서 노이즈 증가·반주 펌핑이 확인되어 꺼 둠(False)
VOCAL_BALANCE_ENABLED = False

# ════════════════════════════════════════════════════════════════
# 경로 · 장치
# ════════════════════════════════════════════════════════════════
BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "outputs"
STATIC_DIR = BASE_DIR / "static"
TRASH_DIR = OUTPUT_DIR / "_trash"
PREVIEW_DIR = STATIC_DIR / "previews"          # 장르 미리듣기 (generate_previews.py 로 생성)
MODEL_DIR = BASE_DIR / "models" / "YuE2-3B"
VAE_DIR = BASE_DIR / "models" / "YuE2-Vae"
for d in (OUTPUT_DIR, STATIC_DIR, TRASH_DIR):
    d.mkdir(parents=True, exist_ok=True)

# 설치 프로그램이 받아 둔 앱 폴더 안 ffmpeg 를 우선 사용 (Demucs 등 하위 프로세스도 같이 사용)
_LOCAL_FFMPEG = BASE_DIR / "tools" / "ffmpeg" / "bin"
if _LOCAL_FFMPEG.exists():
    os.environ["PATH"] = str(_LOCAL_FFMPEG) + os.pathsep + os.environ.get("PATH", "")

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
GPU_NAME = torch.cuda.get_device_name(0) if DEVICE == "cuda" else "CPU"
VRAM_GB = round(torch.cuda.get_device_properties(0).total_memory / 1024 ** 3, 1) if DEVICE == "cuda" else 0
FFMPEG = shutil.which("ffmpeg")
print(f"[*] JK MUSIC Studio PRO v3 — {DEVICE} ({GPU_NAME}, {VRAM_GB}GB) · ffmpeg={'OK' if FFMPEG else '없음'}")

app = FastAPI(title="JK MUSIC Studio PRO API", version="3.0")
# 보안: 이 PC 의 앱 화면에서 온 요청만 받는다 (다른 웹사이트가 몰래 호출하지 못하게)
_ALLOWED_HOSTS = {"127.0.0.1", "localhost"}


@app.middleware("http")
async def _local_only(request: Request, call_next):
    host = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]").lower()
    origin = request.headers.get("origin")
    if host not in _ALLOWED_HOSTS:
        return JSONResponse({"success": False, "detail": "허용되지 않은 접근입니다."}, status_code=403)
    if origin and origin.split("//", 1)[-1].rsplit(":", 1)[0].lower() not in _ALLOWED_HOSTS:
        return JSONResponse({"success": False, "detail": "허용되지 않은 접근입니다."}, status_code=403)
    return await call_next(request)
app.mount("/outputs", StaticFiles(directory=str(OUTPUT_DIR)), name="outputs")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# ════════════════════════════════════════════════════════════════
# YuE2 진행 출력 가로채기 → 현재 작업 진행률로 변환
#   YuE2 Progress 는 생성 시점의 sys.stderr 에 쓰므로 여기서 교체해 두면 된다.
# ════════════════════════════════════════════════════════════════
_YUE_RE = re.compile(r"\[YuE2\]\s+(Starting|Running|Completed)\s+([A-Za-z ]+?):\s*(.*)")
_progress_listener = None   # 현재 실행 중인 작업의 콜백

class _StderrTap:
    def __init__(self, orig):
        self._orig = orig
        self._buf = ""

    def write(self, s):
        try:
            self._orig.write(s)
        except Exception:
            pass
        self._buf += s.replace("\r", "\n")
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            if "[YuE2]" in line and _progress_listener:
                m = _YUE_RE.search(line)
                if m:
                    try:
                        _progress_listener(m.group(1), m.group(2).strip(), m.group(3))
                    except Exception:
                        pass
        return len(s)

    def flush(self):
        try:
            self._orig.flush()
        except Exception:
            pass

    def isatty(self):
        return False

    @property
    def encoding(self):
        return getattr(self._orig, "encoding", "utf-8")

sys.stderr = _StderrTap(sys.stderr)

# ════════════════════════════════════════════════════════════════
# YuE2 파이프라인 (한 번 로드 후 재사용)
# ════════════════════════════════════════════════════════════════
_pipe = None
_pipe_lock = threading.Lock()
# 그래픽카드 메모리에 맞춘 예산 (16GB 카드 = 15GiB, 더 작으면 여유 1GiB 남김)
MEMORY_BUDGET_GIB = max(4, min(15, int(VRAM_GB) - 1)) if VRAM_GB else 15


def models_ready():
    """모델 가중치 파일이 모두 받아져 있는지 (크기 0 인 미완성 파일 제외)"""
    need = [MODEL_DIR / "model.safetensors", VAE_DIR / "model.safetensors", MODEL_DIR / "config.json"]
    return all(p.exists() and p.stat().st_size > 0 for p in need)

def get_pipeline():
    global _pipe
    with _pipe_lock:
        if _pipe is None:
            if not models_ready():
                raise RuntimeError("YuE2 모델이 아직 설치되지 않았습니다. 앱 폴더의 download_models.bat 을 실행해 주세요.")
            from yue2 import YuE2Pipeline
            t0 = time.time()
            _pipe = YuE2Pipeline.from_pretrained(
                str(MODEL_DIR), vae=str(VAE_DIR), local_files_only=True,
                device="cuda", backend="torch-eager", memory_budget_gib=MEMORY_BUDGET_GIB)
            print(f"[+] YuE2 파이프라인 준비 완료 ({time.time() - t0:.1f}s)")
    return _pipe

# ════════════════════════════════════════════════════════════════
# 마스터링 (7단계 → 실패 시 단계적 폴백)
# ════════════════════════════════════════════════════════════════
# ── (이전 체인 v1 — 되돌릴 때 아래 주석을 풀고 새 MASTER_CHAIN 을 주석 처리) ──
# MASTER_CHAIN = (
#     "asubboost=dry=0.8:wet=0.6:decay=0.7:feedback=0.5:cutoff=120:slope=0.6:delay=20,"
#     "acompressor=threshold=0.045:ratio=3.5:attack=8:release=180:makeup=2.2:knee=4,"
#     "equalizer=f=8000:width_type=o:width=2:g=2.0,"
#     "equalizer=f=400:width_type=o:width=1.5:g=-1.5,"
#     "equalizer=f=80:width_type=o:width=1:g=1.5,"
#     "stereowiden=crossfeed=0.3:feedback=0.25,"
#     "aecho=0.8:0.88:60:0.4,"
#     "loudnorm=I=-14:TP=-1.0:LRA=11"
# )

# ── 마스터링 체인 v2 ─────────────────────────────────────────────
#  · speechnorm 추가 : 보컬 구간별 음량 편차를 시간에 따라 평탄화
#  · acompressor 1단(threshold=0.06, ratio=2.5, release=250) + 2단(threshold=0.15, ratio=1.8, release=100)
#      : 느슨한 레벨링 압축 뒤 타이트한 글루 압축 — 벌스/후렴 낙차 완화
#  · equalizer 200Hz +1.8dB 추가 : 저중역 두께감(풍성함) 보강
#  · equalizer 400Hz -1.5 → -1.0dB : 과도한 스쿱으로 얇아지는 것 방지
#  · asoftclip(tanh) 추가 : 배음 새추레이션으로 밀도감/따뜻함 추가
#  · loudnorm LRA 11 → 9 : 체감 음량을 더 일정하게
MASTER_CHAIN = (
    "asubboost=dry=0.8:wet=0.6:decay=0.7:feedback=0.5:cutoff=120:slope=0.6:delay=20,"
    "speechnorm=e=6.25:r=0.0001:l=1,"
    "acompressor=threshold=0.06:ratio=2.5:attack=15:release=250:makeup=1.5:knee=6,"
    "acompressor=threshold=0.15:ratio=1.8:attack=5:release=100:makeup=1.2:knee=3,"
    "equalizer=f=200:width_type=o:width=1.2:g=1.8,"
    "equalizer=f=8000:width_type=o:width=2:g=2.0,"
    "equalizer=f=400:width_type=o:width=1.5:g=-1.0,"
    "equalizer=f=80:width_type=o:width=1:g=1.5,"
    "asoftclip=type=tanh:threshold=0.9,"
    "stereowiden=crossfeed=0.3:feedback=0.25,"
    "aecho=0.8:0.88:60:0.4,"
    "loudnorm=I=-14:TP=-1.0:LRA=9"
)

# ── 마스터링 체인 v3 (비교 후보 · 아직 파이프라인 미적용 — 채택 시 master_to_mp3 의 첫 체인으로 교체) ──
#  v2 대비 변경점
#  · aecho, stereowiden 완전히 제거 : 에코의 딜레이/피드백과 과도한 스테레오 확산이 소리를 얇게 만드는 원인으로 의심
#  · 압축 1단/2단을 다시 조임 (0.06→0.05, ratio 2.5→3 / 0.15→0.12, ratio 1.8→2.2) : v1 수준으로 편차 축소
#  · asoftclip threshold 0.9→0.85 : 압축을 조인 만큼 새추레이션으로 밀도감 보강
#  · loudnorm LRA 목표 9→7 : 더 일정한 체감 음량
MASTER_CHAIN_V3 = (
    "asubboost=dry=0.8:wet=0.6:decay=0.7:feedback=0.5:cutoff=120:slope=0.6:delay=20,"
    "speechnorm=e=6.25:r=0.0001:l=1,"
    "acompressor=threshold=0.05:ratio=3:attack=12:release=220:makeup=1.8:knee=5,"
    "acompressor=threshold=0.12:ratio=2.2:attack=5:release=90:makeup=1.3:knee=3,"
    "equalizer=f=200:width_type=o:width=1.2:g=2.0,"
    "equalizer=f=8000:width_type=o:width=2:g=1.8,"
    "equalizer=f=400:width_type=o:width=1.5:g=-1.0,"
    "equalizer=f=80:width_type=o:width=1:g=1.6,"
    "asoftclip=type=tanh:threshold=0.85,"
    "loudnorm=I=-14:TP=-1.0:LRA=7"
)

# ── 마스터링 v3.5 (v2와 v3 사이 · 목표 LRA 2.5~3) ─────────────────────
#  원인 분석(고향 가는 기차, 필터 누적 측정) 결과 v3 가 LRA 1.8 로 과압축된 이유는 세 가지였다.
#   ① speechnorm(e=6.25)이 전체 믹스의 작은 소리를 최대 +16dB 끌어올려(평균 +4.7dB) 뒤 압축기를 과구동
#   ② 압축 1단 threshold 0.05(≈-26dBFS)가 곡의 평소 레벨보다 한참 아래 → 곡 전체를 3:1 로 압축
#   ③ loudnorm 동적 모드가 자동 볼륨처럼 남은 강약까지 평탄화
#  v3.5 조치
#   · speechnorm 강도 6.25 → 1.5 (보컬 평탄화는 보컬 밸런싱 단계가 담당하므로 전체 믹스엔 약하게)
#   · 압축 1단/2단 threshold 0.18(≈-15dBFS) — 큰 소리만 잡도록, makeup 1 (softclip 과구동 방지)
#   · asoftclip 0.9 (가볍게) · EQ 는 v3 유지 · aecho/stereowiden 없음
#   · loudnorm 대신 2패스: 본체 통합음량 측정 → 고정 게인으로 -14 LUFS → 리미터(-1.5dBFS) 로 피크만 보호
MASTER_BODY_V35 = (
    "asubboost=dry=0.8:wet=0.6:decay=0.7:feedback=0.5:cutoff=120:slope=0.6:delay=20,"
    "speechnorm=e=1.5:r=0.0001:l=1,"
    "acompressor=threshold=0.18:ratio=2.5:attack=12:release=220:makeup=1:knee=5,"
    "acompressor=threshold=0.18:ratio=2.0:attack=5:release=90:makeup=1:knee=3,"
    "equalizer=f=200:width_type=o:width=1.2:g=2.0,"
    "equalizer=f=8000:width_type=o:width=2:g=1.8,"
    "equalizer=f=400:width_type=o:width=1.5:g=-1.0,"
    "equalizer=f=80:width_type=o:width=1:g=1.6,"
    "asoftclip=type=tanh:threshold=0.9"
)
V35_TARGET_LUFS = -14.0
V35_LIMITER = "alimiter=limit=0.84:attack=3:release=60:level=0"


def measure_integrated(src, body):
    """본체 체인을 거친 뒤의 통합 음량(LUFS) 측정 — v3.5 2패스의 1패스"""
    r = subprocess.run([FFMPEG or "ffmpeg", "-hide_banner", "-nostats", "-i", str(src), "-af", body + ",ebur128",
                        "-f", "null", "-"], capture_output=True, text=True, encoding="utf-8", errors="replace").stderr
    return float(re.findall(r"I:\s*(-?[\d.]+) LUFS", r)[-1])


def v35_chain(src):
    """v3.5 완성 체인 문자열 (본체 + 고정 게인 + 리미터)"""
    gain = V35_TARGET_LUFS - measure_integrated(src, MASTER_BODY_V35)
    return f"{MASTER_BODY_V35},volume={gain:.2f}dB,{V35_LIMITER}"

# ── 클린 마스터 (현재 사용 중 · 2026-09-24 청취 평가로 채택) ────────────────
#  청취 평가 결과: v2·v3.5·보컬 밸런싱은 노이즈 증가와 반주/보컬 펌핑(들쭉날쭉)을 만들었고,
#  AI 원본은 괜찮았다. 문제는 곡 재생 중 볼륨을 계속 움직이는 장치들
#  (speechnorm · 사이드체인 덕킹 · 보컬 라이더 · loudnorm 동적 모드)이었다.
#  → 원칙: 재생 중 볼륨을 움직이는 처리는 쓰지 않는다.
#   · 음색만 살짝 보정: 초저역 정리(28Hz 이하) · 200Hz +1.5 두께 · 400Hz -1 탁함 · 3kHz +1 보컬 선명도 · 10kHz +1.5 공기감
#   · 아주 약한 글루 압축(-10.5dBFS 이상, 1.5:1, 느린 반응) — 큰 피크만 살짝 정리
#   · 음량은 2패스: 먼저 측정 → 고정 게인 한 번으로 -14 LUFS → 리미터는 피크 보호용(-1dBFS)
MASTER_CLEAN_BODY = (
    "highpass=f=28,"
    "equalizer=f=200:width_type=o:width=1.2:g=1.5,"
    "equalizer=f=400:width_type=o:width=1.5:g=-1.0,"
    "equalizer=f=3000:width_type=o:width=1.5:g=1.0,"
    "equalizer=f=10000:width_type=o:width=2:g=1.5,"
    "acompressor=threshold=0.3:ratio=1.5:attack=30:release=400:makeup=1:knee=6"
)
MASTER_CLEAN_LIMITER = "alimiter=limit=0.89:attack=5:release=80:level=0"


def clean_chain(src):
    """클린 마스터 완성 체인 (본체 + 고정 게인 + 피크 보호 리미터)"""
    gain = V35_TARGET_LUFS - measure_integrated(src, MASTER_CLEAN_BODY)
    gain = max(-12.0, min(12.0, gain))        # 비정상 측정값 방어
    return f"{MASTER_CLEAN_BODY},volume={gain:.2f}dB,{MASTER_CLEAN_LIMITER}"


# 구버전 ffmpeg(speechnorm·asoftclip 미지원)용 축소 체인 — 두 필터만 제외
MASTER_CHAIN_LITE = ",".join(f for f in MASTER_CHAIN.split(",")
                             if not f.startswith(("speechnorm", "asoftclip")))

def master_to_mp3(flac_path: Path, mp3_path: Path) -> str:
    if not FFMPEG:
        raise RuntimeError("ffmpeg 가 설치되어 있지 않아 MP3 마스터링을 할 수 없습니다.")
    try:
        first = (clean_chain(flac_path), "320k", "클린 마스터링")
    except Exception as e:                     # 측정 실패 시에도 곡 생성은 계속
        print(f"[클린 마스터 측정 실패 → 단순 정규화로 진행] {e}")
        first = ("loudnorm=I=-14:TP=-1.0:LRA=20:linear=true", "320k", "라우드니스 정규화(선형)")
    # v2(MASTER_CHAIN) 등 이전 체인은 비교용으로만 남겨 두고 파이프라인에서는 쓰지 않는다
    chains = [first,
              ("loudnorm=I=-14:TP=-1.0:LRA=20:linear=true", "320k", "라우드니스 정규화(선형)"),
              (None, "256k", "기본 변환")]
    for af, br, label in chains:
        cmd = [FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(flac_path)]
        if af:
            cmd += ["-af", af]
        cmd += ["-ar", "44100", "-b:a", br, str(mp3_path)]
        r = subprocess.run(cmd, capture_output=True)
        if r.returncode == 0 and mp3_path.exists() and mp3_path.stat().st_size > 0:
            return label
    raise RuntimeError("ffmpeg 마스터링에 실패했습니다.")

# ════════════════════════════════════════════════════════════════
# 작업(Job) 대기열
# ════════════════════════════════════════════════════════════════
class SongRequest(BaseModel):
    title: str = ""
    style: str
    lyrics: str = ""
    genre: str = ""
    vocal: str = ""
    bpm: Optional[int] = None
    key: str = ""
    seed: Optional[int] = None

class Job:
    def __init__(self, req: SongRequest, client_ip: str = "unknown"):
        self.id = uuid.uuid4().hex[:10]
        self.req = req
        self.client_ip = client_ip          # 요청자 IP (동시 작업 제한용)
        self.status = "queued"      # queued → running → done / failed / cancelled
        self.stage = "대기 중"
        self.detail = ""
        self.percent = 0.0
        self.created = time.time()
        self.started = None
        self.finished = None
        self.result = None
        self.error = None
        self.cancel = False
        sung = [l for l in mb.to_engine_lyrics(req.lyrics).split("\n") if l.strip() and not l.startswith("[")]
        self.est_audio_sec = 30 + len(sung) * 5.5          # 대략적인 곡 길이 추정
        self.est_sem_tokens = max(3000, len(sung) * 200)       # 실측: 가사 1줄 ≈ 음원 토큰 200

    def public(self):
        now = time.time()
        pos = None
        if self.status == "queued":
            pos = 1 + sum(1 for j in JOBS.values() if j.status == "queued" and j.created < self.created)
        return {
            "job_id": self.id, "status": self.status, "stage": self.stage, "detail": self.detail,
            "percent": round(self.percent, 1), "queue_position": pos,
            "elapsed_sec": round((self.finished or now) - (self.started or now), 1) if self.started else 0,
            "title": self.req.title, "result": self.result, "error": self.error,
        }

JOBS = {}
JOB_Q = queue.Queue()

# ── 자원 보호: 요청 제한 ─────────────────────────────────────────
MAX_ACTIVE_PER_IP = 1        # IP당 대기+실행 중 작업 최대 개수
MAX_ACTIVE_TOTAL = 20        # 서버 전체 대기+실행 중 작업 최대 개수
LYRICS_COOLDOWN_SEC = 5      # 같은 IP의 AI 작사 재요청 최소 간격(초) — LLM 비용 보호
_limit_lock = threading.Lock()
_last_lyrics_at = {}         # IP → 마지막 작사 요청 시각

def _client_ip(request: Request) -> str:
    return (request.client.host if request and request.client else None) or "unknown"

def _enqueue_job(req: SongRequest, ip: str) -> "Job":
    """제한 검사와 등록을 한 번에(동시 요청 경쟁 방지)"""
    with _limit_lock:
        active = [j for j in JOBS.values() if j.status in ("queued", "running")]
        if sum(1 for j in active if j.client_ip == ip) >= MAX_ACTIVE_PER_IP:
            raise HTTPException(429, "이미 진행 중인 작곡 작업이 있습니다. 완료된 후 다시 시도해 주세요.")
        if len(active) >= MAX_ACTIVE_TOTAL:
            raise HTTPException(429, "지금 서버가 매우 바쁩니다. 잠시 후 다시 시도해 주세요.")
        job = Job(req, ip)
        JOBS[job.id] = job
        JOB_Q.put(job)
        return job

def _check_lyrics_cooldown(ip: str):
    with _limit_lock:
        now = time.time()
        last = _last_lyrics_at.get(ip, 0)
        if now - last < LYRICS_COOLDOWN_SEC:
            wait = int(LYRICS_COOLDOWN_SEC - (now - last)) + 1
            raise HTTPException(429, f"작사 요청이 너무 잦습니다. {wait}초 후 다시 시도해 주세요.")
        _last_lyrics_at[ip] = now

def _stage_progress(job, kind, name, rest):
    """YuE2 진행 줄 → (단계 이름, 퍼센트)"""
    tok = re.search(r"(\d+)\s+tokens", rest)
    steps = re.search(r"(\d+)/(\d+)\s+steps", rest)
    if name.startswith(("Resolving", "Verifying", "Loading")):
        # 합성 뒤 VAE 로딩도 같은 이름으로 출력되므로, 초반에만 "엔진 준비"로 표시
        if job.percent < 10:
            job.stage, job.percent = "엔진 준비", max(job.percent, 3)
        else:
            job.stage, job.percent = "④ 48kHz 오디오 복원", max(job.percent, 93)
    elif name.startswith("Planning"):
        n = int(tok.group(1)) if tok else 0
        job.stage = "① 멜로디·코드 설계"
        job.detail = f"악보 토큰 {n:,}"
        job.percent = max(job.percent, 3 + 5 * min(1, n / 1500))
    elif name.startswith("Generating"):
        n = int(tok.group(1)) if tok else 0
        job.stage = "② 보컬·반주 음원 생성"
        job.detail = f"음원 토큰 {n:,}"
        job.percent = max(job.percent, 8 + 37 * min(0.98, n / job.est_sem_tokens))
    elif name.startswith("Synthesizing"):
        job.stage = "③ 고음질 합성"
        if steps:
            a, b = int(steps.group(1)), int(steps.group(2))
            job.detail = f"합성 {a}/{b} 단계"
            job.percent = max(job.percent, 45 + 48 * a / max(1, b))
    elif name.startswith("Decoding"):
        job.stage, job.percent = "④ 48kHz 오디오 복원", max(job.percent, 94)
    if kind == "Completed" and name.startswith("Generating"):
        job.percent = max(job.percent, 45)

def _run_job(job: Job):
    global _progress_listener
    req = job.req
    song_id = f"song_{uuid.uuid4().hex[:6]}"
    out_dir = OUTPUT_DIR / song_id
    try:
        job.status, job.started = "running", time.time()
        job.stage, job.percent = "엔진 준비", 1
        pipe = get_pipeline()

        lyrics = (req.lyrics or "").strip()
        style = req.style.strip()
        style_l = style.lower()
        instrumental = (not mb.has_sung_lines(lyrics)) or ("instrumental" in style_l and "no vocals" in style_l)
        if instrumental:
            if "instrumental" not in style_l:
                style = f"instrumental, no vocals, {style}"
            if not lyrics:
                lyrics = mb.instrumental_lyrics(req.genre)
        engine_lyrics = mb.to_engine_lyrics(lyrics)
        seed = req.seed if req.seed is not None else int(time.time() * 1000) % 1_000_000

        out_dir.mkdir(parents=True, exist_ok=True)
        print(f"[작곡 시작] {song_id} '{req.title}' instrumental={instrumental}\n[Style] {style}")
        _progress_listener = lambda k, n, r: _stage_progress(job, k, n, r)
        song = pipe(id=song_id, style=style, lyrics=engine_lyrics, cot="full", seed=seed,
                    cancelled=lambda: job.cancel)
        _progress_listener = None

        job.stage, job.detail, job.percent = "⑤ 음원 저장", "", 94
        try:
            song.save_artifacts(out_dir)
        except Exception as se:
            print(f"[경고] save_artifacts 실패 → 오디오만 저장: {se}")
            song.save(out_dir / "audio.flac")
        flac = out_dir / "audio.flac"
        mp3 = OUTPUT_DIR / f"{song_id}.mp3"

        # ⑤-1 보컬 밸런싱: 보컬/반주 분리 → 보컬만 레벨링 → 덕킹 재합성 (실패해도 원본으로 계속 진행)
        master_src, balance_note, balance_sec = flac, ("해당 없음(연주곡)" if instrumental else "꺼짐"), 0.0
        if VOCAL_BALANCE_ENABLED and not instrumental:
            job.stage, job.detail, job.percent = "⑤-1 보컬 밸런싱", "보컬·반주 분리 → 보컬 음량 고르게 → 재합성 (1~2분)", 95
            master_src, balance_note, balance_sec = vb.balance_vocals(flac, out_dir, device=DEVICE)
            print(f"[보컬 밸런싱] {balance_note} ({balance_sec}s)")

        job.stage, job.detail, job.percent = "⑤-2 스튜디오 마스터링", "", 98
        master_label = master_to_mp3(master_src, mp3)

        duration = round(len(song.audio) / song.sample_rate, 1)
        title = req.title.strip() or (f"[BGM] {req.genre}" if instrumental else f"JK MUSIC {song_id[-6:]}")
        meta = {
            "song_id": song_id, "title": title, "genre": req.genre, "vocal": req.vocal,
            "bpm": req.bpm, "key": req.key, "style": style, "lyrics": lyrics,
            "is_instrumental": instrumental, "seed": seed, "duration_sec": duration,
            "generation_time_sec": round(time.time() - job.started, 1), "mastering": master_label,
            "vocal_balance": balance_note, "vocal_balance_sec": balance_sec,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "mp3_url": f"/outputs/{mp3.name}", "flac_url": f"/outputs/{song_id}/audio.flac",
            "filename": mp3.name,
        }
        (out_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        job.result, job.status, job.stage, job.percent = meta, "done", "완료", 100
        print(f"[작곡 완료] {song_id} {duration}s · {master_label}")
    except InterruptedError:
        job.status, job.stage = "cancelled", "취소됨"
        shutil.rmtree(out_dir, ignore_errors=True)
        print(f"[작곡 취소] {song_id}")
    except torch.cuda.OutOfMemoryError:
        job.status, job.stage = "failed", "실패"
        job.error = "GPU 메모리가 부족합니다. 다른 GPU 프로그램(게임·영상 생성 등)을 닫고 다시 시도해 주세요."
        shutil.rmtree(out_dir, ignore_errors=True)
    except Exception as e:
        traceback.print_exc()
        job.status, job.stage = "failed", "실패"
        job.error = f"작곡 중 오류가 발생했습니다: {e}"
        shutil.rmtree(out_dir, ignore_errors=True)
    finally:
        _progress_listener = None
        job.finished = time.time()
        if DEVICE == "cuda":
            torch.cuda.empty_cache()

def _worker():
    while True:
        job = JOB_Q.get()
        if job.cancel:
            job.status, job.stage, job.finished = "cancelled", "취소됨", time.time()
            continue
        _run_job(job)

threading.Thread(target=_worker, daemon=True, name="song-worker").start()

def _validate_song(req: SongRequest):
    if not req.style or len(req.style.strip()) < 5:
        raise HTTPException(400, "스타일 프롬프트가 비어 있습니다. 장르를 선택하거나 🔄 자동 설계를 눌러 주세요.")
    if len(req.style) > 1500:
        raise HTTPException(400, "스타일 프롬프트가 너무 깁니다(1500자 이하).")
    if len(req.lyrics) > 6000:
        raise HTTPException(400, "가사가 너무 깁니다(6000자 이하). 곡이 잘릴 수 있습니다.")
    if req.bpm is not None and not (40 <= req.bpm <= 220):
        raise HTTPException(400, "BPM은 40~220 사이여야 합니다.")

# ════════════════════════════════════════════════════════════════
# API — 시스템 / 옵션 / 스타일 / 작사
# ════════════════════════════════════════════════════════════════
@app.get("/api/system-info")
def system_info():
    warnings = []
    if DEVICE != "cuda":
        warnings.append("CUDA GPU를 찾지 못했습니다. NVIDIA 그래픽카드와 최신 드라이버가 필요합니다.")
    if not models_ready():
        warnings.append("YuE2 모델이 아직 설치되지 않았습니다. 앱 폴더의 download_models.bat 을 실행해 주세요 (약 7.4GB).")
    if not FFMPEG:
        warnings.append("ffmpeg 가 없어 MP3 마스터링이 불가합니다. install.bat 을 다시 실행해 주세요.")
    if DEVICE == "cuda" and VRAM_GB < 15:
        warnings.append(f"그래픽카드 메모리가 {VRAM_GB}GB 입니다. 16GB 에서 검증된 앱이라 긴 곡은 메모리 부족으로 실패할 수 있습니다.")
    return {"device": DEVICE, "gpu_name": GPU_NAME, "vram_gb": VRAM_GB,
            "model_loaded": _pipe is not None, "llm": mb.llm_status(), "warnings": warnings}

class SettingsRequest(BaseModel):
    anthropic_api_key: Optional[str] = None   # None = 그대로, "" = 삭제
    gemini_api_key: Optional[str] = None


def _settings_view():
    st = mb.load_settings()
    return {"success": True,
            "claude": mb.masked(st.get("ANTHROPIC_API_KEY", "")),
            "gemini": mb.masked(st.get("GEMINI_API_KEY", "")),
            "llm": mb.llm_status()}


@app.get("/api/settings")
def get_settings():
    return _settings_view()


@app.post("/api/settings")
def set_settings(req: SettingsRequest):
    for v in (req.anthropic_api_key, req.gemini_api_key):
        if v and len(v.strip()) > 300:
            raise HTTPException(400, "API 키가 너무 깁니다. 다시 확인해 주세요.")
    mb.save_settings({"ANTHROPIC_API_KEY": req.anthropic_api_key, "GEMINI_API_KEY": req.gemini_api_key})
    return _settings_view()


@app.post("/api/settings/test")
def test_settings():
    """저장된 키로 아주 짧은 요청을 보내 동작 확인 (비용 거의 없음)"""
    out = {}
    ck, gk = mb._env("ANTHROPIC_API_KEY"), mb._env("GEMINI_API_KEY", "GOOGLE_API_KEY")
    for name, key, fn in (("claude", ck, mb._call_claude), ("gemini", gk, mb._call_gemini)):
        if not key:
            out[name] = "키 없음"
            continue
        try:
            fn("'확인'이라는 한 단어로만 답하세요.", key)
            out[name] = "정상"
        except Exception as e:
            msg = str(e)
            if hasattr(e, "read"):
                try:
                    msg = e.read().decode("utf-8", "ignore")[:200]
                except Exception:
                    pass
            out[name] = "실패: " + msg[:200]
    return {"success": True, **out}


@app.get("/api/options")
def options_api():
    o = mo.options()
    for g in o["genres"].values():              # 미리듣기 파일이 있는 장르만 주소 제공
        f = PREVIEW_DIR / f"{g['slug']}.mp3"
        g["preview_url"] = f"/static/previews/{g['slug']}.mp3" if f.exists() else None
    return {"success": True, **o}

@app.get("/api/preview/{genre:path}")
def preview_api(genre: str):
    """장르 미리듣기 mp3 (장르 이름에 '/'가 있어 path 형식으로 받음)"""
    if genre not in mb.G:
        raise HTTPException(404, "알 수 없는 장르입니다.")
    f = PREVIEW_DIR / f"{mo.genre_slug(genre)}.mp3"
    if not f.exists():
        raise HTTPException(404, "이 장르는 아직 미리듣기가 준비되지 않았습니다.")
    return FileResponse(str(f), media_type="audio/mpeg")

@app.get("/api/llm-status")
def llm_status_api():
    return {"success": True, **mb.llm_status()}

class StyleRequest(BaseModel):
    genre: str = "감성 팝 발라드"
    vocal: str = "맑고 감미로운 여성 보컬"
    mood: str = "기본 장르 최적화"
    inst_focus: str = "기본 편성"
    chips: List[str] = []
    inst_explicit: bool = False
    dynamics: str = "스튜디오 마스터링 & 와이드 다이내믹스"
    lang: str = "auto"
    bpm: Optional[int] = None
    key_mode: str = "auto"
    title: str = ""
    topic: str = ""

def _style_from(r: StyleRequest):
    bpm = r.bpm if (r.bpm and 40 <= r.bpm <= 220) else None
    return mb.build_style(r.genre, r.vocal, r.mood, r.inst_focus, r.chips, r.dynamics,
                          r.lang, bpm, r.key_mode, r.title, r.topic, inst_explicit=r.inst_explicit)

@app.post("/api/build-style")
def build_style_api(req: StyleRequest):
    return {"success": True, **_style_from(req)}

@app.post("/api/generate-lyrics")
def generate_lyrics(req: StyleRequest, request: Request):
    title = (req.title or "").strip()
    if not title:
        raise HTTPException(400, "곡 제목을 먼저 입력해 주세요. 가사는 제목을 중심으로 작성됩니다.")
    if len(title) > 80:
        raise HTTPException(400, "제목은 80자 이하로 입력해 주세요.")
    _check_lyrics_cooldown(_client_ip(request))     # 같은 IP 5초 이내 중복 호출 차단
    info = _style_from(req)
    if info["instrumental"]:
        return {"success": True, "lyrics": mb.instrumental_lyrics(req.genre), "provider": "none",
                "title_ok": True, "note": "연주곡(BGM) 보컬이 선택되어 섹션 구조만 만들었습니다.", **info}
    try:
        r = mb.write_lyrics(title, req.topic, req.genre, req.vocal, req.mood, info["lang"], info)
    except Exception as e:
        print(f"[AI 작사 실패] {e}")
        raise HTTPException(502, f"AI 작사에 실패했습니다. {e}")
    if not r["lyrics"].strip():
        raise HTTPException(502, "AI가 빈 가사를 돌려주었습니다. 다시 시도해 주세요.")
    print(f"[AI 작사] '{title}' provider={r['provider']} title_ok={r['title_ok']}")
    return {"success": True, **r, **info}

# ════════════════════════════════════════════════════════════════
# API — 작곡 작업
# ════════════════════════════════════════════════════════════════
@app.post("/api/jobs")
def create_job(req: SongRequest, request: Request):
    _validate_song(req)
    job = _enqueue_job(req, _client_ip(request))
    return {"success": True, **job.public()}

@app.get("/api/jobs/active")
def active_jobs():
    act = [j.public() for j in sorted(JOBS.values(), key=lambda j: j.created)
           if j.status in ("queued", "running")]
    return {"success": True, "jobs": act}

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "작업을 찾을 수 없습니다(서버가 재시작되었을 수 있습니다).")
    return {"success": True, **job.public()}

@app.post("/api/jobs/{job_id}/cancel")
def cancel_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "작업을 찾을 수 없습니다.")
    if job.status in ("done", "failed", "cancelled"):
        return {"success": True, **job.public()}
    job.cancel = True
    if job.status == "queued":
        job.status, job.stage = "cancelled", "취소됨"
    else:
        job.stage = "취소 중… (현재 단계가 끝나는 대로 멈춥니다)"
    return {"success": True, **job.public()}

@app.post("/api/generate-full-song")
def generate_full_song(req: SongRequest, request: Request):
    """이전 버전 호환용(동기): 작업을 넣고 끝날 때까지 기다린다."""
    _validate_song(req)
    job = _enqueue_job(req, _client_ip(request))
    while job.status in ("queued", "running"):
        time.sleep(1)
    if job.status != "done":
        raise HTTPException(500, job.error or job.stage)
    return {"success": True, **job.result}

# ════════════════════════════════════════════════════════════════
# API — 보관함
# ════════════════════════════════════════════════════════════════
def _read_meta(song_dir: Path):
    mf = song_dir / "meta.json"
    if mf.exists():
        try:
            return json.loads(mf.read_text(encoding="utf-8"))
        except Exception:
            return None
    return None

@app.get("/api/tracks")
def get_tracks():
    tracks = []
    for d in OUTPUT_DIR.iterdir():
        if not (d.is_dir() and d.name.startswith("song_")):
            continue
        meta = _read_meta(d)
        mp3 = OUTPUT_DIR / f"{d.name}.mp3"
        flac = d / "audio.flac"
        if meta is None:
            if not (mp3.exists() or flac.exists()):
                continue   # 실패로 남은 빈 폴더는 목록에서 제외
            src = mp3 if mp3.exists() else flac
            meta = {"song_id": d.name, "title": f"JK MUSIC {d.name[-6:]}", "style": "",
                    "duration_sec": None, "filename": f"{d.name}.mp3",
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(src.stat().st_mtime)),
                    "mp3_url": f"/outputs/{d.name}.mp3" if mp3.exists() else f"/outputs/{d.name}/audio.flac",
                    "flac_url": f"/outputs/{d.name}/audio.flac" if flac.exists() else f"/outputs/{d.name}.mp3"}
        stem_dir = OUTPUT_DIR / f"stems_{d.name}" / "htdemucs" / d.name
        if (stem_dir / "vocals.wav").exists():
            meta["stems"] = {s: f"/outputs/stems_{d.name}/htdemucs/{d.name}/{s}.wav"
                             for s in ("vocals", "drums", "bass", "other")}
        tracks.append(meta)
    master = OUTPUT_DIR / "jk_song.mp3"
    if master.exists():
        tracks.append({"song_id": "master_first_song", "title": "[JK MUSIC #1] 비 내린 거리 위에",
                       "genre": "감성 팝 발라드", "style": "Korean pop ballad, emotional piano, grand strings",
                       "duration_sec": 65.0, "created_at": "2026-09-19 19:28:00",
                       "mp3_url": "/outputs/jk_song.mp3", "filename": "jk_song.mp3",
                       "flac_url": "/outputs/jk_song.flac" if (OUTPUT_DIR / "jk_song.flac").exists() else "/outputs/jk_song.mp3",
                       "is_master": True})
    tracks.sort(key=lambda t: t.get("created_at", ""), reverse=True)
    return {"success": True, "count": len(tracks), "tracks": tracks}

def _song_dir(song_id: str) -> Path:
    if not re.fullmatch(r"song_[0-9a-f]{6}", song_id or ""):
        raise HTTPException(400, "잘못된 트랙 ID입니다.")
    d = OUTPUT_DIR / song_id
    if not d.exists():
        raise HTTPException(404, "트랙을 찾을 수 없습니다.")
    return d

class RenameRequest(BaseModel):
    title: str

@app.patch("/api/tracks/{song_id}")
def rename_track(song_id: str, req: RenameRequest):
    d = _song_dir(song_id)
    title = req.title.strip()
    if not title or len(title) > 80:
        raise HTTPException(400, "제목은 1~80자로 입력해 주세요.")
    meta = _read_meta(d) or {"song_id": song_id}
    meta["title"] = title
    (d / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"success": True, "title": title}

@app.delete("/api/tracks/{song_id}")
def delete_track(song_id: str):
    """완전 삭제 대신 outputs/_trash 로 이동 (복구 가능)"""
    d = _song_dir(song_id)
    dest = TRASH_DIR / f"{time.strftime('%Y%m%d_%H%M%S')}_{song_id}"
    dest.mkdir(parents=True, exist_ok=True)
    for p in (d, OUTPUT_DIR / f"{song_id}.mp3", OUTPUT_DIR / f"stems_{song_id}"):
        if p.exists():
            shutil.move(str(p), str(dest / p.name))
    return {"success": True, "trash": str(dest)}

class StemRequest(BaseModel):
    filename: str

@app.post("/api/separate-stems")
def separate_stems(req: StemRequest):
    name = Path(req.filename).name
    src = OUTPUT_DIR / name
    if not src.exists():
        raise HTTPException(404, "음원 파일을 찾을 수 없습니다.")
    if any(j.status == "running" for j in JOBS.values()):
        raise HTTPException(409, "작곡이 진행 중입니다. 작곡이 끝난 뒤 스템 분리를 해 주세요 (GPU 공유).")
    stem = Path(name).stem
    out = OUTPUT_DIR / f"stems_{stem}"
    track_dir = out / "htdemucs" / stem
    if not (track_dir / "vocals.wav").exists():
        cmd = [sys.executable, "-m", "demucs", "-d", DEVICE, "-n", "htdemucs", "--out", str(out), str(src)]
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0 or not (track_dir / "vocals.wav").exists():
            raise HTTPException(500, "스템 분리에 실패했습니다: " + (r.stderr or "")[-300:])
    base = f"/outputs/stems_{stem}/htdemucs/{stem}"
    return {"success": True, **{s: f"{base}/{s}.wav" for s in ("vocals", "drums", "bass", "other")}}

# ════════════════════════════════════════════════════════════════
# 화면
# ════════════════════════════════════════════════════════════════
NO_CACHE = {"Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache"}

@app.get("/")
def serve_index():
    index = STATIC_DIR / "index.html"
    if index.exists():
        return FileResponse(str(index), headers=NO_CACHE)
    return HTMLResponse("<h1>JK MUSIC Studio PRO 서버 실행 중</h1>")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=7860, log_level="warning")
