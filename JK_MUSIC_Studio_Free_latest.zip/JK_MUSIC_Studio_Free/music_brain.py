# -*- coding: utf-8 -*-
"""
JK MUSIC Studio PRO - 음악 설계 엔진 (music_brain.py)
────────────────────────────────────────────────────────────
1) 장르 프로파일 DB : 장르별 BPM·조성·그루브·핵심 악기·사운드 질감·보컬 창법·작사 규칙·곡 구조
2) 스타일 프롬프트 빌더 : YuE2 공식 권장 형식(언어, 보컬, 장르, 악기, 분위기, BPM)으로 조립
3) 제목 중심 AI 작사 : Claude API → Gemini 순서로 호출, 제목이 후렴에 반드시 들어가도록 검증·재시도
4) 가사 정리기 : 편집기용 가사 → 엔진용 깨끗한 태그 가사([Verse]/[Chorus]...) 변환
"""
import os
import re
import json
import hashlib
import urllib.request
import urllib.error

# ════════════════════════════════════════════════════════════════
# 1. 곡 구조 템플릿 (섹션명, 가사 줄 수)  ─ 0줄 = 연주 구간
# ════════════════════════════════════════════════════════════════
STRUCTURES = {
    "pop":    [("Intro", 0), ("Verse 1", 4), ("Pre-Chorus", 2), ("Chorus", 4), ("Verse 2", 4),
               ("Pre-Chorus", 2), ("Chorus", 4), ("Bridge", 4), ("Chorus", 4), ("Outro", 2)],
    "ballad": [("Intro", 0), ("Verse 1", 4), ("Verse 2", 4), ("Pre-Chorus", 2), ("Chorus", 4),
               ("Verse 3", 4), ("Pre-Chorus", 2), ("Chorus", 4), ("Bridge", 4), ("Chorus", 4), ("Outro", 2)],
    "hiphop": [("Intro", 0), ("Verse 1", 8), ("Hook", 4), ("Verse 2", 8), ("Hook", 4), ("Bridge", 4),
               ("Hook", 4), ("Outro", 2)],
    "edm":    [("Intro", 0), ("Verse 1", 4), ("Pre-Chorus", 4), ("Chorus", 4), ("Interlude", 0),
               ("Verse 2", 4), ("Pre-Chorus", 4), ("Chorus", 4), ("Outro", 2)],
    "trot":   [("Intro", 0), ("Verse 1", 4), ("Chorus", 4), ("Interlude", 0), ("Verse 2", 4),
               ("Chorus", 4), ("Bridge", 2), ("Chorus", 4), ("Outro", 2)],
    "blues":  [("Intro", 0), ("Verse 1", 3), ("Verse 2", 3), ("Chorus", 4), ("Verse 3", 3),
               ("Interlude", 0), ("Chorus", 4), ("Outro", 2)],
    "folk":   [("Intro", 0), ("Verse 1", 4), ("Chorus", 4), ("Verse 2", 4), ("Chorus", 4),
               ("Bridge", 4), ("Chorus", 4), ("Outro", 2)],
    "ritual": [("Intro", 0), ("Verse 1", 4), ("Chorus", 4), ("Verse 2", 4), ("Chorus", 4),
               ("Bridge", 4), ("Chorus", 4), ("Outro", 2)],
}

# ════════════════════════════════════════════════════════════════
# 2. 장르별 작사 규칙 (카테고리 단위)
# ════════════════════════════════════════════════════════════════
LYRIC_RULES = {
    "ballad": "구체적인 장면·사물·계절 묘사로 감정을 보여줄 것(설명 금지). 후렴 줄 끝은 길게 부르기 좋은 열린 모음(아/오/어) 음절로 끝나게(철자를 늘여 쓰지는 말 것). "
              "Verse는 담담하게, 후렴에서 감정이 터지도록 어휘 강도를 올릴 것. 한 줄 10~14음절.",
    "kpop":   "짧고 중독성 있는 후렴 훅을 반복(같은 구절 2회 이상). 영어 단어는 훅에 1~2개만 허용. "
              "Verse는 리듬감 있는 짧은 음절(8~11음절), Pre-Chorus는 긴장감을 쌓는 상승 문장.",
    "hiphop": "Verse는 랩: 매 2줄 끝 라임(각운) 필수, 내부 라임·펀치라인·구체적 디테일 사용, 한 줄 12~18음절의 촘촘한 플로우. "
              "Hook는 멜로디로 부르는 짧고 기억되는 4줄.",
    "trot":   "정(情)·인생·사랑·고향 같은 트로트 정서. 꺾기 좋은 모음과 감탄('아~', '어쩌라고')을 적절히. "
              "후렴은 따라 부르기 쉬운 반복 구절, 한 줄 8~12음절, 4·4조 리듬감.",
    "blues":  "블루스 AAB 형식: Verse의 1·2줄은 같은 내용을 살짝 변주해 반복, 3줄에서 반전·답. 삶의 고단함과 버팀을 솔직하게.",
    "jazz":   "은유적이고 세련된 어휘, 도시의 밤·커피·기억 같은 이미지. 여유 있는 프레이징, 한 줄 9~13음절.",
    "soul":   "사랑·치유·고백을 진솔하게. 후렴에 애드리브를 받을 여백(짧은 구절 반복).",
    "funk":   "몸이 움직이는 리듬 단어, 반복되는 콜앤리스폰스 구절, 짧고 펀치감 있는 음절.",
    "reggae": "긍정·자유·평화·자연. 느긋한 오프비트에 맞는 짧은 구절, 후렴 반복.",
    "latin":  "열정·여름·춤. 짧고 리드미컬한 음절, 스페인어 감탄사 한두 개 허용.",
    "classical": "시적이고 격조 있는 문어체, 긴 호흡의 서정. 한 줄 10~14음절, 고요한 이미지.",
    "cinematic": "서사적 스케일(여정·운명·빛과 어둠), 장엄한 어휘, 후렴은 합창처럼 크게.",
    "gugak":  "한국적 정서(한·그리움·자연), 시적인 우리말과 고어 느낌을 섞되 이해 가능하게. 3·4조 또는 4·4조 율격.",
    "pansori": "판소리 사설처럼 서사를 풀어가는 어투(아니리 느낌), 절절한 한(恨)과 해학, 3·4조 율격.",
    "synth":  "80년대 네온·밤의 도로·레트로 향수 이미지, 영어 훅 한 구절 허용.",
    "lofi":   "일상의 사소한 순간·혼잣말 같은 담백한 어휘, 몽환적이고 느슨한 문장.",
    "edm":    "짧고 강렬한 구호형 문장. Pre-Chorus는 드롭 직전 고조되는 반복 구절, Chorus는 떼창 가능한 훅.",
    "rock":   "직설적이고 에너지 넘치는 어휘, 저항·자유·질주. 후렴은 외치듯 부를 수 있게.",
    "metal":  "강렬한 이미지(불꽃·폭풍·심판), 짧고 단호한 문장, 후렴은 샤우팅 구호.",
    "folk":   "이야기를 따라가는 서술형 가사, 소박하고 따뜻한 일상 어휘, 자연 이미지.",
    "ritual": "제이슨 리추얼 DNA: 후천개벽·우주의 가을, 천부경, 선시·화두, 플럭서스의 해체, 해원상생, 샤먼의 치유. "
              "Chorus는 선사의 사자후 '할!(喝)'로 시작. Outro에 '본래 한 물건도 없거늘 어디에 먼지가 앉으리오' 구절 포함. "
              "허구의 연애담 금지, 깨달음과 의식(儀式)의 언어로.",
}

# ════════════════════════════════════════════════════════════════
# 3. 장르 프로파일 DB  (키 = 앱 드롭다운 value)
#    en: 장르 묘사 / bpm: 기본 / rng: 허용 범위 / key: 기본 조성 / inst: 핵심 악기
#    groove: 리듬 / tex: 사운드 질감·믹스 / vox: 장르 창법 / mood: 기본 분위기 / cat: 작사 카테고리 / struct: 곡 구조
# ════════════════════════════════════════════════════════════════
G = {}
def _g(name, en, bpm, rng, key, inst, groove, tex, vox, mood, cat, struct=None):
    G[name] = dict(en=en, bpm=bpm, rng=rng, key=key, inst=inst, groove=groove, tex=tex,
                   vox=vox, mood=mood, cat=cat, struct=struct or cat)

# ── 제이슨 리추얼 ──
_g("제이슨 플럭서스 굿", "experimental Korean shamanic gut ritual, fluxus avant-garde", 96, (80, 120), "minor",
   ["daebuk drum", "kkwaenggwari", "jing gong", "haegeum", "prepared piano noise"],
   "irregular ritual pulse with sudden stops", "raw live room, chaotic dynamics, sudden silence",
   "incantatory chanting vocal with shamanic cries", "ecstatic, chaotic, sacred", "ritual")
_g("제이슨 아방가르드 선시", "avant-garde Zen meditation, contemporary classical, pansori", 60, (50, 72), "minor",
   ["temple bell", "haegeum", "daegeum", "low drone", "sparse piano"],
   "free rubato, long silences", "vast reverb, hushed intimate space",
   "pansori-style dramatic cry and whispered Zen chant", "meditative, awakening, cosmic", "ritual")
_g("제이슨 북극 샤먼 트랜스", "Siberian shamanic psytrance", 140, (130, 148), "minor",
   ["khomus jaw harp", "shamanic frame drum", "rolling psytrance bass", "arctic wind pads"],
   "driving four-on-the-floor trance pulse", "hypnotic, wide stereo, deep sub",
   "Tuvan throat singing overtones with hypnotic chant", "trance, primal, icy", "ritual")
_g("제이슨 천지공사 메탈", "cyberpunk shamanic metal", 150, (130, 180), "minor",
   ["high-gain distorted guitars", "double-bass drums", "daebuk drum", "taepyeongso", "industrial synths"],
   "blast beats and heavy half-time breakdowns", "massive wall of sound, tight modern metal mix",
   "fierce ritual shouting and chanted choir", "apocalyptic, explosive, revolutionary", "ritual")

# ── 블루스·재즈·소울 ──
_g("딥 소울 블루스", "deep soul blues", 68, (58, 80), "minor",
   ["crying electric blues guitar", "Hammond B3 organ", "upright piano", "bass", "brushed drums"],
   "slow 12/8 shuffle", "warm vintage analog, live band feel",
   "husky soulful vocal with blue notes and runs", "heartbroken, raw, smoky", "blues")
_g("정통 델타 블루스", "acoustic Delta blues", 80, (70, 96), "minor",
   ["resonator slide guitar", "harmonica", "foot stomp"],
   "loose shuffle with stomping pulse", "dry raw porch recording, lo-fi warmth",
   "gritty raw blues vocal", "weary, earthy, lonesome", "blues")
_g("시카고 일렉트릭 블루스", "Chicago electric blues", 104, (92, 120), "major",
   ["overdriven electric guitar", "harmonica", "walking bass", "piano", "shuffle drums"],
   "12-bar shuffle groove", "tube amp crunch, live club sound",
   "powerful gritty blues vocal", "swaggering, gritty", "blues")
_g("스무스 재즈 카페", "smooth jazz", 92, (80, 110), "major",
   ["tenor saxophone", "Rhodes electric piano", "upright bass", "brushed drums", "jazz guitar"],
   "relaxed swing and bossa feel", "polished warm studio, soft room reverb",
   "silky relaxed jazz vocal", "cozy, late night, elegant", "jazz", "folk")
_g("네오 소울 / R&B", "neo-soul R&B", 84, (70, 96), "minor",
   ["Rhodes electric piano", "warm fingered bass", "laid-back drums", "soft guitar licks"],
   "behind-the-beat laid-back groove", "silky warm mix, lush layered harmonies",
   "smooth soulful vocal with melismatic runs", "romantic, intimate, sensual", "soul", "pop")

# ── 펑크·레게·그루브 ──
_g("그루비 펑크 디스코", "funk disco", 118, (110, 126), "minor",
   ["slap bass", "brass horn section", "wah rhythm guitar", "clavinet", "four-on-the-floor drums"],
   "tight syncopated sixteenth-note funk groove", "punchy bright 70s disco mix",
   "energetic funky vocal with ad-libs", "joyful, dancing, groovy", "funk", "pop")
_g("루츠 레게 & 덥", "roots reggae dub", 76, (66, 88), "minor",
   ["offbeat skank guitar", "deep dub bass", "Hammond organ bubble", "one-drop drums"],
   "one-drop reggae rhythm", "spacious dub echo and spring reverb, heavy low end",
   "relaxed laid-back reggae vocal", "peaceful, sunny, hopeful", "reggae", "folk")
_g("트로피컬 레게톤", "tropical reggaeton", 95, (88, 100), "minor",
   ["dembow drums", "marimba", "latin guitar", "deep 808 bass", "warm synth pads"],
   "dembow rhythm", "bright modern latin pop mix",
   "sultry rhythmic vocal", "hot, summer, seductive", "latin", "pop")
_g("애시드 재즈 / 펑크", "acid jazz funk", 108, (96, 118), "minor",
   ["Rhodes electric piano", "muted trumpet", "walking bass", "breakbeat drums", "wah guitar"],
   "breakbeat jazz-funk groove", "retro 90s London club sound",
   "cool smooth vocal", "cool, urban, groovy", "funk", "pop")

# ── 클래식·네오클래시컬 ──
_g("정통 심포니 오케스트라", "romantic symphonic orchestra", 76, (60, 100), "minor",
   ["full string section", "French horns", "woodwinds", "timpani", "harp"],
   "expressive rubato", "concert hall reverb, wide natural orchestral dynamics",
   "classical operatic vocal", "majestic, noble, emotional", "classical", "folk")
_g("네오 클래시컬 피아노", "neo-classical piano", 70, (60, 84), "minor",
   ["felt grand piano", "solo cello", "chamber strings"],
   "gentle flowing arpeggios", "intimate close-mic piano, soft room",
   "breathy gentle vocal", "poignant, fragile, reflective", "classical", "ballad")
_g("영화 OST 웅장 오케스트라", "epic cinematic film score", 90, (70, 120), "minor",
   ["massive brass", "soaring violins", "taiko drums", "choir", "low strings ostinato"],
   "driving orchestral ostinato", "huge hybrid cinematic mix, deep sub hits",
   "powerful heroic vocal with choir", "epic, heroic, destiny", "cinematic", "pop")

# ── 현대 퓨전 ──
_g("오케스트럴 신스웨이브 퓨전", "cyberpunk synthwave orchestral fusion", 110, (96, 124), "minor",
   ["analog synth arpeggios", "orchestral brass", "violins", "driving synth bass", "gated drums"],
   "driving eighth-note pulse", "neon wide stereo, cinematic hybrid mix",
   "cinematic vocal with reverb", "futuristic, epic, nocturnal", "synth", "pop")
_g("국악 EDM 크로스오버", "Korean gugak EDM crossover", 128, (124, 132), "minor",
   ["taepyeongso lead", "haegeum", "janggu", "festival supersaw synths", "heavy kick"],
   "four-on-the-floor festival beat with big drop", "massive festival mix, huge sidechain",
   "powerful Korean vocal with traditional ornaments", "euphoric, festive, powerful", "edm")
_g("재즈 힙합 퓨전", "jazz hop", 88, (80, 94), "minor",
   ["dusty jazz piano", "upright bass", "boom bap drums", "muted trumpet"],
   "swung boom bap groove", "warm vinyl texture, lo-fi saturation",
   "laid-back rap verses and smooth sung hook", "chill, urban, nostalgic", "hiphop")
_g("펑크 록 퓨전", "funk rock", 112, (100, 124), "minor",
   ["slap bass", "distorted rhythm guitar", "tight rock drums", "clavinet"],
   "syncopated funk rock groove", "raw punchy live band mix",
   "energetic rock vocal with funky phrasing", "gritty, energetic, cocky", "rock", "pop")

# ── 한국 전통·성인가요 ──
_g("국악 / 퓨전국악", "Korean fusion gugak", 84, (66, 100), "minor",
   ["gayageum", "haegeum", "daegeum", "janggu", "soft strings"],
   "gutgeori jangdan 12/8 lilt", "elegant cinematic oriental mix",
   "Korean traditional vocal with sigimsae ornaments", "longing, elegant, han", "gugak", "folk")
_g("사물놀이 / 타악", "Korean samulnori percussion", 120, (100, 150), "major",
   ["kkwaenggwari", "jing", "janggu", "buk drum"],
   "accelerating jajinmori jangdan", "live outdoor energy, powerful percussion",
   "shouting chuimsae calls", "festive, wild, communal", "gugak", "folk")
_g("트로트 / 성인가요", "Korean trot", 128, (110, 140), "minor",
   ["brass section", "electric organ", "bouncy synth bass", "accordion", "disco drums"],
   "bouncy two-step ppongjjak rhythm", "bright punchy Korean adult contemporary mix",
   "trot vocal with kkeokki vibrato and bends", "lively, heartfelt, nostalgic", "trot")
_g("판소리풍 웅장 발라드", "epic pansori-influenced Korean ballad", 72, (60, 84), "minor",
   ["buk drum", "gayageum", "haegeum", "grand strings", "piano"],
   "slow jinyangjo feel building to climax", "wide cinematic mix, grand dynamics",
   "pansori-style raspy powerful vocal", "tragic, grand, han", "pansori", "ballad")

# ── 대중음악·댄스 ──
_g("K-Pop 댄스", "K-pop dance pop", 122, (112, 130), "minor",
   ["bright synth leads", "punchy EDM drums", "deep synth bass", "vocal chops"],
   "tight dance groove with switch-up drops", "polished glossy K-pop mix, loud and crisp",
   "catchy confident pop vocal", "energetic, confident, bright", "kpop", "pop")
_g("감성 팝 발라드", "Korean emotional pop ballad", 72, (62, 82), "major",
   ["grand piano", "lush string section", "soft drums", "warm bass"],
   "slow 4/4 build", "clean intimate mix with big chorus lift",
   "emotive vocal building to soaring chorus", "sentimental, longing, warm", "ballad")
_g("80s 신스웨이브", "80s synthwave", 108, (96, 118), "minor",
   ["analog synth leads", "arpeggiated bass", "gated reverb drums", "lush pads"],
   "driving retro eighth-note pulse", "neon retro, lush reverb, tape warmth",
   "dreamy reverb vocal", "nostalgic, nocturnal, cinematic", "synth", "pop")
_g("로파이 칠", "lo-fi chill hop", 80, (70, 88), "minor",
   ["dusty Rhodes chords", "mellow bass", "soft boom bap drums", "vinyl crackle"],
   "lazy swung beat", "warm tape saturation, muffled lo-fi texture",
   "soft whispery vocal", "calm, cozy, dreamy", "lofi", "folk")
_g("힙합 / 붐뱁 & 트랩", "modern Korean hip hop trap", 140, (130, 150), "minor",
   ["heavy 808 bass", "trap hi-hats", "dark piano", "bell melody"],
   "trap half-time groove with rolling hi-hats", "hard-hitting modern mix, deep sub",
   "confident rap flow with melodic hook", "dark, confident, hungry", "hiphop")
_g("EDM 페스티벌", "progressive house EDM", 128, (124, 130), "major",
   ["supersaw leads", "big room kick", "plucks", "risers", "sub bass"],
   "build-up into massive drop", "huge festival mix, heavy sidechain",
   "euphoric soaring vocal", "euphoric, uplifting, massive", "edm")

# ── 록·메탈·포크 ──
_g("인디 록 / 모던 록", "Korean modern indie rock", 124, (110, 140), "major",
   ["overdriven electric guitars", "live drums", "driving bass", "piano"],
   "driving straight rock beat", "raw live band energy, wide guitars",
   "earnest emotional rock vocal", "youthful, free, hopeful", "rock", "pop")
_g("하드 록 / 헤비메탈", "heavy metal", 150, (120, 180), "minor",
   ["heavy distorted guitar riffs", "double-bass drums", "bass", "guitar solo"],
   "galloping metal rhythm", "massive saturated wall of sound",
   "powerful high rock vocal with grit", "aggressive, heroic, fierce", "metal", "pop")
_g("어쿠스틱 포크", "acoustic folk", 96, (80, 110), "major",
   ["fingerpicked acoustic guitar", "violin", "light percussion", "upright bass"],
   "gentle strummed folk rhythm", "organic natural room sound",
   "warm honest storytelling vocal", "warm, nostalgic, simple", "folk")

# ════════════════════════════════════════════════════════════════
# 4. 보컬 / 분위기 / 악기 강조 / 마스터링
# ════════════════════════════════════════════════════════════════
VOCALS = {
    "맑고 감미로운 여성 보컬": ("female", "clear sweet female vocal, emotive phrasing"),
    "파워풀한 여성 고음 보컬": ("female", "powerful female belting vocal, strong high notes"),
    "허스키하고 몽환적인 여성 보컬": ("female", "husky dreamy breathy female vocal"),
    "소울풀한 흑인 여성 R&B 보컬": ("female", "soulful female R&B vocal with runs and ad-libs"),
    "따뜻하고 부드러운 남성 미성": ("male", "warm soft male tenor vocal"),
    "호소력 짙은 감성 발라드 남성": ("male", "passionate male ballad vocal, soaring chorus"),
    "거칠고 파워풀한 록 샤우팅 남성": ("male", "gritty raspy male rock vocal with shouting"),
    "중저음의 감미로운 바리톤 남성": ("male", "deep warm baritone male vocal"),
    "남녀 혼성 듀엣": ("duet", "male and female duet, harmonized chorus"),
    "웅장한 가스펠 합창단": ("choir", "lead vocal with full gospel choir"),
    "보컬 없는 순수 연주곡": ("inst", "instrumental, no vocals"),
    "감성 피아노 & 스트링 BGM": ("inst", "instrumental, no vocals, emotive piano and strings"),
    "영화/영상 OST 웅장 시네마틱 BGM": ("inst", "instrumental, no vocals, epic cinematic score"),
    "카페 & 휴식 로파이 칠 BGM": ("inst", "instrumental, no vocals, cozy lo-fi cafe music"),
    "명상 & 앰비언트 힐링 BGM": ("inst", "instrumental, no vocals, serene ambient healing"),
}

# (묘사, BPM 배율, 조성 우선)
MOODS = {
    "기본 장르 최적화": (None, 1.00, None),
    "신나고 경쾌한 빠른 템포": ("upbeat, bright and joyful, high energy", 1.12, "major"),
    "서정적이고 아련한 감성": ("wistful, tender and nostalgic", 0.90, "minor"),
    "웅장하고 비장한 서사": ("epic and solemn, grand build-up to a powerful climax", 0.95, "minor"),
    "어둡고 그루비한 비트": ("dark, moody late-night groove", 0.97, "minor"),
    "따뜻하고 편안한 어쿠스틱 카페": ("warm, cozy and relaxed", 0.90, "major"),
    "격정적이고 폭발적인 사운드": ("passionate and explosive, intense climax", 1.06, "minor"),
}

INSTRUMENT_FOCUS = {
    "기본 편성": [],
    "펑키 슬랩 베이스 & 브라스": ["slap bass", "brass horn section", "wah rhythm guitar"],
    "레게 챂 기타 & 오르간": ["offbeat skank guitar", "Hammond organ", "dub bass"],
    "그랜드 피아노 & 첼로": ["grand piano", "solo cello"],
    "코무스 & 샤먼 북 & 호미": ["khomus jaw harp", "shamanic frame drum", "throat singing"],
    "대북 & 꽹과리 & 징": ["daebuk drum", "kkwaenggwari", "jing gong"],
    "가야금 & 대금 & 장구": ["gayageum", "daegeum", "janggu"],
    "어쿠스틱 & 일렉 기타": ["acoustic guitar", "lead electric guitar"],
    "그랜드 피아노 & 스트링": ["grand piano", "lush strings"],
    "묵직한 808 베이스 & 드럼": ["heavy 808 bass", "punchy drums"],
    "감성 브라스 & 색소폰": ["tenor saxophone", "warm brass section"],
    "아날로그 신디사이저": ["analog synth lead", "synth arpeggios", "lush pads"],
    "웅장한 시네마틱 금관 & 타악": ["French horns", "trumpets", "taiko drums"],
}

DYNAMICS = {
    "스튜디오 마스터링 & 와이드 다이내믹스": "wide stereo, clear vocal mix, punchy low end",
    "하이 다이내믹 빌드업": "soft intimate verses exploding into a huge chorus",
    "따뜻하고 묵직한 아날로그": "warm analog tape saturation, vintage character",
    "오리지널 기본 음향": "",
}

MAJOR_KEYS = ["C major", "G major", "D major", "F major", "E-flat major", "A major", "B-flat major"]
MINOR_KEYS = ["A minor", "E minor", "D minor", "C minor", "F-sharp minor", "G minor", "B minor"]

# ════════════════════════════════════════════════════════════════
# 5. 유틸
# ════════════════════════════════════════════════════════════════
def has_hangul(text):
    return any('\uac00' <= c <= '\ud7a3' or '\u3131' <= c <= '\u318e' for c in (text or ""))

def has_latin(text):
    return bool(re.search(r"[A-Za-z]", text or ""))

def resolve_lang(lang, *texts):
    """'auto'면 제목/주제에 한글이 없고 영어만 있을 때 영어, 그 외 한국어"""
    if lang in ("ko", "en"):
        return lang
    joined = " ".join(t for t in texts if t)
    if joined.strip() and has_latin(joined) and not has_hangul(joined):
        return "en"
    return "ko"

def get_profile(genre):
    if genre in G:
        return G[genre]
    base = dict(G["감성 팝 발라드"])   # 알 수 없는 장르 → 발라드 기본값 + 장르명 그대로
    base["en"] = genre
    return base

def _pick_key(genre, mode, title=""):
    """장르+제목 기반으로 항상 같은 조를 고르되 곡마다 다양하게"""
    pool = MINOR_KEYS if mode == "minor" else MAJOR_KEYS
    h = int(hashlib.md5(f"{genre}|{title}".encode("utf-8")).hexdigest(), 16)
    return pool[h % len(pool)]

def _dedupe(items):
    seen, out = set(), []
    for it in items:
        k = it.strip().lower()
        if k and k not in seen:
            seen.add(k)
            out.append(it.strip())
    return out

# ════════════════════════════════════════════════════════════════
# 6. 스타일 프롬프트 빌더
# ════════════════════════════════════════════════════════════════
def build_style(genre, vocal, mood="기본 장르 최적화", inst_focus="기본 편성", chips=None,
                dynamics="스튜디오 마스터링 & 와이드 다이내믹스", lang="auto",
                bpm=None, key_mode="auto", title="", topic=""):
    """
    YuE2 권장 순서: 언어 → 보컬 → 장르 → 악기 → 그루브/분위기/질감 → BPM → 조성
    반환: dict(style, bpm, key, lang, instrumental, summary, instruments)
    """
    p = get_profile(genre)
    lang = resolve_lang(lang, title, topic)
    v_kind, v_desc = VOCALS.get(vocal, ("custom", vocal or ""))
    instrumental = v_kind == "inst"
    m_desc, m_mult, m_key = MOODS.get(mood, (mood if mood and mood != "기본 장르 최적화" else None, 1.0, None))

    # BPM: 사용자 지정 > 장르 기본 × 분위기 배율 (장르 허용 범위 안으로)
    if bpm:
        final_bpm = max(40, min(220, int(bpm)))
    else:
        lo, hi = p["rng"]
        final_bpm = max(lo, min(hi, int(round(p["bpm"] * m_mult))))

    # 조성: 사용자 지정 > 분위기 > 장르 기본
    mode = key_mode if key_mode in ("major", "minor") else (m_key or p["key"])
    key = _pick_key(genre, mode, title)

    # 악기: 사용자 강조(칩 → 드롭다운) 우선 + 장르 핵심 악기로 채워 최대 6개
    focus = list(chips or []) + INSTRUMENT_FOCUS.get(inst_focus, [])
    instruments = _dedupe(focus + p["inst"])[:6]

    parts = []
    if not instrumental:
        parts.append("Korean" if lang == "ko" else "English")
        parts.append(v_desc)      # 사용자가 고른 보컬 음색
        parts.append(p["vox"])    # 장르 고유 창법
    else:
        parts.append("instrumental, no vocals")
        extra = v_desc.replace("instrumental, no vocals", "").strip(" ,")
        if extra:
            parts.append(extra)
    parts.append(p["en"])
    parts.append(", ".join(instruments))
    parts.append(p["groove"])
    parts.append(m_desc or p["mood"])
    parts.append(p["tex"])
    d = DYNAMICS.get(dynamics, "")
    if d and instrumental:
        d = d.replace(", clear vocal mix", "")   # 연주곡엔 보컬 믹스 표현 제외
    if d:
        parts.append(d)
    parts.append(f"{final_bpm} BPM")
    parts.append(key)

    # 쉼표 단위로 쪼개 중복·포함 관계(짧은 구절이 긴 구절에 이미 포함) 제거
    pieces = _dedupe([pc for x in parts if x for pc in x.split(", ")])
    pieces = [pc for pc in pieces
              if len(pc.split()) < 2   # 한 단어(언어·분위기 형용사)는 항상 유지
              or not any(pc.lower() != o.lower() and pc.lower() in o.lower() for o in pieces)]
    style = ", ".join(pieces)
    lang_label = "연주곡" if instrumental else ("한국어" if lang == "ko" else "English")
    summary = f"{final_bpm} BPM · {key} · {lang_label} · 악기 {len(instruments)}종"
    return dict(style=style, bpm=final_bpm, key=key, lang=lang,
                instrumental=instrumental, summary=summary, instruments=instruments)

# ════════════════════════════════════════════════════════════════
# 7. 가사 정리 (편집기용 ↔ 엔진용)
# ════════════════════════════════════════════════════════════════
_TAG_WORDS = (r"intro|verse|pre[\s-]?chorus|chorus|hook|refrain|post[\s-]?chorus|bridge|outro|interlude|"
              r"instrumental|solo|drop|build[\s-]?up|rap|breakdown|인트로|벌스|후렴|코러스|브릿지|아웃트로|간주")
_TAG_RE = re.compile(r"^\s*[\[【(]\s*(" + _TAG_WORDS + r")([^\]】)]*)[\]】)]\s*$", re.I)
_BARE_TAG_RE = re.compile(r"^\s*(" + _TAG_WORDS + r")\s*(\d*)\s*[:：]?\s*$", re.I)

_ENGINE_TAG = {
    "intro": "Intro", "인트로": "Intro",
    "verse": "Verse", "벌스": "Verse", "rap": "Verse",
    "prechorus": "Pre-Chorus", "buildup": "Pre-Chorus",
    "chorus": "Chorus", "hook": "Chorus", "refrain": "Chorus", "후렴": "Chorus", "코러스": "Chorus",
    "drop": "Chorus", "postchorus": "Chorus",
    "bridge": "Bridge", "브릿지": "Bridge", "breakdown": "Bridge",
    "outro": "Outro", "아웃트로": "Outro",
    "interlude": "Interlude", "instrumental": "Interlude", "solo": "Interlude", "간주": "Interlude",
}

def _norm_tag(word):
    return _ENGINE_TAG.get(re.sub(r"[\s-]", "", word.lower()), "Verse")

def _match_tag(s):
    return _TAG_RE.match(s) or _BARE_TAG_RE.match(s)

def clean_llm_lyrics(text):
    """LLM 출력에서 코드블록·제목줄·설명·마크다운 제거, 태그 표기 통일 (편집기용: Verse 번호 유지)"""
    t = (text or "").replace("\r\n", "\n").strip()
    t = re.sub(r"^```[a-zA-Z]*\s*$", "", t, flags=re.M).strip()
    out = []
    for line in t.split("\n"):
        s = line.strip().strip("*#").strip()
        if re.match(r"^(제목|title|곡명|장르|genre|style)\s*[:：]", s, re.I):
            continue
        m = _match_tag(s)
        if m:
            base = _norm_tag(m.group(1))
            num = re.search(r"\d+", m.group(2) or "")
            label = f"{base} {num.group()}" if (num and base == "Verse") else base
            if out and out[-1] != "":
                out.append("")
            out.append(f"[{label}]")
            continue
        s = re.sub(r"\[[^\]]*\]", "", s).strip()   # 가사 줄 속 연출 지시문 제거
        out.append(s)
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out)).strip()

def to_engine_lyrics(text):
    """엔진 전달용: [Verse 1 - 설명] → [Verse], 설명·번호 제거, 섹션 사이 빈 줄"""
    out = []
    for line in (text or "").replace("\r\n", "\n").split("\n"):
        s = line.strip()
        if not s:
            continue
        m = _match_tag(s)
        if m:
            if out:
                out.append("")
            out.append(f"[{_norm_tag(m.group(1))}]")
            continue
        s = re.sub(r"\[[^\]]*\]", "", s).strip()
        if s:
            out.append(s)
    return "\n".join(out).strip()

def has_sung_lines(text):
    return any(l.strip() and not _match_tag(l.strip()) for l in (text or "").split("\n"))

def instrumental_lyrics(genre=""):
    """연주곡용 깨끗한 섹션 골격 (장르 구조 기반)"""
    p = get_profile(genre) if genre else G["감성 팝 발라드"]
    key = p["struct"] if p["struct"] in STRUCTURES else "pop"
    return "\n\n".join(f"[{_norm_tag(s.split()[0])}]" for s, _ in STRUCTURES[key])

# ════════════════════════════════════════════════════════════════
# 8. 제목 중심 작사 프롬프트
# ════════════════════════════════════════════════════════════════
def _structure_text(struct_key):
    rows = []
    for name, n in STRUCTURES[struct_key]:
        rows.append(f"[{name}]" + ("   ← 가사 없이 태그만 (연주 구간)" if n == 0 else f"   ← {n}줄"))
    return "\n".join(rows)

def build_lyrics_prompt(title, topic, genre, vocal, mood, lang, style_info):
    p = get_profile(genre)
    struct_key = p["struct"] if p["struct"] in STRUCTURES else "pop"
    rules = LYRIC_RULES.get(p["cat"], LYRIC_RULES["ballad"])
    lang_name = "한국어" if lang == "ko" else "English"
    v_kind, _ = VOCALS.get(vocal, ("custom", ""))
    duet = ("남녀 듀엣이므로 Verse 1은 남성 화자, Verse 2는 여성 화자 시점, 후렴은 두 사람이 함께 부르는 가사로.\n"
            if v_kind == "duet" else "")
    story = topic.strip() if topic and topic.strip() else f"제목 「{title}」에서 떠오르는 가장 설득력 있는 이야기를 스스로 설정"
    mood_txt = mood if mood and mood != "기본 장르 최적화" else p["mood"]

    return f"""당신은 음원 차트 상위권 곡을 다수 쓴 전문 작사가입니다. 아래 곡의 가사를 씁니다.

■ 곡 제목: 「{title}」
■ 스토리/주제: {story}
■ 장르: {genre} ({p['en']})
■ 보컬: {vocal}
■ 분위기: {mood_txt}
■ 템포/조성: {style_info['bpm']} BPM, {style_info['key']}
■ 가사 언어: {lang_name}

[최우선 규칙 — 제목]
1. 이 노래는 「{title}」라는 제목의 노래다. 모든 Verse가 제목의 상황·이미지·감정을 구체적으로 전개해야 한다. 제목과 무관한 일반적인 사랑/이별 문장 금지.
2. 모든 [Chorus](또는 [Hook])의 첫 줄 또는 마지막 줄에 제목 「{title}」 구절을 그대로(또는 거의 그대로) 넣어 훅으로 만든다.
3. Verse 1은 제목의 장면을 여는 구체적 묘사, Verse 2는 이야기를 한 걸음 진전, Bridge는 시점 전환이나 반전으로 제목의 의미를 확장.

[장르 작사 규칙]
{rules}
{duet}
[곡 구조 — 이 태그와 순서를 정확히 지킬 것]
{_structure_text(struct_key)}

[출력 형식]
- 위 태그를 한 줄에 단독으로 쓰고, 그 아래 실제로 노래할 가사만 쓴다.
- 태그 안이나 가사 줄에 악기·연주·분위기 지시문을 절대 넣지 말 것 (예: [Chorus - 폭발적인 밴드] 금지).
- 제목 줄, 해설, 인사말, 따옴표, 마크다운, 이모지 없이 가사만 출력.
- 후렴은 반복하되 마지막 후렴은 한 줄 정도 변주해 클라이맥스를 만든다.
- 발음하기 쉽고 멜로디에 얹기 좋은 자연스러운 {lang_name} 문장으로.
- 모음 늘이기 표기(예: "오오", "안고서어", "~")나 괄호 추임새는 쓰지 말 것. 음 길이는 작곡 엔진이 결정한다."""

# ════════════════════════════════════════════════════════════════
# 9. LLM 호출 (Claude → Gemini 순)
# ════════════════════════════════════════════════════════════════
# ── 앱 안 설정 파일 (⚙ 설정 화면에서 입력한 API 키 저장 · 이 PC 안에만 보관) ──
SETTINGS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config", "settings.json")
SETTING_KEYS = ("ANTHROPIC_API_KEY", "GEMINI_API_KEY")


def load_settings():
    try:
        with open(SETTINGS_PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_settings(updates):
    """updates: {키이름: 값} — 값이 빈 문자열이면 삭제, None 이면 그대로 둠"""
    d = load_settings()
    for k, v in updates.items():
        if k not in SETTING_KEYS or v is None:
            continue
        v = str(v).strip()
        if v:
            d[k] = v
        else:
            d.pop(k, None)
    os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
    tmp = SETTINGS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, SETTINGS_PATH)
    return d


def masked(v):
    return (v[:7] + "…" + v[-4:]) if v and len(v) > 12 else ("설정됨" if v else "")


def _env(*names):
    """앱 설정 파일 → 프로세스 환경변수 → Windows 사용자 환경변수(레지스트리) 순으로 조회"""
    st = load_settings()
    for n in names:
        if st.get(n):
            return st[n]
    for n in names:
        v = os.environ.get(n)
        if v:
            return v
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
                for n in names:
                    try:
                        v, _ = winreg.QueryValueEx(k, n)
                        if v:
                            return v
                    except FileNotFoundError:
                        pass
        except Exception:
            pass
    return None

CLAUDE_MODEL = _env("CLAUDE_MODEL") or "claude-sonnet-5"
GEMINI_MODELS = [m for m in [_env("GEMINI_MODEL"), "gemini-2.5-flash", "gemini-flash-latest"] if m]

def llm_status():
    return {"claude": bool(_env("ANTHROPIC_API_KEY")),
            "gemini": bool(_env("GEMINI_API_KEY", "GOOGLE_API_KEY"))}

def _post_json(url, payload, headers, timeout=90):
    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"),
                                 headers={"Content-Type": "application/json", **headers})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))

def _claude_headers(key):
    """워크스페이스에 묶이지 않은 키는 ANTHROPIC_WORKSPACE_ID 헤더가 필요"""
    h = {"x-api-key": key, "anthropic-version": "2023-06-01"}
    ws = _env("ANTHROPIC_WORKSPACE_ID")
    if ws:
        h["anthropic-workspace-id"] = ws
    return h

def _call_claude(prompt, key):
    res = _post_json("https://api.anthropic.com/v1/messages", {
        "model": CLAUDE_MODEL, "max_tokens": 3000,   # 최신 Claude 모델은 temperature 미지원
        "messages": [{"role": "user", "content": prompt}],
    }, _claude_headers(key))
    return "".join(b.get("text", "") for b in res.get("content", []) if b.get("type") == "text")

def _call_gemini(prompt, key):
    last = None
    for model in GEMINI_MODELS:
        try:
            res = _post_json(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}", {
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {
                        "temperature": 0.85, "maxOutputTokens": 4096,
                        "thinkingConfig": {"thinkingBudget": 0},   # 사고 토큰이 출력 한도를 잡아먹지 않게
                    },
                }, {})
            cand = res["candidates"][0]
            text = "".join(p.get("text", "") for p in cand.get("content", {}).get("parts", []))
            if text.strip():
                return text
            last = RuntimeError(f"{model}: 빈 응답 (finishReason={cand.get('finishReason')})")
        except urllib.error.HTTPError as e:
            last = RuntimeError(f"{model}: HTTP {e.code} {e.read().decode('utf-8', 'ignore')[:200]}")
        except Exception as e:
            last = e
    raise last or RuntimeError("Gemini 호출 실패")

def call_llm(prompt):
    errors = []
    ck = _env("ANTHROPIC_API_KEY")
    if ck:
        try:
            return _call_claude(prompt, ck), "claude"
        except urllib.error.HTTPError as e:
            errors.append(f"Claude HTTP {e.code}: {e.read().decode('utf-8', 'ignore')[:200]}")
        except Exception as e:
            errors.append(f"Claude: {e}")
    gk = _env("GEMINI_API_KEY", "GOOGLE_API_KEY")
    if gk:
        try:
            return _call_gemini(prompt, gk), "gemini"
        except Exception as e:
            errors.append(f"Gemini: {e}")
    if not ck and not gk:
        errors.append("AI 작사용 API 키가 없습니다. 화면 오른쪽 위 ⚙ 설정에서 Claude 또는 Gemini API 키를 넣거나, 가사를 직접 입력해 주세요.")
    raise RuntimeError(" / ".join(errors))

# ════════════════════════════════════════════════════════════════
# 10. 제목 반영 검증 + 작사 메인
# ════════════════════════════════════════════════════════════════
def _core(s):
    return re.sub(r"[\s\W_]+", "", (s or "").lower())

def _strip_subtitle(title):
    return re.sub(r"[\(\[（【].*?[\)\]）】]", "", title or "").strip()

def _chorus_text(lyrics):
    blocks, cur, grab = [], [], False
    for line in lyrics.split("\n"):
        if line.startswith("["):
            if grab and cur:
                blocks.append(" ".join(cur))
            cur, grab = [], ("Chorus" in line or "Hook" in line)
        elif grab and line.strip():
            cur.append(line)
    if grab and cur:
        blocks.append(" ".join(cur))
    return " ".join(blocks)

def title_in_lyrics(title, lyrics):
    """후렴에 제목(또는 제목 핵심 단어 대부분)이 들어갔는지 확인 — 조사 변화 허용"""
    chorus = _core(_chorus_text(lyrics)) or _core(lyrics)
    base = _strip_subtitle(title)
    t = _core(base)
    if not t or t in chorus:
        return True
    words = [w for w in re.split(r"\s+", base) if len(_core(w)) >= 2]
    if not words:
        return False
    hit = sum(1 for w in words if _core(w)[:max(2, len(_core(w)) - 1)] in chorus)
    return hit / len(words) >= 0.7

def write_lyrics(title, topic, genre, vocal, mood, lang, style_info):
    prompt = build_lyrics_prompt(title, topic, genre, vocal, mood, lang, style_info)
    raw, provider = call_llm(prompt)
    lyrics = clean_llm_lyrics(raw)
    retried = False
    if not title_in_lyrics(title, lyrics):
        retried = True
        fix = (prompt + f"\n\n[수정 요청] 직전 결과는 후렴에 제목 「{title}」이 들어가지 않았다. "
               f"모든 [Chorus]의 첫 줄 또는 마지막 줄에 「{title}」을 그대로 넣어 처음부터 다시 써라.")
        raw2, provider = call_llm(fix)
        lyrics2 = clean_llm_lyrics(raw2)
        if title_in_lyrics(title, lyrics2) or not title_in_lyrics(title, lyrics):
            lyrics = lyrics2 if lyrics2 else lyrics
    return dict(lyrics=lyrics, provider=provider, title_ok=title_in_lyrics(title, lyrics), retried=retried)

def catalog():
    """프론트엔드 표시용 장르 요약"""
    return {name: {"bpm": p["bpm"], "range": list(p["rng"]), "key": p["key"], "cat": p["cat"]}
            for name, p in G.items()}
