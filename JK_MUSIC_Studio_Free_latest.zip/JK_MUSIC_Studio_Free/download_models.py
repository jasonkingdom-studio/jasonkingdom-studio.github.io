# -*- coding: utf-8 -*-
"""
JK MUSIC Studio — 작곡 모델 다운로드 (download_models.py)
YuE2 모델을 공식 Hugging Face 저장소(m-a-p)에서 앱 폴더의 models/ 로 직접 받습니다.
· 모델 가중치 라이선스: CC BY-NC 4.0 + 개인 창작자 허가 (LICENSES/YuE2_MODEL_LICENSE.txt 참고)
· 중간에 끊겨도 다시 실행하면 이어서 받습니다.
"""
import sys
import time
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

APP = Path(__file__).resolve().parent
MODELS = [("m-a-p/YuE2-3B", APP / "models" / "YuE2-3B", "작곡 모델 (약 6.9GB)"),
          ("m-a-p/YuE2-Vae", APP / "models" / "YuE2-Vae", "오디오 복원 모델 (약 0.5GB)")]


def ready(d: Path) -> bool:
    f = d / "model.safetensors"
    return f.exists() and f.stat().st_size > 100_000_000 and (d / "config.json").exists()


def main():
    from huggingface_hub import snapshot_download
    for repo, dest, label in MODELS:
        if ready(dest):
            print(f"   ✔ {label} — 이미 받아져 있습니다 ({dest.name})", flush=True)
            continue
        print(f"   ↓ {label} 받는 중: https://huggingface.co/{repo}", flush=True)
        dest.mkdir(parents=True, exist_ok=True)
        for attempt in range(1, 4):
            try:
                snapshot_download(repo_id=repo, local_dir=str(dest),
                                  ignore_patterns=["*.whl", "assets/*", ".gitattributes"])
                break
            except Exception as e:
                print(f"   ⚠ 재시도 {attempt}/3: {e}", flush=True)
                if attempt == 3:
                    raise
                time.sleep(5)
        if not ready(dest):
            raise RuntimeError(f"{label} 파일이 완전하지 않습니다. 다시 실행해 주세요.")
        print(f"   ✔ {label} 완료", flush=True)
    print("   ✔ 작곡 모델 준비 완료", flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n   ✖ 모델 다운로드 실패: {e}", flush=True)
        sys.exit(1)
